typedef unsigned char   undefined;

typedef unsigned char    byte;
typedef unsigned int    dword;
typedef unsigned long long    GUID;
typedef pointer32 ImageBaseOffset32;

typedef unsigned char    uchar;
typedef unsigned int    uint;
typedef unsigned long    ulong;
typedef unsigned char    undefined1;
typedef unsigned short    undefined2;
typedef unsigned int    undefined4;
typedef unsigned long long    undefined8;
typedef unsigned short    ushort;
typedef unsigned short    wchar16;
typedef unsigned short    word;
typedef union IMAGE_RESOURCE_DIRECTORY_ENTRY_DirectoryUnion IMAGE_RESOURCE_DIRECTORY_ENTRY_DirectoryUnion, *PIMAGE_RESOURCE_DIRECTORY_ENTRY_DirectoryUnion;

typedef struct IMAGE_RESOURCE_DIRECTORY_ENTRY_DirectoryStruct IMAGE_RESOURCE_DIRECTORY_ENTRY_DirectoryStruct, *PIMAGE_RESOURCE_DIRECTORY_ENTRY_DirectoryStruct;

struct IMAGE_RESOURCE_DIRECTORY_ENTRY_DirectoryStruct {
    dword OffsetToDirectory:31;
    dword DataIsDirectory:1;
};

union IMAGE_RESOURCE_DIRECTORY_ENTRY_DirectoryUnion {
    dword OffsetToData;
    struct IMAGE_RESOURCE_DIRECTORY_ENTRY_DirectoryStruct IMAGE_RESOURCE_DIRECTORY_ENTRY_DirectoryStruct;
};

typedef struct CLIENT_ID CLIENT_ID, *PCLIENT_ID;

struct CLIENT_ID {
    void *UniqueProcess;
    void *UniqueThread;
};

typedef struct TypeDescriptor TypeDescriptor, *PTypeDescriptor;

struct TypeDescriptor {
    void *pVFTable;
    void *spare;
    char name[0];
};

typedef struct _SECURITY_ATTRIBUTES _SECURITY_ATTRIBUTES, *P_SECURITY_ATTRIBUTES;

typedef ulong DWORD;

typedef void *LPVOID;

typedef int BOOL;

struct _SECURITY_ATTRIBUTES {
    DWORD nLength;
    LPVOID lpSecurityDescriptor;
    BOOL bInheritHandle;
};

typedef struct _WIN32_FIND_DATAA _WIN32_FIND_DATAA, *P_WIN32_FIND_DATAA;

typedef struct _WIN32_FIND_DATAA *LPWIN32_FIND_DATAA;

typedef struct _FILETIME _FILETIME, *P_FILETIME;

typedef struct _FILETIME FILETIME;

typedef char CHAR;

struct _WIN32_FIND_DATAA {
    DWORD dwFileAttributes;
    FILETIME ftCreationTime;
    FILETIME ftLastAccessTime;
    FILETIME ftLastWriteTime;
    DWORD nFileSizeHigh;
    DWORD nFileSizeLow;
    DWORD dwReserved0;
    DWORD dwReserved1;
    CHAR cFileName[260];
    CHAR cAlternateFileName[14];
};

struct _FILETIME {
    DWORD dwLowDateTime;
    DWORD dwHighDateTime;
};

typedef struct _OVERLAPPED _OVERLAPPED, *P_OVERLAPPED;

typedef ulong ULONG_PTR;

typedef union _union_518 _union_518, *P_union_518;

typedef void *HANDLE;

typedef struct _struct_519 _struct_519, *P_struct_519;

typedef void *PVOID;

struct _struct_519 {
    DWORD Offset;
    DWORD OffsetHigh;
};

union _union_518 {
    struct _struct_519 s;
    PVOID Pointer;
};

struct _OVERLAPPED {
    ULONG_PTR Internal;
    ULONG_PTR InternalHigh;
    union _union_518 u;
    HANDLE hEvent;
};

typedef struct _OVERLAPPED *LPOVERLAPPED;

typedef struct _SECURITY_ATTRIBUTES *LPSECURITY_ATTRIBUTES;

typedef CHAR *LPCSTR;

typedef long LONG;

typedef LONG *PLONG;

typedef union _LARGE_INTEGER _LARGE_INTEGER, *P_LARGE_INTEGER;

typedef struct _struct_19 _struct_19, *P_struct_19;

typedef struct _struct_20 _struct_20, *P_struct_20;

typedef double LONGLONG;

struct _struct_19 {
    DWORD LowPart;
    LONG HighPart;
};

struct _struct_20 {
    DWORD LowPart;
    LONG HighPart;
};

union _LARGE_INTEGER {
    struct _struct_19 s;
    struct _struct_20 u;
    LONGLONG QuadPart;
};

typedef union _LARGE_INTEGER LARGE_INTEGER;

typedef struct _OSVERSIONINFOA _OSVERSIONINFOA, *P_OSVERSIONINFOA;

struct _OSVERSIONINFOA {
    DWORD dwOSVersionInfoSize;
    DWORD dwMajorVersion;
    DWORD dwMinorVersion;
    DWORD dwBuildNumber;
    DWORD dwPlatformId;
    CHAR szCSDVersion[128];
};

typedef CHAR *LPSTR;

typedef struct _OSVERSIONINFOA *LPOSVERSIONINFOA;

typedef struct IMAGE_DOS_HEADER IMAGE_DOS_HEADER, *PIMAGE_DOS_HEADER;

struct IMAGE_DOS_HEADER {
    char e_magic[2]; // Magic number
    word e_cblp; // Bytes of last page
    word e_cp; // Pages in file
    word e_crlc; // Relocations
    word e_cparhdr; // Size of header in paragraphs
    word e_minalloc; // Minimum extra paragraphs needed
    word e_maxalloc; // Maximum extra paragraphs needed
    word e_ss; // Initial (relative) SS value
    word e_sp; // Initial SP value
    word e_csum; // Checksum
    word e_ip; // Initial IP value
    word e_cs; // Initial (relative) CS value
    word e_lfarlc; // File address of relocation table
    word e_ovno; // Overlay number
    word e_res[4][4]; // Reserved words
    word e_oemid; // OEM identifier (for e_oeminfo)
    word e_oeminfo; // OEM information; e_oemid specific
    word e_res2[10][10]; // Reserved words
    dword e_lfanew; // File address of new exe header
    byte e_program[64]; // Actual DOS program
};

typedef ULONG_PTR SIZE_T;

typedef int (*FARPROC)(void);

typedef DWORD *LPDWORD;

typedef struct HINSTANCE__ HINSTANCE__, *PHINSTANCE__;

struct HINSTANCE__ {
    int unused;
};

typedef HANDLE HGLOBAL;

typedef uint *PUINT;

typedef void *LPCVOID;

typedef struct HINSTANCE__ *HINSTANCE;

typedef struct HRSRC__ HRSRC__, *PHRSRC__;

typedef struct HRSRC__ *HRSRC;

struct HRSRC__ {
    int unused;
};

typedef HINSTANCE HMODULE;

typedef long *LPLONG;

typedef uint UINT;

typedef struct IMAGE_OPTIONAL_HEADER32 IMAGE_OPTIONAL_HEADER32, *PIMAGE_OPTIONAL_HEADER32;

typedef struct IMAGE_DATA_DIRECTORY IMAGE_DATA_DIRECTORY, *PIMAGE_DATA_DIRECTORY;

struct IMAGE_OPTIONAL_HEADER32 {
    word Magic;
    byte MajorLinkerVersion;
    byte MinorLinkerVersion;
    dword SizeOfCode;
    dword SizeOfInitializedData;
    dword SizeOfUninitializedData;
    ImageBaseOffset32 AddressOfEntryPoint;
    ImageBaseOffset32 BaseOfCode;
    ImageBaseOffset32 BaseOfData;
    pointer32 ImageBase;
    dword SectionAlignment;
    dword FileAlignment;
    word MajorOperatingSystemVersion;
    word MinorOperatingSystemVersion;
    word MajorImageVersion;
    word MinorImageVersion;
    word MajorSubsystemVersion;
    word MinorSubsystemVersion;
    dword Win32VersionValue;
    dword SizeOfImage;
    dword SizeOfHeaders;
    dword CheckSum;
    word Subsystem;
    word DllCharacteristics;
    dword SizeOfStackReserve;
    dword SizeOfStackCommit;
    dword SizeOfHeapReserve;
    dword SizeOfHeapCommit;
    dword LoaderFlags;
    dword NumberOfRvaAndSizes;
    struct IMAGE_DATA_DIRECTORY DataDirectory[16];
};

struct IMAGE_DATA_DIRECTORY {
    ImageBaseOffset32 VirtualAddress;
    dword Size;
};

typedef struct Var Var, *PVar;

struct Var {
    word wLength;
    word wValueLength;
    word wType;
};

typedef struct IMAGE_RESOURCE_DIRECTORY_ENTRY_NameStruct IMAGE_RESOURCE_DIRECTORY_ENTRY_NameStruct, *PIMAGE_RESOURCE_DIRECTORY_ENTRY_NameStruct;

struct IMAGE_RESOURCE_DIRECTORY_ENTRY_NameStruct {
    dword NameOffset:31;
    dword NameIsString:1;
};

typedef struct IMAGE_FILE_HEADER IMAGE_FILE_HEADER, *PIMAGE_FILE_HEADER;

struct IMAGE_FILE_HEADER {
    word Machine; // 332
    word NumberOfSections;
    dword TimeDateStamp;
    dword PointerToSymbolTable;
    dword NumberOfSymbols;
    word SizeOfOptionalHeader;
    word Characteristics;
};

typedef struct IMAGE_NT_HEADERS32 IMAGE_NT_HEADERS32, *PIMAGE_NT_HEADERS32;

struct IMAGE_FILE_HEADER {
    word Machine; // 332
    word NumberOfSections;
    dword TimeDateStamp;
    dword PointerToSymbolTable;
    dword NumberOfSymbols;
    word SizeOfOptionalHeader;
    word Characteristics;
};

struct IMAGE_OPTIONAL_HEADER32 {
    word Magic;
    byte MajorLinkerVersion;
    byte MinorLinkerVersion;
    dword SizeOfCode;
    dword SizeOfInitializedData;
    dword SizeOfUninitializedData;
    ImageBaseOffset32 AddressOfEntryPoint;
    ImageBaseOffset32 BaseOfCode;
    ImageBaseOffset32 BaseOfData;
    pointer32 ImageBase;
    dword SectionAlignment;
    dword FileAlignment;
    word MajorOperatingSystemVersion;
    word MinorOperatingSystemVersion;
    word MajorImageVersion;
    word MinorImageVersion;
    word MajorSubsystemVersion;
    word MinorSubsystemVersion;
    dword Win32VersionValue;
    dword SizeOfImage;
    dword SizeOfHeaders;
    dword CheckSum;
    word Subsystem;
    word DllCharacteristics;
    dword SizeOfStackReserve;
    dword SizeOfStackCommit;
    dword SizeOfHeapReserve;
    dword SizeOfHeapCommit;
    dword LoaderFlags;
    dword NumberOfRvaAndSizes;
    struct IMAGE_DATA_DIRECTORY DataDirectory[16];
};

struct IMAGE_NT_HEADERS32 {
    char Signature[4];
    struct IMAGE_FILE_HEADER FileHeader;
    struct IMAGE_OPTIONAL_HEADER32 OptionalHeader;
};

typedef struct StringFileInfo StringFileInfo, *PStringFileInfo;

struct StringFileInfo {
    word wLength;
    word wValueLength;
    word wType;
};

typedef struct IMAGE_RESOURCE_DIRECTORY_ENTRY IMAGE_RESOURCE_DIRECTORY_ENTRY, *PIMAGE_RESOURCE_DIRECTORY_ENTRY;

typedef union IMAGE_RESOURCE_DIRECTORY_ENTRY_NameUnion IMAGE_RESOURCE_DIRECTORY_ENTRY_NameUnion, *PIMAGE_RESOURCE_DIRECTORY_ENTRY_NameUnion;

union IMAGE_RESOURCE_DIRECTORY_ENTRY_DirectoryUnion {
    dword OffsetToData;
    struct IMAGE_RESOURCE_DIRECTORY_ENTRY_DirectoryStruct IMAGE_RESOURCE_DIRECTORY_ENTRY_DirectoryStruct;
};

struct IMAGE_RESOURCE_DIRECTORY_ENTRY_NameStruct {
    dword NameOffset:31;
    dword NameIsString:1;
};

union IMAGE_RESOURCE_DIRECTORY_ENTRY_NameUnion {
    struct IMAGE_RESOURCE_DIRECTORY_ENTRY_NameStruct IMAGE_RESOURCE_DIRECTORY_ENTRY_NameStruct;
    dword Name;
    word Id;
};

struct IMAGE_RESOURCE_DIRECTORY_ENTRY {
    union IMAGE_RESOURCE_DIRECTORY_ENTRY_NameUnion NameUnion;
    union IMAGE_RESOURCE_DIRECTORY_ENTRY_DirectoryUnion DirectoryUnion;
};

typedef struct StringTable StringTable, *PStringTable;

struct StringTable {
    word wLength;
    word wValueLength;
    word wType;
};

typedef struct IMAGE_SECTION_HEADER IMAGE_SECTION_HEADER, *PIMAGE_SECTION_HEADER;

typedef union Misc Misc, *PMisc;

typedef enum SectionFlags {
    IMAGE_SCN_TYPE_NO_PAD=8,
    IMAGE_SCN_RESERVED_0001=16,
    IMAGE_SCN_CNT_CODE=32,
    IMAGE_SCN_CNT_INITIALIZED_DATA=64,
    IMAGE_SCN_CNT_UNINITIALIZED_DATA=128,
    IMAGE_SCN_LNK_OTHER=256,
    IMAGE_SCN_LNK_INFO=512,
    IMAGE_SCN_RESERVED_0040=1024,
    IMAGE_SCN_LNK_REMOVE=2048,
    IMAGE_SCN_LNK_COMDAT=4096,
    IMAGE_SCN_GPREL=32768,
    IMAGE_SCN_MEM_16BIT=131072,
    IMAGE_SCN_MEM_PURGEABLE=131072,
    IMAGE_SCN_MEM_LOCKED=262144,
    IMAGE_SCN_MEM_PRELOAD=524288,
    IMAGE_SCN_ALIGN_1BYTES=1048576,
    IMAGE_SCN_ALIGN_2BYTES=2097152,
    IMAGE_SCN_ALIGN_4BYTES=3145728,
    IMAGE_SCN_ALIGN_8BYTES=4194304,
    IMAGE_SCN_ALIGN_16BYTES=5242880,
    IMAGE_SCN_ALIGN_32BYTES=6291456,
    IMAGE_SCN_ALIGN_64BYTES=7340032,
    IMAGE_SCN_ALIGN_128BYTES=8388608,
    IMAGE_SCN_ALIGN_256BYTES=9437184,
    IMAGE_SCN_ALIGN_512BYTES=10485760,
    IMAGE_SCN_ALIGN_1024BYTES=11534336,
    IMAGE_SCN_ALIGN_2048BYTES=12582912,
    IMAGE_SCN_ALIGN_4096BYTES=13631488,
    IMAGE_SCN_ALIGN_8192BYTES=14680064,
    IMAGE_SCN_LNK_NRELOC_OVFL=16777216,
    IMAGE_SCN_MEM_DISCARDABLE=33554432,
    IMAGE_SCN_MEM_NOT_CACHED=67108864,
    IMAGE_SCN_MEM_NOT_PAGED=134217728,
    IMAGE_SCN_MEM_SHARED=268435456,
    IMAGE_SCN_MEM_EXECUTE=536870912,
    IMAGE_SCN_MEM_READ=1073741824,
    IMAGE_SCN_MEM_WRITE=2147483648
} SectionFlags;

union Misc {
    dword PhysicalAddress;
    dword VirtualSize;
};

struct IMAGE_SECTION_HEADER {
    char Name[8];
    union Misc Misc;
    ImageBaseOffset32 VirtualAddress;
    dword SizeOfRawData;
    dword PointerToRawData;
    dword PointerToRelocations;
    dword PointerToLinenumbers;
    word NumberOfRelocations;
    word NumberOfLinenumbers;
    enum SectionFlags Characteristics;
};

typedef struct IMAGE_RESOURCE_DIR_STRING_U_8 IMAGE_RESOURCE_DIR_STRING_U_8, *PIMAGE_RESOURCE_DIR_STRING_U_8;

struct IMAGE_RESOURCE_DIR_STRING_U_8 {
    word Length;
    wchar16 NameString[4];
};

typedef struct VS_VERSION_INFO VS_VERSION_INFO, *PVS_VERSION_INFO;

struct VS_VERSION_INFO {
    word StructLength;
    word ValueLength;
    word StructType;
    wchar16 Info[16];
    byte Padding[2];
    dword Signature;
    word StructVersion[2];
    word FileVersion[4];
    word ProductVersion[4];
    dword FileFlagsMask[2];
    dword FileFlags;
    dword FileOS;
    dword FileType;
    dword FileSubtype;
    dword FileTimestamp;
};

typedef struct IMAGE_BASE_RELOCATION IMAGE_BASE_RELOCATION, *PIMAGE_BASE_RELOCATION;

struct IMAGE_BASE_RELOCATION {
    dword VirtualAddress;
    dword SizeOfBlock;
};

typedef struct IMAGE_RESOURCE_DATA_ENTRY IMAGE_RESOURCE_DATA_ENTRY, *PIMAGE_RESOURCE_DATA_ENTRY;

struct IMAGE_RESOURCE_DATA_ENTRY {
    dword OffsetToData;
    dword Size;
    dword CodePage;
    dword Reserved;
};

typedef struct VarFileInfo VarFileInfo, *PVarFileInfo;

struct VarFileInfo {
    word wLength;
    word wValueLength;
    word wType;
};

typedef struct IMAGE_RESOURCE_DIRECTORY IMAGE_RESOURCE_DIRECTORY, *PIMAGE_RESOURCE_DIRECTORY;

struct IMAGE_RESOURCE_DIRECTORY {
    dword Characteristics;
    dword TimeDateStamp;
    word MajorVersion;
    word MinorVersion;
    word NumberOfNamedEntries;
    word NumberOfIdEntries;
};

typedef struct IMAGE_DIRECTORY_ENTRY_EXPORT IMAGE_DIRECTORY_ENTRY_EXPORT, *PIMAGE_DIRECTORY_ENTRY_EXPORT;

struct IMAGE_DIRECTORY_ENTRY_EXPORT {
    dword Characteristics;
    dword TimeDateStamp;
    word MajorVersion;
    word MinorVersion;
    ImageBaseOffset32 Name;
    dword Base;
    dword NumberOfFunctions;
    dword NumberOfNames;
    ImageBaseOffset32 AddressOfFunctions;
    ImageBaseOffset32 AddressOfNames;
    ImageBaseOffset32 AddressOfNameOrdinals;
};

typedef struct StringInfo StringInfo, *PStringInfo;

struct StringInfo {
    word wLength;
    word wValueLength;
    word wType;
};

typedef struct _s_CatchableTypeArray _s_CatchableTypeArray, *P_s_CatchableTypeArray;

typedef struct _s_CatchableTypeArray CatchableTypeArray;

typedef struct _s_CatchableType _s_CatchableType, *P_s_CatchableType;

typedef struct _s_CatchableType CatchableType;


// WARNING! conflicting data type names: /ehdata.h/TypeDescriptor - /TypeDescriptor

typedef struct PMD PMD, *PPMD;

typedef void (*PMFN)(void *);

typedef int ptrdiff_t;

struct _s_CatchableTypeArray {
    int nCatchableTypes;
    CatchableType *arrayOfCatchableTypes[0];
};

struct PMD {
    ptrdiff_t mdisp;
    ptrdiff_t pdisp;
    ptrdiff_t vdisp;
};

struct _s_CatchableType {
    uint properties;
    struct TypeDescriptor *pType;
    struct PMD thisDisplacement;
    int sizeOrOffset;
    PMFN copyFunction;
};

typedef struct _s_ThrowInfo _s_ThrowInfo, *P_s_ThrowInfo;

typedef struct _s_ThrowInfo ThrowInfo;

struct _s_ThrowInfo {
    uint attributes;
    PMFN pmfnUnwind;
    int (*pForwardCompat)(void);
    CatchableTypeArray *pCatchableTypeArray;
};

typedef struct exception exception, *Pexception;

struct exception { // PlaceHolder Structure
};

typedef struct type_info type_info, *Ptype_info;

struct type_info { // PlaceHolder Structure
};

typedef int (*_onexit_t)(void);

typedef uint size_t;



undefined LAB_10001150;
pointer PTR_LAB_10030084;
void *ExceptionList;
undefined LAB_100011d0;
undefined LAB_10001240;
undefined LAB_100012b0;
pointer PTR_LAB_10030094;
undefined LAB_10001330;
undefined LAB_100013a0;
undefined LAB_10001410;
pointer PTR_LAB_100300a4;
undefined LAB_10001490;
undefined LAB_10001500;
undefined LAB_10001570;
undefined LAB_100015f0;
string s_Audio_IFF_1014f550;
undefined DAT_1014f560;
undefined DAT_1014f570;
undefined LAB_10001990;
pointer PTR_LAB_100300b4;
undefined LAB_10001a10;
undefined LAB_10002240;
pointer PTR_LAB_10030074;
undefined1 DAT_1014f600;
undefined LAB_100022b0;
undefined LAB_10002330;
undefined LAB_100028a0;
undefined DAT_10030420;
string s_Uninited_marker_1014f580;
undefined DAT_1014f5b0;
undefined DAT_1014f5e0;
undefined LAB_10002e70;
undefined DAT_1014f5a0;
undefined LAB_10003160;
undefined LAB_100032f0;
undefined DAT_1014f590;
undefined LAB_100034a0;
undefined DAT_100304a0;
undefined LAB_10003690;
undefined LAB_100038e0;
undefined4 DAT_10034544;
undefined4 DAT_10034540;
undefined LAB_10003a70;
pointer PTR_LAB_100304d4;
undefined DAT_10030570;
void *DAT_10034544;
void *DAT_10034540;
undefined LAB_10003f70;
undefined DAT_1014f818;
undefined DAT_1014f7f8;
undefined LAB_10004520;
undefined LAB_100045a0;
undefined4 DAT_1005474c;
undefined DAT_1014f8e4;
undefined4 DAT_10054550;
undefined DAT_10034550;
undefined DAT_10034554;
undefined1 DAT_1014fc50;
pointer PTR_LAB_10030614;
pointer PTR_LAB_10030624;
undefined LAB_10005c90;
pointer PTR_LAB_10030634;
string s_%sSimple_chunk,_type:_%s,_size:_%_1014fc60;
string s_%sDumping_contents_of_'FORM'_chu_1014fc90;
string s_%sDumping_contents_of_'CAT_'_chu_1014fcc0;
string s_%sDumping_contents_of_'LIST'_chu_1014fcf0;
undefined FUN_10004000;
undefined FUN_100040b0;
undefined LAB_10005ec0;
undefined1 DAT_1014fb80;
undefined1 DAT_1014fb88;
undefined1 DAT_1014fb90;
undefined LAB_10006900;
pointer PTR_LAB_100308b4;
undefined LAB_10006980;
undefined LAB_100069f0;
undefined LAB_10006a60;
pointer PTR_LAB_100308a4;
undefined LAB_10006ae0;
undefined LAB_10006b50;
undefined LAB_10006bc0;
pointer PTR_LAB_100308c4;
undefined LAB_10006c40;
undefined LAB_10006cb0;
undefined *PTR_LAB_100307d4;
undefined *PTR_LAB_100307e4;
undefined LAB_10007050;
undefined *PTR_LAB_10030824;
undefined LAB_10007170;
undefined *PTR_LAB_10030864;
undefined LAB_10007910;
undefined LAB_10007b10;
undefined *PTR_LAB_10031d14;
pointer PTR_LAB_10031d34;
undefined LAB_100084c0;
undefined LAB_10008540;
pointer PTR_LAB_10031d24;
undefined LAB_10008810;
undefined LAB_100088b0;
undefined LAB_100089f0;
undefined LAB_10008af0;
undefined LAB_10008b90;
undefined *PTR_LAB_10031d44;
undefined LAB_10008c10;
undefined LAB_10008d70;
undefined *PTR_LAB_10031d54;
undefined LAB_10008e00;
undefined4 DAT_10054760;
undefined LAB_10009280;
undefined LAB_10009860;
undefined LAB_10009940;
pointer PTR_LAB_10030584;
char DAT_100322c0;
undefined LAB_1000a800;
pointer PTR_LAB_100322d4;
pointer PTR_LAB_100322e4;
undefined LAB_1000abf0;
pointer PTR_LAB_100323f4;
undefined LAB_1000ac70;
undefined LAB_1000ace0;
undefined LAB_1000ad50;
pointer PTR_LAB_10032454;
undefined LAB_1000add0;
undefined LAB_1000ae40;
undefined1 DAT_10150f40;
undefined1 DAT_10150f50;
undefined LAB_1000b530;
undefined DAT_100326c0;
undefined LAB_1000b770;
undefined DAT_10032670;
undefined LAB_1000bb00;
undefined LAB_1000bb80;
undefined LAB_1000bc40;
undefined LAB_1000bf30;
undefined LAB_1000bfb0;
undefined LAB_1000c070;
undefined DAT_10150f90;
undefined LAB_1000c4f0;
undefined4 DAT_10150388;
undefined LAB_1000c5f0;
int DAT_10150388;
string s_%s%s%s_10150fa0;
undefined LAB_1000c770;
undefined *PTR_LAB_10032404;
undefined LAB_1000c800;
undefined LAB_1000c8a0;
undefined DAT_10032710;
pointer PTR_LAB_10032014;
undefined LAB_1000d5c0;
undefined LAB_1000d7b0;
undefined LAB_1000d830;
pointer PTR_LAB_10032444;
undefined LAB_1000d8a0;
undefined LAB_1000da50;
pointer PTR_LAB_100327b4;
undefined LAB_1000dac0;
undefined LAB_1000dc70;
undefined LAB_1000de00;
pointer PTR_LAB_10032784;
undefined LAB_1000ded0;
undefined4 DAT_10032770;
DWORD DAT_10054780;
LONG DAT_10054784;
undefined LAB_1000e1e0;
pointer PTR_LAB_10032794;
undefined4 *DAT_10054760;
undefined LAB_1000e290;
undefined LAB_1000e350;
undefined LAB_1000e3c0;
undefined LAB_1000e430;
undefined LAB_1000e4b0;
pointer PTR_LAB_100327d4;
undefined LAB_1000e520;
undefined LAB_1000e590;
undefined LAB_1000e610;
pointer PTR_LAB_100327c4;
undefined LAB_1000e680;
undefined LAB_1000e6f0;
undefined LAB_1000e770;
pointer PTR_LAB_100327a4;
undefined LAB_1000e7e0;
undefined LAB_1000e910;
undefined LAB_1000e980;
undefined LAB_1000eab0;
undefined *PTR_LAB_10032b24;
string s_Comp_%d_10151700;
undefined LAB_1000eb30;
undefined DAT_10151628;
undefined DAT_10151660;
undefined DAT_10151664;
undefined DAT_10151640;
undefined DAT_10151630;
undefined DAT_10151638;
undefined DAT_10151668;
undefined DAT_10151648;
undefined DAT_10151650;
undefined DAT_10151658;
undefined DAT_10151670;
undefined LAB_1000f590;
undefined LAB_1000f6c0;
undefined *PTR_LAB_10032cb4;
string s_5Delay_%d_1015184f;
undefined LAB_1000f740;
undefined DAT_101517c0;
undefined DAT_101517b8;
undefined DAT_101517c8;
undefined DAT_101517cc;
undefined DAT_10054150;
undefined DAT_10054154;
undefined *PTR_LAB_10032db4;
undefined LAB_100102f0;
undefined LAB_10010410;
undefined *PTR_LAB_10032df4;
undefined LAB_100104a0;
undefined *PTR_LAB_10032e34;
undefined LAB_10010520;
undefined *PTR_LAB_10032e74;
undefined LAB_100105a0;
undefined *PTR_LAB_10032eb4;
undefined LAB_10010660;
undefined *PTR_LAB_10032f04;
string s_FTestDevice_%d_101519ff;
undefined LAB_10010800;
undefined *PTR_LAB_10033144;
string s_CDist_%d_10151c0f;
undefined LAB_10010880;
undefined DAT_10151b54;
undefined DAT_10151b4c;
undefined DAT_10151b50;
undefined DAT_10151b20;
undefined DAT_10151b28;
undefined DAT_10151b30;
undefined DAT_10151b38;
undefined DAT_10151b40;
undefined DAT_10151ab8;
char DAT_100d47a0;
undefined DAT_10151bfc;
undefined DAT_10151c00;
undefined DAT_10151c04;
undefined DAT_10151c08;
undefined DAT_10151c0c;
undefined DAT_10151be0;
undefined DAT_10151bf0;
undefined DAT_10151be8;
undefined DAT_100d47a4;
undefined DAT_100d4ba0;
char DAT_100e0128;
undefined LAB_10011b90;
undefined LAB_10011d60;
undefined DAT_100dc7b0;
undefined1 DAT_100dc7b1;
undefined LAB_10012930;
undefined4 DAT_100dc7b2;
undefined DAT_10151f30;
undefined DAT_10151f34;
undefined DAT_10151f3c;
undefined DAT_10151f38;
undefined DAT_10151f40;
undefined DAT_10151f20;
undefined DAT_10151f28;
TypeDescriptor RTTI_Type_Descriptor;
undefined4 DAT_100deec0;
undefined4 DAT_100def08;
undefined DAT_10151f48;
undefined DAT_10151f50;
undefined DAT_10151f58;
undefined DAT_1010012c;
uint DAT_100df894;
undefined1 DAT_100df754;
undefined1 DAT_100df755;
undefined4 DAT_100df794;
undefined DAT_100df798;
undefined DAT_10151f7c;
undefined DAT_10151f78;
undefined DAT_10151f70;
undefined1 DAT_100e00d8;
undefined1 DAT_100e0128;
undefined4 DAT_100e012c;
undefined DAT_100f0128;
undefined4 DAT_100f012c;
undefined LAB_100142b0;
undefined DAT_10014290;
undefined LAB_10014390;
undefined LAB_10014420;
undefined LAB_10014540;
int DAT_10100230;
undefined LAB_10014ae0;
undefined4 DAT_10100230;
undefined LAB_100151e0;
undefined LAB_100153f0;
undefined LAB_10015510;
undefined *PTR_LAB_10033214;
char DAT_1010026c;
undefined LAB_100165d0;
undefined *PTR_LAB_10033ad4;
string s_CPCFInsert_%d_101524c0;
undefined LAB_10016650;
undefined DAT_1015227c;
undefined DAT_10152280;
undefined DAT_10152340;
undefined DAT_10152350;
undefined DAT_101523c0;
undefined DAT_10152358;
undefined DAT_10152360;
undefined DAT_10152368;
undefined DAT_10152370;
undefined DAT_10152378;
undefined DAT_10152380;
undefined DAT_10152388;
undefined DAT_101523c4;
undefined DAT_101523c8;
undefined DAT_10152390;
undefined DAT_10152398;
undefined DAT_10152328;
undefined DAT_101523a0;
undefined DAT_101523a8;
undefined DAT_101523b0;
undefined DAT_101523d0;
undefined DAT_101523cc;
undefined DAT_101523d4;
undefined DAT_101523b8;
undefined DAT_1010c270;
undefined DAT_1010c274;
undefined DAT_1010c278;
undefined DAT_101523f0;
undefined DAT_10152400;
undefined DAT_10152478;
undefined DAT_10152408;
undefined DAT_10152410;
undefined DAT_10152418;
undefined DAT_10152420;
undefined DAT_10152428;
undefined DAT_10152430;
undefined DAT_10152438;
undefined DAT_1015247c;
undefined DAT_10152480;
undefined DAT_10152440;
undefined DAT_10152448;
undefined DAT_101523d8;
undefined DAT_10152450;
undefined DAT_10152458;
undefined DAT_10152460;
undefined DAT_10152468;
undefined DAT_10152488;
undefined DAT_10152484;
undefined DAT_10152470;
undefined DAT_10100270;
undefined DAT_10100274;
undefined DAT_10100278;
undefined LAB_10017bc0;
string s_%s_SEMA_10152640;
string s_%s_EVENT_10152650;
undefined LAB_10017cc0;
undefined LAB_10017d30;
undefined LAB_10017ed0;
undefined LAB_10017f40;
undefined *PTR_LAB_10033ba4;
undefined LAB_10018ab0;
undefined4 *DAT_10118284;
undefined4 *DAT_10118280;
undefined LAB_1001a3d0;
undefined LAB_1001a4f0;
undefined LAB_1001a6a0;
undefined4 DAT_10118280;
undefined4 *DAT_1011d0b0;
undefined LAB_1001abb0;
undefined LAB_1001ac20;
undefined LAB_1001acb0;
int DAT_1011d0b4;
undefined LAB_1001ada0;
undefined4 DAT_1011d0b0;
undefined LAB_1001ae30;
int DAT_1011d0b0;
undefined LAB_1001b060;
undefined LAB_1001b0d0;
undefined LAB_1001b190;
undefined LAB_1001b220;
undefined LAB_1001b310;
string s_ReBirth_Audio_101534d0;
undefined LAB_1001b5b0;
undefined1 DAT_101534e0;
undefined1 DAT_101534f0;
undefined1 DAT_10153500;
undefined1 DAT_10153510;
undefined1 DAT_10153520;
undefined1 DAT_10153530;
undefined1 DAT_10153540;
undefined1 DAT_10153550;
undefined1 DAT_10153560;
undefined1 DAT_10153570;
undefined1 DAT_10153580;
undefined1 DAT_10153590;
undefined1 DAT_101535a0;
undefined1 DAT_101535b0;
undefined1 DAT_101535c0;
undefined1 DAT_101535d0;
undefined1 DAT_101535e0;
undefined1 DAT_101535f0;
undefined LAB_1001b6b0;
string s_ReBirth_DLL->Panel_10152d18;
undefined LAB_1001b760;
string s_ReBirth_panel_loaded_10153620;
undefined LAB_1001b7f0;
undefined1 DAT_10121ed8;
undefined LAB_1001b900;
undefined LAB_1001b970;
undefined LAB_1001ba40;
undefined *PTR_LAB_10033c44;
string s_ReBirth_Panel->DLL_10152ee8;
string s_DLL_Writer_10153600;
string s_DLL_Reader_10153610;
undefined LAB_1001bb00;
undefined LAB_1001bc40;
undefined LAB_1001bcb0;
char DAT_10121ed8;
undefined LAB_1001c7a0;
pointer PTR_LAB_10033c34;
void *DAT_1011d0b4;
undefined LAB_1001ca70;
undefined LAB_1001caf0;
undefined LAB_1001cc30;
undefined DAT_10118290;
undefined LAB_1001cde0;
undefined DAT_1011a9a0;
undefined DAT_1011d0b8;
undefined LAB_1001d310;
undefined DAT_1011d0b9;
undefined DAT_10153164;
undefined DAT_1011f7c8;
undefined LAB_1001d980;
undefined LAB_1001da60;
undefined LAB_1001db50;
undefined LAB_1001dc00;
undefined LAB_1001e0a0;
void *DAT_1011d0b0;
undefined *PTR_FUN_10033d58;
pointer PTR_LAB_10033d54;
undefined DAT_10153640;
undefined DAT_10153648;
undefined DAT_1015364c;
undefined LAB_1001e450;
pointer PTR_LAB_10033d64;
undefined DAT_101536a8;
undefined DAT_101536ac;
undefined LAB_1001e680;
pointer PTR_LAB_10033d74;
undefined DAT_10153710;
undefined LAB_1001e920;
pointer PTR_LAB_10033d84;
undefined DAT_10153768;
int DAT_101245f0;
undefined LAB_1001ed90;
undefined LAB_1001eea0;
undefined DAT_10153808;
undefined DAT_10153810;
undefined LAB_1001f7b0;
undefined LAB_100201d0;
undefined LAB_10020430;
undefined LAB_10020660;
undefined DAT_10121ee0;
undefined LAB_10021710;
undefined LAB_10021830;
void *DAT_101245f0;
void *DAT_10100230;
char DAT_10124700;
undefined DAT_101539c8;
undefined DAT_101539d8;
undefined DAT_10153a58;
undefined DAT_101539e0;
undefined DAT_101539e8;
undefined DAT_101539f0;
undefined DAT_101539f8;
undefined DAT_10153a00;
undefined DAT_10153a08;
undefined DAT_10153a10;
undefined DAT_10153a5c;
undefined DAT_10153a60;
undefined DAT_10153a18;
undefined DAT_10153a20;
undefined DAT_101539a8;
undefined DAT_10153a28;
undefined DAT_10153a30;
undefined DAT_10153a38;
undefined DAT_10153a40;
undefined DAT_10153a48;
undefined DAT_10153a64;
undefined DAT_10153a68;
undefined DAT_10153a50;
undefined DAT_1012b364;
undefined DAT_1012b368;
undefined DAT_1012b36c;
undefined DAT_1012b370;
undefined DAT_10153a6c;
undefined DAT_10153a70;
char DAT_10124704;
undefined DAT_10153a90;
undefined DAT_10153a98;
undefined DAT_10153a80;
undefined DAT_10153ab0;
undefined LAB_10023be0;
undefined *PTR_LAB_10033fd4;
undefined4 DAT_10125364;
undefined LAB_10023c60;
undefined DAT_10153b28;
undefined DAT_10153b30;
undefined DAT_10153b38;
undefined DAT_10153b74;
undefined DAT_10153b48;
undefined DAT_10153b50;
undefined DAT_10153b58;
int DAT_10124708;
undefined DAT_10153b40;
undefined DAT_10033f90;
undefined DAT_10153be8;
undefined DAT_10124710;
undefined DAT_10153bf0;
undefined DAT_1012470c;
undefined DAT_10124714;
undefined DAT_10153c30;
undefined DAT_10153be0;
undefined DAT_10153bf8;
undefined DAT_10153c08;
undefined DAT_10153c00;
undefined DAT_10153c10;
undefined DAT_10153c18;
undefined DAT_10153c20;
undefined DAT_10153c34;
undefined DAT_10153c38;
undefined DAT_10153c28;
undefined DAT_10153c40;
undefined DAT_10153c44;
undefined DAT_10153c48;
undefined DAT_10153c50;
undefined DAT_10153c4c;
undefined LAB_10026e00;
undefined LAB_10026e90;
short DAT_1014ccd8;
undefined DAT_10153ea0;
undefined DAT_10153ea8;
undefined LAB_10027510;
undefined *PTR_LAB_10034154;
undefined2 DAT_1014cbd8;
undefined LAB_10027680;
undefined *PTR_LAB_10153ffc;
undefined *PTR_LAB_10153f98;
undefined *PTR_LAB_10153fa8;
undefined *PTR_LAB_1015401c;
undefined *PTR_LAB_10153fbc;
undefined *PTR_LAB_10154000;
undefined *PTR_LAB_10153fd0;
undefined DAT_10154200;
undefined DAT_10154224;
undefined DAT_10154228;
undefined DAT_10154218;
short DAT_1014cbd0;
undefined DAT_100340e4;
undefined DAT_10034104;
undefined DAT_1015422c;
byte DAT_1014cbd4;
undefined DAT_10154230;
undefined DAT_10034090;
undefined DAT_1003409c;
undefined DAT_100340dc;
short DAT_1014e68c;
undefined DAT_101542a0;
undefined DAT_101542b0;
undefined DAT_1015431c;
undefined DAT_101542a8;
undefined LAB_1002a950;
undefined *PTR_LAB_10034294;
undefined2 DAT_1014e54c;
undefined DAT_1014e64c;
undefined LAB_1002aab0;
undefined DAT_101545d0;
undefined DAT_101545d8;
undefined DAT_101545d4;
undefined DAT_101545dc;
undefined DAT_101545e4;
undefined DAT_101545f8;
undefined DAT_10154600;
undefined DAT_101545fc;
undefined DAT_10154604;
undefined DAT_10154608;
undefined DAT_1015460c;
undefined DAT_1014e544;
undefined DAT_10154644;
undefined DAT_10154638;
undefined DAT_10034264;
undefined DAT_10154648;
undefined DAT_1015464c;
byte DAT_1014e548;
undefined DAT_10034210;
undefined DAT_1003421c;
undefined DAT_1003425c;
undefined DAT_10034358;
undefined DAT_10034368;
undefined DAT_100343c8;
undefined DAT_100343b8;
undefined DAT_100343c0;
undefined DAT_100343a8;
undefined DAT_100343b0;
undefined DAT_10034370;
undefined DAT_10034378;
undefined DAT_100343a0;
undefined DAT_10034360;
undefined DAT_10034390;
undefined DAT_10034398;
undefined DAT_10034380;
undefined DAT_10034388;
undefined DAT_10034350;
undefined DAT_10156000;
undefined DAT_10156410;
undefined DAT_10156818;
undefined DAT_10155080;
undefined DAT_1015506c;
undefined DAT_10155076;
undefined DAT_10155060;
undefined DAT_1015504c;
undefined DAT_10155032;
undefined DAT_10155028;
double DAT_10155018;
double DAT_1015503c;
undefined DAT_1002ead8;
undefined DAT_1002f138;
undefined DAT_1002f148;
undefined DAT_1002f158;
int DAT_1014e690;
undefined *PTR__adjust_fdiv_1002f0b0;
undefined DAT_1014e694;
undefined4 *DAT_1014e6a0;
undefined4 *DAT_1014e69c;
undefined DAT_10030000;
undefined DAT_10030060;
undefined *DAT_1014e698;

void __fastcall FUN_100010f0(exception *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10001150;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  exception::exception(param_1);
  *(undefined ***)param_1 = &PTR_LAB_10030084;
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_10001160(exception *param_1,exception *param_2)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_100011d0;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  exception::exception(param_1,param_2);
  *(undefined ***)param_1 = &PTR_LAB_10030084;
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_100011e0(exception *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10001240;
  local_10 = ExceptionList;
  local_8 = 0xffffffff;
  ExceptionList = &local_10;
  exception::~exception(param_1);
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_10001250(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_100012b0;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_100010f0();
  *param_1 = &PTR_LAB_10030094;
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_100012c0(undefined4 *param_1,undefined4 param_2)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10001330;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10001160(param_2);
  *param_1 = &PTR_LAB_10030094;
  ExceptionList = local_10;
  return;
}



void FUN_10001340(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_100013a0;
  local_10 = ExceptionList;
  local_8 = 0xffffffff;
  ExceptionList = &local_10;
  FUN_100011e0();
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_100013b0(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10001410;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_100010f0();
  *param_1 = &PTR_LAB_100300a4;
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_10001420(undefined4 *param_1,undefined4 param_2)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10001490;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10001160(param_2);
  *param_1 = &PTR_LAB_100300a4;
  ExceptionList = local_10;
  return;
}



void FUN_100014a0(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10001500;
  local_10 = ExceptionList;
  local_8 = 0xffffffff;
  ExceptionList = &local_10;
  FUN_100011e0();
  ExceptionList = local_10;
  return;
}



void FUN_10001510(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10001570;
  local_10 = ExceptionList;
  local_8 = 0xffffffff;
  ExceptionList = &local_10;
  FUN_100081b0();
  ExceptionList = local_10;
  return;
}



undefined4 __fastcall FUN_10001580(undefined4 param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_100015f0;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10008160(s_Audio_IFF_1014f550,&DAT_1014f560,&DAT_1014f570);
  ExceptionList = local_10;
  return param_1;
}



void __thiscall FUN_10001674(undefined2 *param_1,int param_2)

{
  undefined2 uVar1;
  undefined4 uVar2;
  float10 fVar3;
  undefined4 uStack_1c;
  
  uVar1 = FUN_10004060(param_2);
  *param_1 = uVar1;
  uVar2 = FUN_100040b0(param_2 + 2);
  *(undefined4 *)(param_1 + 2) = uVar2;
  uVar1 = FUN_10004060(param_2 + 6);
  param_1[4] = uVar1;
  fVar3 = (float10)FUN_10004110(param_2 + 8);
  uStack_1c = (undefined4)(longlong)ROUND(fVar3);
  *(undefined4 *)(param_1 + 6) = uStack_1c;
  return;
}



undefined4 __fastcall FUN_100016f4(short *param_1)

{
  if ((((*param_1 == 0) || (*(int *)(param_1 + 2) == 0)) || ((ushort)param_1[4] < 8)) ||
     ((0x20 < (ushort)param_1[4] || (*(int *)(param_1 + 6) == 0)))) {
    return 0;
  }
  return 1;
}



void __thiscall FUN_10001774(undefined4 *param_1,int param_2)

{
  undefined4 uVar1;
  
  uVar1 = FUN_100040b0(param_2);
  *param_1 = uVar1;
  uVar1 = FUN_100040b0(param_2 + 4);
  param_1[1] = uVar1;
  return;
}



undefined1 * __fastcall FUN_100017a4(undefined1 *param_1)

{
  *(undefined2 *)(param_1 + 6) = 0;
  param_1[5] = 0;
  param_1[4] = 0;
  param_1[3] = 0;
  param_1[2] = 0;
  param_1[1] = 0;
  *param_1 = 0;
  return param_1;
}



void __thiscall FUN_10001844(undefined1 *param_1,undefined1 *param_2)

{
  undefined2 uVar1;
  
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  uVar1 = FUN_10004060(param_2 + 6);
  *(undefined2 *)(param_1 + 6) = uVar1;
  FUN_10003708();
  FUN_10003708();
  return;
}



void __fastcall FUN_10001930(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10001990;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10004ba0();
  *param_1 = &PTR_LAB_100300b4;
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_100019a0(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10001a10;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  *param_1 = &PTR_LAB_100300b4;
  local_8 = 0xffffffff;
  FUN_10004bc0();
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_100021d0(undefined4 *param_1,undefined4 param_2)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10002240;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10004eb0(param_2,&DAT_1014f600);
  *param_1 = &PTR_LAB_10030074;
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_10002250(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_100022b0;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10004e90();
  *param_1 = &PTR_LAB_10030074;
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_100022c0(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10002330;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  *param_1 = &PTR_LAB_10030074;
  local_8 = 0xffffffff;
  FUN_10004ef0();
  ExceptionList = local_10;
  return;
}



void FUN_10002340(char *param_1,int param_2)

{
  bool bVar1;
  char cVar2;
  undefined2 uVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  undefined2 *puVar8;
  char *pcVar9;
  char *pcVar10;
  char *pcVar11;
  undefined1 auStackY_180 [128];
  ushort local_c8 [2];
  undefined2 *local_c4;
  undefined2 *local_c0;
  char local_bc;
  char local_bb;
  short local_b4;
  ushort local_b2;
  ushort local_b0;
  ushort local_a8;
  ushort local_a4;
  undefined1 local_a0 [12];
  uint local_94;
  undefined1 local_90 [20];
  undefined1 local_7c [12];
  undefined1 local_70 [12];
  undefined1 local_64 [12];
  char *local_58;
  uint local_54;
  void *local_50;
  uint local_4c;
  uint local_48;
  uint local_44;
  ushort *local_40;
  undefined1 *local_3c;
  undefined1 *local_38;
  undefined1 *local_34;
  undefined1 *local_30;
  undefined2 *local_2c;
  void *local_28;
  undefined1 *local_20;
  undefined4 local_1c;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_100028a0;
  local_10 = ExceptionList;
  local_14 = auStackY_180 + 0x8c;
  local_20 = local_90;
  ExceptionList = &local_10;
  FUN_100017a4();
  local_40 = local_c8;
  local_c8[0] = 0;
  local_c4 = (undefined2 *)0x0;
  local_c0 = (undefined2 *)0x0;
  local_8 = 1;
  param_1[0xc] = '\r';
  param_1[0xd] = '\0';
  param_1[0xe] = '\0';
  param_1[0xf] = '\0';
  cVar2 = FUN_10004f00(&DAT_1014f5b0,local_20,0x14);
  if (cVar2 == '\0') {
    ExceptionList = local_10;
    return;
  }
  FUN_10001844(local_20);
  if (local_bc == '\0') {
    *param_1 = '<';
    param_1[1] = '\0';
  }
  else {
    *param_1 = local_bc;
    param_1[1] = local_bb;
  }
  param_1[2] = '\x01';
  cVar2 = FUN_10005220(&DAT_1014f5e0,&local_94);
  if (cVar2 != '\0') {
    local_50 = operator_new(local_94);
    local_28 = local_50;
    cVar2 = FUN_10004f00(&DAT_1014f5e0,local_50,local_94);
    if (cVar2 == '\0') {
      FUN_1002dde0(local_28);
      local_38 = local_7c;
      local_50 = (void *)0x0;
      FUN_10001250();
                    // WARNING: Subroutine does not return
      _CxxThrowException(local_38,(ThrowInfo *)&DAT_10030420);
    }
    local_c8[0] = FUN_10004060(local_50);
    uVar7 = (uint)local_c8[0];
    local_c4 = operator_new(uVar7 * 0x108);
    local_54 = uVar7;
    if (uVar7 != 0) {
      local_58 = (char *)(local_c4 + 4);
      local_1c = 2;
      puVar8 = local_c4;
      do {
        *(undefined4 *)(puVar8 + 2) = 0;
        *puVar8 = 0;
        pcVar10 = s_Uninited_marker_1014f580;
        pcVar9 = local_58;
        do {
          cVar2 = *pcVar10;
          pcVar10 = pcVar10 + 1;
          *pcVar9 = cVar2;
          pcVar9 = pcVar9 + 1;
        } while (cVar2 != '\0');
        local_54 = local_54 - 1;
        local_58 = local_58 + 0x108;
        puVar8 = puVar8 + 0x84;
      } while (local_54 != 0);
      local_54 = 0;
    }
    pcVar9 = (char *)0x2;
    local_4c = 0;
    pcVar10 = pcVar9;
    local_2c = local_c4;
    if (local_c8[0] != 0) {
      do {
        uVar3 = FUN_10004060((char *)((int)local_50 + (int)pcVar9),pcVar10);
        uVar7 = local_4c;
        local_c4[local_4c * 0x84] = uVar3;
        uVar4 = FUN_100040b0(pcVar9 + (int)local_50 + 2);
        *(undefined4 *)(local_c4 + uVar7 * 0x84 + 2) = uVar4;
        FUN_10009120(pcVar9 + (int)local_50 + 6,local_c4 + uVar7 * 0x84 + 4);
        iVar5 = -1;
        pcVar11 = (char *)(local_c4 + uVar7 * 0x84 + 4);
        do {
          pcVar10 = pcVar11;
          if (iVar5 == 0) break;
          iVar5 = iVar5 + -1;
          pcVar10 = pcVar11 + 1;
          cVar2 = *pcVar11;
          pcVar11 = pcVar10;
        } while (cVar2 != '\0');
        pcVar9 = pcVar9 + (5 - iVar5);
        if (((uint)pcVar9 & 1) != 0) {
          pcVar9 = pcVar9 + 1;
        }
        local_4c = local_4c + 1 & 0xffff;
      } while (local_4c < local_c8[0]);
    }
    FUN_1002dde0(local_50,pcVar10);
    if ((1 < local_c8[0]) && (local_c0 = local_c4, local_c4 == (undefined2 *)0x0)) {
      local_3c = local_a0;
      FUN_10001250();
                    // WARNING: Subroutine does not return
      _CxxThrowException(local_3c,(ThrowInfo *)&DAT_10030420);
    }
  }
  if (local_c0 != (undefined2 *)0x0) {
    iVar5 = 0;
    uVar7 = (uint)local_b2;
    if (0 < (short)local_c8[0]) {
      do {
        local_48 = uVar7;
        if ((ushort)local_c4[iVar5 * 0x84] == uVar7) {
          local_a4 = (ushort)iVar5;
          bVar1 = true;
          goto LAB_100026c4;
        }
        iVar5 = (iVar5 + 1) * 0x10000 >> 0x10;
      } while (iVar5 < (short)local_c8[0]);
    }
    bVar1 = false;
LAB_100026c4:
    if (!bVar1) {
      local_30 = local_70;
      FUN_10001250();
                    // WARNING: Subroutine does not return
      _CxxThrowException(local_30,(ThrowInfo *)&DAT_10030420);
    }
    iVar5 = 0;
    uVar7 = (uint)local_b0;
    if (0 < (short)local_c8[0]) {
      do {
        local_44 = uVar7;
        if ((ushort)local_c4[iVar5 * 0x84] == uVar7) {
          local_a8 = (ushort)iVar5;
          bVar1 = true;
          goto LAB_10002739;
        }
        iVar5 = (iVar5 + 1) * 0x10000 >> 0x10;
      } while (iVar5 < (short)local_c8[0]);
    }
    bVar1 = false;
LAB_10002739:
    if (!bVar1) {
      local_34 = local_64;
      FUN_10001250();
                    // WARNING: Subroutine does not return
      _CxxThrowException(local_34,(ThrowInfo *)&DAT_10030420);
    }
    iVar5 = *(int *)(local_c0 + (uint)local_a4 * 0x84 + 2);
    iVar6 = *(int *)(local_c0 + (uint)local_a8 * 0x84 + 2);
    if (local_b4 == 0) {
      uVar4 = 0xe;
      param_1[0xc] = '\x0e';
      param_1[0xd] = '\0';
      param_1[0xe] = '\0';
      param_1[0xf] = '\0';
    }
    else {
      uVar4 = 0xf;
      param_1[0xc] = '\x0f';
      param_1[0xd] = '\0';
      param_1[0xe] = '\0';
      param_1[0xf] = '\0';
    }
    if (iVar5 < 0) {
      iVar5 = 0;
      param_1[0xc] = '\x0e';
      param_1[0xd] = '\0';
      param_1[0xe] = '\0';
      param_1[0xf] = '\0';
    }
    if (param_2 < iVar6) {
      param_1[0xc] = '\x0e';
      param_1[0xd] = '\0';
      param_1[0xe] = '\0';
      param_1[0xf] = '\0';
      iVar6 = param_2;
    }
    if (iVar6 <= iVar5) {
      iVar5 = 0;
      param_1[0xc] = '\r';
      param_1[0xd] = '\0';
      param_1[0xe] = '\0';
      param_1[0xf] = '\0';
      iVar6 = 0;
    }
    *(int *)(param_1 + 8) = iVar6;
    *(int *)(param_1 + 4) = iVar5;
    FUN_1002dde0(local_c0,uVar4);
  }
  ExceptionList = local_10;
  return;
}



void FUN_100028b0(void)

{
  bool bVar1;
  char cVar2;
  undefined2 uVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  undefined2 *puVar7;
  char *pcVar8;
  char *pcVar9;
  char *pcVar10;
  int iVar11;
  undefined1 auStackY_190 [128];
  undefined1 local_d8 [20];
  undefined2 *local_c4;
  ushort local_c0;
  ushort local_bc;
  char local_b8;
  char local_b7;
  short local_b0;
  ushort local_ae;
  ushort local_ac;
  undefined1 local_a4 [12];
  ushort local_98 [2];
  undefined2 *local_94;
  uint local_90;
  undefined1 local_8c [16];
  undefined1 local_7c [12];
  undefined1 local_70 [12];
  char *local_64;
  uint local_60;
  void *local_5c;
  uint local_58;
  uint local_54;
  uint local_50;
  ushort *local_4c;
  undefined1 *local_48;
  undefined1 *local_44;
  undefined1 *local_40;
  undefined1 *local_3c;
  uint local_38;
  undefined2 *local_34;
  void *local_30;
  int local_2c;
  int local_24;
  undefined1 *local_20;
  int local_1c;
  undefined4 local_18;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10002e70;
  local_10 = ExceptionList;
  local_14 = auStackY_190 + 0x8c;
  local_20 = local_d8;
  ExceptionList = &local_10;
  FUN_100017a4();
  local_4c = local_98;
  local_94 = (undefined2 *)0x0;
  local_98[0] = 0;
  local_c4 = (undefined2 *)0x0;
  local_8 = 1;
  cVar2 = FUN_10004f00(&DAT_1014f5b0,local_20,0x14);
  if (cVar2 == '\0') {
    ExceptionList = local_10;
    return;
  }
  FUN_10001844(local_20);
  local_38 = (uint)(local_b0 != 0);
  if (local_b8 == '\0') {
    FUN_1000a940(0x3c);
    FUN_1000a950(0);
    FUN_1000a960(1);
  }
  else {
    FUN_1000a940(local_b8);
    FUN_1000a950((int)local_b7);
    FUN_1000a960(1);
  }
  cVar2 = FUN_10005220(&DAT_1014f5e0,&local_90);
  if (cVar2 != '\0') {
    local_5c = operator_new(local_90);
    local_30 = local_5c;
    cVar2 = FUN_10004f00(&DAT_1014f5e0,local_5c,local_90);
    if (cVar2 == '\0') {
      FUN_1002dde0(local_30);
      local_44 = local_8c;
      local_5c = (void *)0x0;
      FUN_10001250();
                    // WARNING: Subroutine does not return
      _CxxThrowException(local_44,(ThrowInfo *)&DAT_10030420);
    }
    local_98[0] = FUN_10004060(local_5c);
    uVar6 = (uint)local_98[0];
    local_94 = operator_new(uVar6 * 0x108);
    local_60 = uVar6;
    if (uVar6 != 0) {
      local_64 = (char *)(local_94 + 4);
      local_18 = 2;
      puVar7 = local_94;
      do {
        *(undefined4 *)(puVar7 + 2) = 0;
        *puVar7 = 0;
        pcVar9 = s_Uninited_marker_1014f580;
        pcVar8 = local_64;
        do {
          cVar2 = *pcVar9;
          pcVar9 = pcVar9 + 1;
          *pcVar8 = cVar2;
          pcVar8 = pcVar8 + 1;
        } while (cVar2 != '\0');
        local_60 = local_60 - 1;
        local_64 = local_64 + 0x108;
        puVar7 = puVar7 + 0x84;
      } while (local_60 != 0);
      local_60 = 0;
    }
    pcVar8 = (char *)0x2;
    local_58 = 0;
    pcVar9 = pcVar8;
    local_34 = local_94;
    if (local_98[0] != 0) {
      do {
        uVar3 = FUN_10004060((char *)((int)local_5c + (int)pcVar8),pcVar9);
        uVar6 = local_58;
        local_94[local_58 * 0x84] = uVar3;
        uVar4 = FUN_100040b0(pcVar8 + (int)local_5c + 2);
        *(undefined4 *)(local_94 + uVar6 * 0x84 + 2) = uVar4;
        FUN_10009120(pcVar8 + (int)local_5c + 6,local_94 + uVar6 * 0x84 + 4);
        iVar5 = -1;
        pcVar10 = (char *)(local_94 + uVar6 * 0x84 + 4);
        do {
          pcVar9 = pcVar10;
          if (iVar5 == 0) break;
          iVar5 = iVar5 + -1;
          pcVar9 = pcVar10 + 1;
          cVar2 = *pcVar10;
          pcVar10 = pcVar9;
        } while (cVar2 != '\0');
        pcVar8 = pcVar8 + (5 - iVar5);
        if (((uint)pcVar8 & 1) != 0) {
          pcVar8 = pcVar8 + 1;
        }
        local_58 = local_58 + 1 & 0xffff;
      } while (local_58 < local_98[0]);
    }
    FUN_1002dde0(local_5c,pcVar9);
    if ((1 < local_98[0]) && (local_c4 = local_94, local_94 == (undefined2 *)0x0)) {
      local_48 = local_a4;
      FUN_10001250();
                    // WARNING: Subroutine does not return
      _CxxThrowException(local_48,(ThrowInfo *)&DAT_10030420);
    }
  }
  if (local_c4 != (undefined2 *)0x0) {
    iVar5 = 0;
    uVar6 = (uint)local_ae;
    if (0 < (short)local_98[0]) {
      do {
        local_54 = uVar6;
        if ((ushort)local_94[iVar5 * 0x84] == uVar6) {
          local_bc = (ushort)iVar5;
          bVar1 = true;
          goto LAB_10002c9d;
        }
        iVar5 = (iVar5 + 1) * 0x10000 >> 0x10;
      } while (iVar5 < (short)local_98[0]);
    }
    bVar1 = false;
LAB_10002c9d:
    if (!bVar1) {
      local_3c = local_7c;
      FUN_10001250();
                    // WARNING: Subroutine does not return
      _CxxThrowException(local_3c,(ThrowInfo *)&DAT_10030420);
    }
    iVar11 = (int)(short)local_98[0];
    iVar5 = 0;
    uVar6 = (uint)local_ac;
    if (0 < iVar11) {
      do {
        local_50 = uVar6;
        if ((ushort)local_94[iVar5 * 0x84] == uVar6) {
          local_c0 = (ushort)iVar5;
          bVar1 = true;
          goto LAB_10002d12;
        }
        iVar5 = (iVar5 + 1) * 0x10000 >> 0x10;
      } while (iVar5 < iVar11);
    }
    bVar1 = false;
LAB_10002d12:
    if (!bVar1) {
      local_40 = local_70;
      FUN_10001250();
                    // WARNING: Subroutine does not return
      _CxxThrowException(local_40,(ThrowInfo *)&DAT_10030420);
    }
    local_2c = *(int *)(local_c4 + (uint)local_c0 * 0x84 + 2);
    local_1c = *(int *)(local_c4 + (uint)local_bc * 0x84 + 2);
    if (local_1c < 0) {
      local_38 = 0;
      local_1c = 0;
    }
    local_24 = local_2c;
    iVar5 = FUN_1000aa80();
    if (iVar5 < local_24) {
      local_2c = FUN_1000aa80();
      local_38 = 0;
    }
    FUN_1000a8b0(local_1c,local_2c,local_38);
    if (local_c4 != (undefined2 *)0x0) {
      FUN_1002dde0(local_c4,iVar11);
    }
  }
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_10002e84(int param_1,undefined4 param_2,ushort param_3,ushort param_4)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined1 auStack_30 [8];
  undefined1 local_28 [12];
  int local_1c;
  undefined1 auStack_14 [4];
  
  cVar1 = FUN_10004f00(&DAT_1014f5a0,auStack_30,8);
  if (cVar1 == '\0') {
    FUN_10001250();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_28,(ThrowInfo *)&DAT_10030420);
  }
  FUN_10001774(auStack_30);
  if (0 < local_1c) {
    (**(code **)(**(int **)(param_1 + 0xc) + 0x2c))(local_1c);
  }
  if (param_4 == param_3) {
    uVar2 = FUN_1000aa70();
    uVar3 = FUN_1000aa80();
    FUN_10009f40(*(undefined4 *)(param_1 + 0xc),uVar2,2,param_3 & 0xff,uVar3,1,auStack_14);
    return;
  }
  uVar2 = FUN_1000aa70();
  uVar3 = FUN_1000aa80();
  FUN_10009c60(*(undefined4 *)(param_1 + 0xc),uVar2,2,param_3 & 0xff,param_4 & 0xff,uVar3,1);
  return;
}



void __thiscall
FUN_10002fc4(int param_1,undefined4 param_2,ushort param_3,undefined1 param_4,int param_5)

{
  char cVar1;
  undefined4 uVar2;
  undefined1 auStack_30 [8];
  undefined1 local_28 [12];
  int local_1c;
  
  cVar1 = FUN_10004f00(&DAT_1014f5a0,auStack_30,8);
  if (cVar1 == '\0') {
    FUN_10001250();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_28,(ThrowInfo *)&DAT_10030420);
  }
  FUN_10001774(auStack_30);
  if (0 < local_1c) {
    (**(code **)(**(int **)(param_1 + 0xc) + 0x2c))(local_1c);
  }
  if (param_3 == 1) {
    uVar2 = FUN_10007210();
    (**(code **)(**(int **)(param_1 + 0xc) + 4))(param_5 * 2,uVar2);
    FUN_10009990(uVar2,param_5);
    return;
  }
  FUN_10009dd0(*(undefined4 *)(param_1 + 0xc),param_2,2,param_3 & 0xff,param_4,param_5,1);
  return;
}



void FUN_100030e0(undefined4 param_1,undefined4 param_2)

{
  undefined1 auStackY_bc [128];
  undefined1 local_1c [8];
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10003160;
  local_10 = ExceptionList;
  local_14 = auStackY_bc + 0x88;
  ExceptionList = &local_10;
  FUN_1000c700(param_1);
  local_8 = 0;
  FUN_10003170(local_1c,param_2);
  local_8 = 0xffffffff;
  FUN_1000c810();
  ExceptionList = local_10;
  return;
}



void FUN_10003170(int *param_1,undefined1 *param_2)

{
  char cVar1;
  undefined1 auStack_7a [34];
  undefined1 local_58 [12];
  undefined1 local_4c [12];
  undefined2 local_40;
  undefined4 local_3c;
  ushort local_38;
  undefined4 local_34;
  undefined1 local_30 [20];
  undefined4 local_1c;
  undefined1 *local_18;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_100032f0;
  local_10 = ExceptionList;
  local_14 = auStack_7a + -0x12;
  local_18 = local_30;
  local_40 = 0;
  local_3c = 0;
  local_38 = 0;
  local_34 = 0;
  local_8 = 0;
  ExceptionList = &local_10;
  local_1c = (**(code **)(*param_1 + 0x10))();
  FUN_100021d0(param_1);
  local_8 = 1;
  cVar1 = FUN_10004f40(&DAT_1014f590,local_18,0,0x12);
  if (cVar1 == '\0') {
    FUN_10001250();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_58,(ThrowInfo *)&DAT_10030420);
  }
  FUN_10001674(local_18);
  cVar1 = FUN_100016f4();
  if (cVar1 == '\0') {
    FUN_10001250();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_4c,(ThrowInfo *)&DAT_10030420);
  }
  (**(code **)(*param_1 + 0x14))(local_1c);
  *param_2 = (undefined1)local_40;
  param_2[1] = (char)local_38;
  *(undefined4 *)(param_2 + 4) = local_34;
  *(undefined4 *)(param_2 + 8) = local_3c;
  param_2[0x18] = (local_38 & 0xff) == 0x10;
  *(undefined4 *)(param_2 + 0x14) = 0;
  *(undefined4 *)(param_2 + 0x10) = 0;
  param_2[0xd] = 0;
  param_2[0xc] = 0;
  local_8 = 0;
  FUN_100022c0();
  ExceptionList = local_10;
  return;
}



void * FUN_10003300(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined1 auStack_7a [34];
  undefined1 local_58 [4];
  undefined4 local_54;
  undefined4 local_50;
  char local_40;
  undefined1 local_3c [20];
  undefined1 *local_28;
  void *local_24;
  undefined1 *local_20;
  void *local_1c;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_100034a0;
  local_10 = ExceptionList;
  local_14 = auStack_7a + -0x12;
  local_8 = 0;
  ExceptionList = &local_10;
  FUN_100021d0(param_1);
  local_8 = 1;
  local_20 = local_58;
  FUN_1000a610();
  local_8 = 2;
  FUN_10003170(param_1,local_20);
  if (local_40 == '\0') {
    local_28 = local_3c;
    FUN_100013b0();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_28,(ThrowInfo *)&DAT_100304a0);
  }
  local_1c = operator_new(0x58);
  if (local_1c == (void *)0x0) {
    local_24 = (void *)0x0;
  }
  else {
    FUN_1000a9c0(param_2,local_54,local_50);
    local_24 = local_1c;
  }
  uVar1 = FUN_1000aa70();
  FUN_10002fc4(uVar1,local_58[0],0,local_50);
  local_8 = 1;
  FUN_10012c00();
  local_8 = 0;
  FUN_100022c0();
  ExceptionList = local_10;
  return local_24;
}



void FUN_100034b0(undefined4 param_1,undefined1 param_2,undefined4 *param_3)

{
  void *pvVar1;
  undefined1 auStack_18a [22];
  undefined1 local_174 [280];
  undefined1 local_5c [4];
  undefined4 local_58;
  undefined4 local_54;
  char local_44;
  undefined1 local_40 [8];
  undefined1 local_38 [20];
  undefined1 *local_24;
  undefined1 *local_20;
  undefined1 *local_1c;
  void *local_18;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10003690;
  local_10 = ExceptionList;
  local_14 = auStack_18a + -0x12;
  local_24 = local_174;
  local_1c = local_5c;
  ExceptionList = &local_10;
  FUN_1000a610();
  *param_3 = 0;
  local_8 = 1;
  FUN_100030e0(param_1,local_1c);
  if (local_44 == '\0') {
    local_20 = local_38;
    FUN_100013b0();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_100304a0);
  }
  FUN_1000c700(param_1);
  local_8 = 2;
  FUN_100021d0(local_40);
  local_8 = 3;
  FUN_1000c0d0(local_24);
  local_18 = operator_new(0x68);
  if (local_18 == (void *)0x0) {
    pvVar1 = (void *)0x0;
  }
  else {
    FUN_1000a6c0(local_24,local_58,local_54,0,0,0);
    pvVar1 = local_18;
  }
  *param_3 = pvVar1;
  FUN_10002e84(pvVar1,local_5c[0],param_2);
  FUN_100028b0(*param_3);
  local_8 = 2;
  FUN_100022c0();
  local_8 = 1;
  FUN_1000c810();
  local_8 = 0xffffffff;
  FUN_10012c00();
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_10003708(undefined4 param_1,int param_2)

{
  undefined2 uVar1;
  undefined2 *in_EAX;
  
  uVar1 = FUN_10004060(param_2);
  *in_EAX = uVar1;
  uVar1 = FUN_10004060(param_2 + 2);
  in_EAX[1] = uVar1;
  uVar1 = FUN_10004060(param_2 + 4);
  in_EAX[2] = uVar1;
  return;
}



undefined4 FUN_100037a0(undefined4 param_1,int param_2,undefined4 *param_3,uint param_4,int param_5)

{
  uint uVar1;
  undefined4 *puVar2;
  
  puVar2 = (undefined4 *)(param_5 + param_2);
  for (uVar1 = param_4 >> 2; uVar1 != 0; uVar1 = uVar1 - 1) {
    *param_3 = *puVar2;
    puVar2 = puVar2 + 1;
    param_3 = param_3 + 1;
  }
  for (param_4 = param_4 & 3; param_4 != 0; param_4 = param_4 - 1) {
    *(undefined1 *)param_3 = *(undefined1 *)puVar2;
    puVar2 = (undefined4 *)((int)puVar2 + 1);
    param_3 = (undefined4 *)((int)param_3 + 1);
  }
  return 1;
}



undefined4
FUN_10003860(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_100038e0;
  local_10 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_10;
  (**(code **)(*param_5 + 4))(param_4,param_3);
  ExceptionList = local_10;
  return 1;
}



undefined4 FUN_10003920(void)

{
  return DAT_10034544;
}



undefined4 FUN_10003930(void)

{
  return DAT_10034540;
}



undefined4 * __thiscall FUN_10003940(undefined4 *param_1,undefined4 param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  undefined4 *puVar5;
  uint local_1c;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10003a70;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  *param_1 = &PTR_LAB_100304d4;
  param_1[1] = 0x57a51555;
  param_1[2] = param_2;
  param_1[3] = 0;
  param_1[4] = 0;
  uVar1 = 0;
  do {
    uVar4 = uVar1 + 1;
    param_1[uVar1 + 5] = 0;
    uVar1 = uVar4;
  } while (uVar4 < 0xff6);
  param_1[0xffb] = 0xe2de2de2;
  local_8 = 0;
  uVar1 = FUN_10003ae4();
  local_1c = 0;
  if (uVar1 != 0) {
    do {
      puVar2 = operator_new(0x4000);
      puVar5 = puVar2;
      for (iVar3 = 0x1000; iVar3 != 0; iVar3 = iVar3 + -1) {
        *puVar5 = 0;
        puVar5 = puVar5 + 1;
      }
      uVar4 = local_1c + 1;
      param_1[local_1c + 5] = puVar2;
      local_1c = uVar4;
    } while (uVar4 < uVar1);
  }
  ExceptionList = local_10;
  return param_1;
}



void __fastcall FUN_10003a84(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  *param_1 = &PTR_LAB_100304d4;
  puVar1 = param_1;
  do {
    FUN_1002dde0(puVar1[5]);
    puVar1[5] = 0;
    puVar1 = puVar1 + 1;
  } while (puVar1 < param_1 + 0xff6);
  param_1[2] = 0;
  return;
}



undefined4 __fastcall FUN_10003ad0(int param_1)

{
  return *(undefined4 *)(param_1 + 8);
}



uint __fastcall FUN_10003ae4(int param_1)

{
  uint uVar1;
  
  uVar1 = *(uint *)(param_1 + 8) >> 0xe;
  if (uVar1 << 0xe < *(uint *)(param_1 + 8)) {
    uVar1 = uVar1 + 1;
  }
  return uVar1;
}



void __thiscall FUN_10003b00(int param_1,uint param_2,uint param_3,undefined4 param_4)

{
  uint uVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  undefined1 local_40 [12];
  undefined1 local_34 [12];
  undefined1 local_28 [12];
  uint local_1c;
  uint local_18;
  
  local_18 = param_2 >> 0xe;
  iVar3 = param_2 + local_18 * -0x4000;
  uVar4 = local_18;
  uVar1 = 0;
  if (iVar3 != 0) {
    local_1c = 0x4000U - iVar3 & 0xffff;
    if (param_3 < local_1c) {
      local_1c = param_3 & 0xffff;
    }
    cVar2 = FUN_100037a0(param_1,0,*(int *)(param_1 + 0x14 + local_18 * 4) + iVar3,local_1c,param_4)
    ;
    if (cVar2 == '\0') {
      FUN_100010f0();
                    // WARNING: Subroutine does not return
      _CxxThrowException(local_40,(ThrowInfo *)&DAT_10030570);
    }
    param_3 = param_3 - local_1c;
    uVar4 = local_18 + 1;
    uVar1 = local_1c;
  }
  for (; 0x3fff < param_3; param_3 = param_3 - 0x4000) {
    cVar2 = FUN_100037a0(param_1,uVar1,*(undefined4 *)(param_1 + 0x14 + uVar4 * 4),0x4000,param_4);
    if (cVar2 == '\0') {
      FUN_100010f0();
                    // WARNING: Subroutine does not return
      _CxxThrowException(local_34,(ThrowInfo *)&DAT_10030570);
    }
    uVar4 = uVar4 + 1;
    uVar1 = uVar1 + 0x4000;
  }
  if ((param_3 != 0) &&
     (cVar2 = FUN_100037a0(param_1,uVar1,*(undefined4 *)(param_1 + 0x14 + uVar4 * 4),param_3,param_4
                          ), cVar2 == '\0')) {
    FUN_100010f0();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_28,(ThrowInfo *)&DAT_10030570);
  }
  return;
}



void FUN_10003ed0(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10003f70;
  local_10 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_10;
  DAT_10034544 = operator_new(0x4000);
  DAT_10034540 = operator_new(0x4000);
  ExceptionList = local_10;
  return;
}



void FUN_10003fd0(undefined1 *param_1,undefined1 *param_2)

{
  *param_2 = *param_1;
  param_2[1] = param_1[1];
  param_2[2] = param_1[2];
  param_2[3] = param_1[3];
  param_2[4] = 0;
  return;
}



undefined4 FUN_10004000(undefined4 *param_1)

{
  return *param_1;
}



undefined2 FUN_10004060(undefined1 *param_1)

{
  return CONCAT11(*param_1,param_1[1]);
}



undefined2 FUN_10004064(void)

{
  undefined1 *in_EAX;
  
  return CONCAT11(*in_EAX,in_EAX[1]);
}



void FUN_10004090(undefined1 *param_1,undefined4 param_2)

{
  param_1[1] = (char)param_2;
  *param_1 = (char)((uint)param_2 >> 8);
  return;
}



undefined4 FUN_100040b0(undefined1 *param_1)

{
  return CONCAT13(*param_1,CONCAT12(param_1[1],CONCAT11(param_1[2],param_1[3])));
}



undefined4 FUN_100040b4(void)

{
  undefined1 *in_EAX;
  
  return CONCAT13(*in_EAX,CONCAT12(in_EAX[1],CONCAT11(in_EAX[2],in_EAX[3])));
}



void FUN_100040e0(undefined1 *param_1,undefined4 param_2)

{
  param_1[3] = (char)param_2;
  param_1[2] = (char)((uint)param_2 >> 8);
  param_1[1] = (char)((uint)param_2 >> 0x10);
  *param_1 = (char)((uint)param_2 >> 0x18);
  return;
}



// WARNING: Removing unreachable block (ram,0x10004222)
// WARNING: Globals starting with '_' overlap smaller symbols at the same address

float10 FUN_10004110(void)

{
  ushort uVar1;
  uint uVar2;
  uint uVar3;
  float10 fVar4;
  float10 fVar5;
  float10 fVar6;
  
  uVar1 = FUN_10004064();
  uVar2 = FUN_100040b4();
  uVar3 = FUN_100040b4();
  if (((uVar1 == 0) && (uVar2 == 0)) && (uVar3 == 0)) {
    return (float10)_DAT_1014f7f8;
  }
  fVar4 = (float10)FUN_1002ddf0(0,0x40000000,0,0xc04f8000);
  fVar5 = (float10)FUN_1002ddf0(0,0x40000000,0,0xc03f0000);
  fVar6 = (float10)FUN_1002ddf0(0,0x40000000,(double)(uVar1 & 0x7fff) - _DAT_1014f818);
  return fVar6 * (float10)(double)((float10)uVar2 * fVar5 +
                                  (float10)(double)((float10)uVar3 * fVar4));
}



undefined4 __thiscall FUN_100044b0(undefined4 param_1,undefined4 param_2)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10004520;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_1000a270();
  local_8 = 0;
  FUN_100045b4(param_2);
  ExceptionList = local_10;
  return param_1;
}



void FUN_10004530(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_100045a0;
  local_10 = ExceptionList;
  local_8 = 0xffffffff;
  ExceptionList = &local_10;
  FUN_1000a300();
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_100045b4(undefined4 *param_1,int param_2)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  uVar2 = FUN_100040b4();
  *param_1 = uVar2;
  FUN_1000a560(param_2 + 4);
  iVar5 = 0;
  iVar3 = 0;
  do {
    cVar1 = *(char *)(iVar5 + param_2 + 9);
    iVar4 = iVar3;
    if (cVar1 == '\0') break;
    *(char *)((int)param_1 + iVar3 + 0x10) = cVar1;
    iVar4 = iVar3 + 1;
    if ((*(char *)(param_2 + 9 + iVar5) == '\r') && (iVar4 < 0x80)) {
      *(undefined1 *)((int)param_1 + iVar3 + 0x11) = 10;
      iVar4 = iVar3 + 2;
    }
    iVar5 = iVar5 + 1;
    iVar3 = iVar4;
  } while (iVar4 < 0x80);
  *(undefined1 *)((int)param_1 + iVar4 + 0x10) = 0;
  return;
}



int FUN_10004630(int param_1,int param_2)

{
  if (param_1 < param_2) {
    return param_1;
  }
  return param_2;
}



int FUN_10004640(int param_1,int param_2)

{
  if (param_2 < param_1) {
    return param_1;
  }
  return param_2;
}



int FUN_10004650(int param_1)

{
  if (param_1 < 0) {
    param_1 = -param_1;
  }
  return param_1;
}



int FUN_10004660(int param_1,int param_2,int param_3)

{
  if (param_1 < param_2) {
    return param_2;
  }
  if (param_3 < param_1) {
    return param_3;
  }
  return param_1;
}



bool FUN_10004680(int param_1,int param_2,int param_3)

{
  param_1 = param_1 - param_2;
  if (param_1 < 0) {
    param_1 = -param_1;
  }
  return param_1 <= param_3;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void FUN_100046b0(void)

{
  undefined4 uVar1;
  float fVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  uint local_10;
  uint local_c;
  uint local_8;
  
  fVar2 = _DAT_1014f8e4;
  DAT_1005474c = 0x3f800000;
  uVar5 = 0x7e;
  do {
    uVar3 = uVar5 - 1 & 0xffff;
    (&DAT_10054550)[uVar5] =
         *(float *)(uVar5 * 4 + 0x10054554) - fVar2 * *(float *)(uVar5 * 4 + 0x10054554);
    uVar5 = uVar3;
  } while (uVar3 != 0);
  uVar5 = 0;
  DAT_10054550 = 0;
  do {
    local_8 = 0;
    do {
      iVar6 = (int)((local_8 - 0x40) * 0x10000) >> 0x10;
      iVar4 = (int)(short)((int)(iVar6 * iVar6 + ((uint)(iVar6 * iVar6 >> 4) >> 0x1b)) >> 5);
      if (iVar6 < 1) {
        local_c = uVar5;
      }
      else {
        uVar3 = FUN_10004660((short)uVar5 - iVar4,0,0x7f);
        local_c = uVar3 & 0xffff;
      }
      if (iVar6 < 0) {
        uVar3 = FUN_10004660((short)uVar5 - iVar4,0,0x7f);
        local_10 = uVar3 & 0xffff;
      }
      else {
        local_10 = uVar5;
      }
      uVar1 = (&DAT_10054550)[local_10];
      *(undefined4 *)(&DAT_10034550 + local_8 * 8 + uVar5 * 0x400) = (&DAT_10054550)[local_c];
      *(undefined4 *)(&DAT_10034554 + local_8 * 8 + uVar5 * 0x400) = uVar1;
      local_8 = local_8 + 1 & 0xffff;
    } while (local_8 < 0x80);
    uVar5 = uVar5 + 1 & 0xffff;
  } while (uVar5 < 0x80);
  return;
}



void __thiscall FUN_10004934(int param_1,int param_2)

{
  undefined4 uVar1;
  
  FUN_10003fd0(param_2,param_1);
  uVar1 = FUN_100040b0(param_2 + 4);
  *(undefined4 *)(param_1 + 8) = uVar1;
  return;
}



void __thiscall FUN_100049b4(int param_1,int param_2)

{
  undefined4 uVar1;
  
  FUN_10003fd0(param_2,param_1);
  uVar1 = FUN_10004000(param_2 + 4);
  *(undefined4 *)(param_1 + 8) = uVar1;
  return;
}



char * __fastcall FUN_100049f4(char *param_1)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  
  pcVar3 = &DAT_1014fc50;
  param_1[8] = '\0';
  param_1[9] = '\0';
  param_1[10] = '\0';
  param_1[0xb] = '\0';
  pcVar2 = param_1;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
    *pcVar2 = cVar1;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  pcVar2 = param_1 + 0xc;
  pcVar3 = &DAT_1014fc50;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
    *pcVar2 = cVar1;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  return param_1;
}



void __thiscall FUN_10004a84(int param_1,int param_2)

{
  undefined4 uVar1;
  
  FUN_10003fd0(param_2,param_1);
  uVar1 = FUN_100040b0(param_2 + 4);
  *(undefined4 *)(param_1 + 8) = uVar1;
  FUN_10003fd0(param_2 + 8,param_1 + 0xc);
  return;
}



void __thiscall FUN_10004b24(int param_1,int param_2)

{
  undefined4 uVar1;
  
  FUN_10003fd0(param_2,param_1);
  uVar1 = FUN_10004000(param_2 + 4);
  *(undefined4 *)(param_1 + 8) = uVar1;
  FUN_10003fd0(param_2 + 8,param_1 + 0xc);
  return;
}



undefined4 * __fastcall FUN_10004ba0(undefined4 *param_1)

{
  *param_1 = &PTR_LAB_10030614;
  param_1[2] = 0xadde1ab0;
  param_1[3] = 0xadde1ab0;
  param_1[4] = 0;
  *(undefined1 *)(param_1 + 1) = 0;
  return param_1;
}



void __fastcall FUN_10004bc0(undefined4 *param_1)

{
  *param_1 = &PTR_LAB_10030614;
  param_1[4] = 0;
  return;
}



undefined4 * __fastcall FUN_10004e90(undefined4 *param_1)

{
  *param_1 = &PTR_LAB_10030624;
  FUN_10006720();
  return param_1;
}



undefined4 * __thiscall FUN_10004eb0(undefined4 *param_1,undefined4 param_2,char *param_3)

{
  char cVar1;
  char *pcVar2;
  
  *param_1 = &PTR_LAB_10030624;
  FUN_10006720();
  pcVar2 = (char *)((int)param_1 + 6);
  do {
    cVar1 = *param_3;
    param_3 = param_3 + 1;
    *pcVar2 = cVar1;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  param_1[3] = param_2;
  return param_1;
}



void __fastcall FUN_10004ef0(undefined4 *param_1)

{
  *param_1 = &PTR_LAB_10030624;
  param_1[3] = 0;
  return;
}



undefined1 FUN_10004f00(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 uVar1;
  
  uVar1 = FUN_10004f44(param_1,param_2,0,param_3);
  return uVar1;
}



undefined1 FUN_10004f40(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined1 uVar1;
  undefined1 auStack_18 [8];
  
  uVar1 = FUN_10004f94(param_1,param_2,param_3,param_4,auStack_18);
  return uVar1;
}



undefined1 FUN_10004f44(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined1 uVar1;
  undefined1 auStack_18 [8];
  
  uVar1 = FUN_10004f94(param_1,param_2,param_3,param_4,auStack_18);
  return uVar1;
}



undefined4 __thiscall FUN_10004f94(int param_1,undefined4 param_2,uint *param_3)

{
  byte bVar1;
  char cVar2;
  uint uVar3;
  int iVar4;
  byte *unaff_ESI;
  char *pcVar5;
  byte *pbVar6;
  char *pcVar7;
  byte *pbVar8;
  bool bVar9;
  undefined4 unaff_retaddr;
  undefined4 local_68 [5];
  int iStack_54;
  undefined1 local_50 [8];
  byte abStack_48 [8];
  uint uStack_40;
  char local_3c [8];
  undefined4 local_34 [2];
  undefined1 auStack_2c [4];
  
  local_68[0] = 0x10004fa8;
  FUN_100049f4();
  pcVar5 = local_3c;
  pcVar7 = &DAT_1014fc50;
  local_34[0] = 0;
  do {
    cVar2 = *pcVar7;
    pcVar7 = pcVar7 + 1;
    *pcVar5 = cVar2;
    pcVar5 = pcVar5 + 1;
  } while (cVar2 != '\0');
  local_68[0] = 0;
  (**(code **)(**(int **)(param_1 + 0xc) + 0x14))();
  (**(code **)(**(int **)(param_1 + 0xc) + 4))(0xc,auStack_2c);
  if (*(char *)(param_1 + 5) == '\0') {
    FUN_10004a84(local_34);
  }
  else {
    FUN_10004b24(local_34);
  }
  cVar2 = FUN_100054d4(local_50);
  if (cVar2 == '\0') {
    FUN_10001250();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_68,(ThrowInfo *)&DAT_10030420);
  }
  iVar4 = 0xc;
  FUN_10005474(abStack_48);
  pbVar8 = abStack_48;
  pbVar6 = unaff_ESI;
  do {
    bVar1 = *pbVar8;
    bVar9 = bVar1 < *pbVar6;
    if (bVar1 != *pbVar6) {
LAB_100050a4:
      uVar3 = -(uint)bVar9 | 1;
      goto joined_r0x100050ab;
    }
    if (bVar1 == 0) break;
    bVar1 = pbVar8[1];
    bVar9 = bVar1 < pbVar6[1];
    if (bVar1 != pbVar6[1]) goto LAB_100050a4;
    pbVar8 = pbVar8 + 2;
    pbVar6 = pbVar6 + 2;
  } while (bVar1 != 0);
  uVar3 = 0;
joined_r0x100050ab:
  do {
    if (uVar3 == 0) {
      bVar9 = true;
      *param_3 = uStack_40;
LAB_100051c2:
      if (bVar9) {
        (**(code **)(**(int **)(param_1 + 0xc) + 0x2c))(unaff_retaddr);
        (**(code **)(**(int **)(param_1 + 0xc) + 4))(unaff_retaddr,unaff_ESI);
        return 1;
      }
      return 0;
    }
    iVar4 = iVar4 + 8 + uStack_40;
    if ((*(char *)(param_1 + 4) != '\0') && ((uStack_40 & 1) == 1)) {
      iVar4 = iVar4 + 1;
    }
    if (iStack_54 + 8 <= iVar4 + 8) {
      bVar9 = false;
      goto LAB_100051c2;
    }
    (**(code **)(**(int **)(param_1 + 0xc) + 0x14))(iVar4);
    (**(code **)(**(int **)(param_1 + 0xc) + 4))(8,&uStack_40);
    if (*(char *)(param_1 + 5) == '\0') {
      FUN_10004934(local_3c);
      pbVar8 = abStack_48;
      pbVar6 = unaff_ESI;
      do {
        bVar1 = *pbVar8;
        bVar9 = bVar1 < *pbVar6;
        if (bVar1 != *pbVar6) {
LAB_10005152:
          uVar3 = -(uint)bVar9 | 1;
          goto joined_r0x100050ab;
        }
        if (bVar1 == 0) break;
        bVar1 = pbVar8[1];
        bVar9 = bVar1 < pbVar6[1];
        if (bVar1 != pbVar6[1]) goto LAB_10005152;
        pbVar8 = pbVar8 + 2;
        pbVar6 = pbVar6 + 2;
      } while (bVar1 != 0);
      uVar3 = 0;
    }
    else {
      FUN_100049b4(local_3c);
      pbVar8 = abStack_48;
      pbVar6 = unaff_ESI;
      do {
        bVar1 = *pbVar8;
        bVar9 = bVar1 < *pbVar6;
        if (bVar1 != *pbVar6) {
LAB_100051a0:
          uVar3 = -(uint)bVar9 | 1;
          goto joined_r0x100050ab;
        }
        if (bVar1 == 0) break;
        bVar1 = pbVar8[1];
        bVar9 = bVar1 < pbVar6[1];
        if (bVar1 != pbVar6[1]) goto LAB_100051a0;
        pbVar8 = pbVar8 + 2;
        pbVar6 = pbVar6 + 2;
      } while (bVar1 != 0);
      uVar3 = 0;
    }
  } while( true );
}



undefined4 __fastcall FUN_10005220(int param_1)

{
  undefined1 *puVar1;
  byte bVar2;
  char cVar3;
  uint uVar4;
  int iVar5;
  byte *unaff_ESI;
  char *pcVar6;
  byte *pbVar7;
  uint *unaff_EDI;
  char *pcVar8;
  byte *pbVar9;
  bool bVar10;
  undefined4 local_68 [2];
  int iStack_60;
  undefined1 auStack_54 [12];
  byte abStack_48 [8];
  uint uStack_40;
  char local_3c [8];
  undefined4 local_34;
  undefined1 auStack_30 [8];
  
  puVar1 = auStack_30 + 8;
  local_68[0] = 0x10005236;
  FUN_100049f4();
  pcVar6 = local_3c;
  pcVar8 = &DAT_1014fc50;
  local_34 = 0;
  do {
    cVar3 = *pcVar8;
    pcVar8 = pcVar8 + 1;
    *pcVar6 = cVar3;
    pcVar6 = pcVar6 + 1;
  } while (cVar3 != '\0');
  local_68[0] = 0;
  (**(code **)(**(int **)(param_1 + 0xc) + 0x14))();
  (**(code **)(**(int **)(param_1 + 0xc) + 4))(0xc,puVar1);
  if (*(char *)(param_1 + 5) == '\0') {
    FUN_10004a84(puVar1);
  }
  else {
    FUN_10004b24(puVar1);
  }
  cVar3 = FUN_100054d4(local_68);
  if (cVar3 == '\0') {
    FUN_10001250();
                    // WARNING: Subroutine does not return
    _CxxThrowException(auStack_54,(ThrowInfo *)&DAT_10030420);
  }
  iVar5 = 0xc;
  FUN_10005474(abStack_48);
  pbVar9 = abStack_48;
  pbVar7 = unaff_ESI;
  do {
    bVar2 = *pbVar9;
    bVar10 = bVar2 < *pbVar7;
    if (bVar2 != *pbVar7) {
LAB_10005328:
      uVar4 = -(uint)bVar10 | 1;
      goto joined_r0x1000532f;
    }
    if (bVar2 == 0) break;
    bVar2 = pbVar9[1];
    bVar10 = bVar2 < pbVar7[1];
    if (bVar2 != pbVar7[1]) goto LAB_10005328;
    pbVar9 = pbVar9 + 2;
    pbVar7 = pbVar7 + 2;
  } while (bVar2 != 0);
  uVar4 = 0;
joined_r0x1000532f:
  do {
    if (uVar4 == 0) {
      *unaff_EDI = uStack_40;
      return 1;
    }
    iVar5 = iVar5 + 8 + uStack_40;
    if ((*(char *)(param_1 + 4) != '\0') && ((uStack_40 & 1) == 1)) {
      iVar5 = iVar5 + 1;
    }
    if (iStack_60 + 8 <= iVar5 + 8) {
      return 0;
    }
    (**(code **)(**(int **)(param_1 + 0xc) + 0x14))(iVar5);
    (**(code **)(**(int **)(param_1 + 0xc) + 4))(unaff_ESI,&uStack_40);
    if (*(char *)(param_1 + 5) == '\0') {
      FUN_10004934(local_3c);
      pbVar9 = abStack_48;
      pbVar7 = unaff_ESI;
      do {
        bVar2 = *pbVar9;
        bVar10 = bVar2 < *pbVar7;
        if (bVar2 != *pbVar7) {
LAB_100053de:
          uVar4 = -(uint)bVar10 | 1;
          goto joined_r0x1000532f;
        }
        if (bVar2 == 0) break;
        bVar2 = pbVar9[1];
        bVar10 = bVar2 < pbVar7[1];
        if (bVar2 != pbVar7[1]) goto LAB_100053de;
        pbVar9 = pbVar9 + 2;
        pbVar7 = pbVar7 + 2;
      } while (bVar2 != 0);
      uVar4 = 0;
      goto joined_r0x1000532f;
    }
    FUN_100049b4(local_3c);
    pbVar9 = abStack_48;
    pbVar7 = unaff_ESI;
    do {
      bVar2 = *pbVar9;
      bVar10 = bVar2 < *pbVar7;
      if (bVar2 != *pbVar7) {
LAB_1000542c:
        uVar4 = -(uint)bVar10 | 1;
        goto joined_r0x1000532f;
      }
      if (bVar2 == 0) break;
      bVar2 = pbVar9[1];
      bVar10 = bVar2 < pbVar7[1];
      if (bVar2 != pbVar7[1]) goto LAB_1000542c;
      pbVar9 = pbVar9 + 2;
      pbVar7 = pbVar7 + 2;
    } while (bVar2 != 0);
    uVar4 = 0;
  } while( true );
}



void __fastcall FUN_10005474(int param_1)

{
  undefined1 auStack_14 [12];
  
  (**(code **)(**(int **)(param_1 + 0xc) + 4))(8,auStack_14);
  if (*(char *)(param_1 + 5) == '\0') {
    FUN_10004934(auStack_14);
    return;
  }
  FUN_100049b4(auStack_14);
  return;
}



undefined4 __thiscall FUN_100054d4(int param_1,byte *param_2)

{
  byte bVar1;
  uint uVar2;
  byte *pbVar3;
  byte *pbVar4;
  bool bVar5;
  
  pbVar3 = (byte *)(param_1 + 6);
  pbVar4 = param_2;
  do {
    bVar1 = *pbVar4;
    bVar5 = bVar1 < *pbVar3;
    if (bVar1 != *pbVar3) {
LAB_10005500:
      uVar2 = -(uint)bVar5 | 1;
      goto LAB_10005505;
    }
    if (bVar1 == 0) break;
    bVar1 = pbVar4[1];
    bVar5 = bVar1 < pbVar3[1];
    if (bVar1 != pbVar3[1]) goto LAB_10005500;
    pbVar4 = pbVar4 + 2;
    pbVar3 = pbVar3 + 2;
  } while (bVar1 != 0);
  uVar2 = 0;
LAB_10005505:
  if ((uVar2 == 0) && (3 < *(uint *)(param_2 + 8))) {
    return 1;
  }
  return 0;
}



undefined4 * __fastcall FUN_10005534(undefined4 *param_1)

{
  *param_1 = 0xffffffff;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[1] = 0;
  *(undefined1 *)(param_1 + 2) = 0;
  return param_1;
}



undefined4 * __thiscall
FUN_10005594(undefined4 *param_1,undefined4 param_2,undefined4 *param_3,undefined4 param_4,
            undefined4 param_5)

{
  param_1[3] = param_4;
  param_1[4] = param_5;
  *param_1 = param_2;
  param_1[1] = *param_3;
  *(undefined1 *)(param_1 + 2) = 0;
  return param_1;
}



undefined4 __fastcall FUN_100055d4(undefined4 *param_1)

{
  undefined1 local_14 [12];
  undefined1 *local_8;
  
  switch(*param_1) {
  case 0:
    return 8;
  case 1:
  case 2:
  case 3:
    return 0xc;
  default:
    local_8 = local_14;
    FUN_100010f0();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_8,(ThrowInfo *)&DAT_10030570);
  }
}



void FUN_10005630(undefined4 param_1,int *param_2,uint param_3)

{
  bool bVar1;
  undefined ***pppuVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  char *pcVar6;
  char *pcVar7;
  int iVar8;
  uint uVar9;
  char *pcVar10;
  undefined1 auStack_102 [30];
  undefined4 local_e4;
  undefined1 local_e0;
  int local_dc;
  char *local_d8;
  undefined4 *local_d4;
  char *local_c8;
  undefined **local_c4 [2];
  undefined4 local_bc;
  char *local_a0;
  undefined4 local_9c;
  undefined4 local_98;
  int local_90;
  char *local_8c;
  undefined1 local_88 [12];
  undefined4 local_7c;
  undefined4 local_78;
  undefined4 local_74;
  undefined4 local_70;
  undefined4 local_6c;
  undefined4 *local_68;
  undefined ***local_64;
  int local_60;
  int local_5c;
  int local_58;
  code *local_54;
  code *local_50;
  code *local_4c;
  char *local_48;
  code *local_44;
  code *local_40;
  code *local_3c;
  code *local_38;
  undefined1 *local_34;
  undefined4 *local_30;
  undefined4 *local_2c;
  undefined4 *local_28;
  undefined4 *local_24;
  undefined4 *local_20;
  undefined4 *local_1c;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10005c90;
  local_10 = ExceptionList;
  local_14 = auStack_102 + -0x12;
  local_a0 = (char *)0x0;
  local_c8 = (char *)0x0;
  local_8 = 0;
  ExceptionList = &local_10;
  local_c8 = operator_new(param_3 + 1);
  uVar9 = param_3 >> 2;
  pcVar10 = local_c8;
  while (uVar9 != 0) {
    uVar9 = uVar9 - 1;
    builtin_strncpy(pcVar10,"    ",4);
    pcVar10 = pcVar10 + 4;
  }
  for (uVar9 = param_3 & 3; uVar9 != 0; uVar9 = uVar9 - 1) {
    *pcVar10 = ' ';
    pcVar10 = pcVar10 + 1;
  }
  local_c8[param_3] = '\0';
  local_a0 = operator_new(300);
  local_64 = local_c4;
  FUN_10005cb4(param_1,0);
  local_8 = 1;
  local_68 = &local_9c;
  FUN_10005534();
  cVar3 = FUN_10005ed4(local_68);
  if (cVar3 != '\0') {
    do {
      switch(local_9c) {
      case 0:
        uVar4 = FUN_10005ca4();
        local_48 = local_8c;
        sprintf(local_a0,s__sSimple_chunk__type___s__size____1014fc60,local_c8,uVar4,local_8c,
                pcVar10);
        iVar8 = -1;
        pcVar10 = local_a0;
        do {
          if (iVar8 == 0) break;
          iVar8 = iVar8 + -1;
          cVar3 = *pcVar10;
          pcVar10 = pcVar10 + 1;
        } while (cVar3 != '\0');
        local_38 = *(code **)(*param_2 + 0xc);
        (*local_38)(-2 - iVar8,local_a0);
        break;
      case 1:
        uVar4 = FUN_10005ca4();
        sprintf(local_a0,s__sDumping_contents_of__FORM__chu_1014fc90,local_c8,uVar4);
        iVar8 = -1;
        pcVar10 = local_a0;
        do {
          pcVar6 = pcVar10;
          if (iVar8 == 0) break;
          iVar8 = iVar8 + -1;
          pcVar6 = pcVar10 + 1;
          cVar3 = *pcVar10;
          pcVar10 = pcVar6;
        } while (cVar3 != '\0');
        local_3c = *(code **)(*param_2 + 0xc);
        (*local_3c)(-2 - iVar8,local_a0);
        local_28 = operator_new(0x10);
        if (local_28 == (undefined4 *)0x0) {
          local_1c = (undefined4 *)0x0;
        }
        else {
          local_58 = local_90;
          iVar8 = FUN_100055d4();
          pcVar6 = local_8c;
          FUN_10007220(local_bc,local_58 + iVar8,local_8c);
          local_1c = local_28;
        }
        FUN_10005630(local_1c,param_2,param_3 + 4,pcVar6);
        if (local_1c != (undefined4 *)0x0) {
          local_4c = *(code **)*local_1c;
          (*local_4c)(1);
        }
        break;
      case 2:
        uVar4 = FUN_10005ca4();
        sprintf(local_a0,s__sDumping_contents_of__CAT___chu_1014fcc0,local_c8,uVar4);
        iVar8 = -1;
        pcVar10 = local_a0;
        do {
          pcVar6 = pcVar10;
          if (iVar8 == 0) break;
          iVar8 = iVar8 + -1;
          pcVar6 = pcVar10 + 1;
          cVar3 = *pcVar10;
          pcVar10 = pcVar6;
        } while (cVar3 != '\0');
        local_40 = *(code **)(*param_2 + 0xc);
        (*local_40)(-2 - iVar8,local_a0);
        local_2c = operator_new(0x10);
        if (local_2c == (undefined4 *)0x0) {
          local_20 = (undefined4 *)0x0;
        }
        else {
          local_5c = local_90;
          iVar8 = FUN_100055d4();
          FUN_10007220(local_bc,local_5c + iVar8,local_8c);
          local_20 = local_2c;
        }
        FUN_10005630(local_20,param_2,param_3 + 4,pcVar6);
        if (local_20 != (undefined4 *)0x0) {
          local_50 = *(code **)*local_20;
          (*local_50)(1);
        }
        break;
      case 3:
        uVar4 = FUN_10005ca4();
        sprintf(s__sDumping_contents_of__LIST__chu_1014fcf0,local_c8,uVar4,pcVar10);
        iVar8 = -1;
        pcVar10 = local_a0;
        do {
          pcVar6 = pcVar10;
          if (iVar8 == 0) break;
          iVar8 = iVar8 + -1;
          pcVar6 = pcVar10 + 1;
          cVar3 = *pcVar10;
          pcVar10 = pcVar6;
        } while (cVar3 != '\0');
        local_44 = *(code **)(*param_2 + 0xc);
        (*local_44)(-2 - iVar8,local_a0);
        local_30 = operator_new(0x10);
        if (local_30 == (undefined4 *)0x0) {
          local_24 = (undefined4 *)0x0;
        }
        else {
          local_60 = local_90;
          iVar8 = FUN_100055d4();
          FUN_10007220(local_bc,local_60 + iVar8,local_8c);
          local_24 = local_30;
        }
        FUN_10005630(local_24,param_2,param_3 + 4,pcVar6);
        if (local_24 != (undefined4 *)0x0) {
          local_54 = *(code **)*local_24;
          (*local_54)(1);
        }
      }
      pppuVar2 = local_64;
      iVar8 = local_90;
      local_d8 = local_8c;
      pcVar10 = (char *)&local_e4;
      local_dc = local_90;
      local_e4 = local_98;
      local_e0 = 0;
      local_d4 = local_68;
      iVar5 = FUN_100055d4();
      pcVar6 = local_d8 + iVar8 + iVar5;
      uVar9 = (uint)pcVar6 & 1;
      if ((int)pcVar6 < 0) {
        uVar9 = -(-(int)pcVar6 & 1U);
      }
      pcVar6 = pcVar6 + uVar9;
      pcVar7 = (char *)(**(code **)(*pppuVar2[2] + 0x18))();
      if (pcVar6 == pcVar7) {
        bVar1 = false;
      }
      else {
        iVar8 = (**(code **)(*pppuVar2[2] + 0x18))();
        if (iVar8 < (int)pcVar6) {
          local_34 = local_88;
          FUN_100010f0();
                    // WARNING: Subroutine does not return
          _CxxThrowException(local_34,(ThrowInfo *)&DAT_10030570);
        }
        (**(code **)(*pppuVar2[2] + 0x14))(pcVar6);
        FUN_10006084(&local_7c);
        bVar1 = true;
        *local_d4 = local_7c;
        local_d4[1] = local_78;
        local_d4[2] = local_74;
        local_d4[3] = local_70;
        local_d4[4] = local_6c;
      }
    } while (bVar1);
  }
  FUN_1002dde0(local_a0,pcVar10);
  local_a0 = (char *)0x0;
  FUN_1002dde0(local_c8,pcVar10);
  local_c8 = (char *)0x0;
  local_8 = 0;
  local_c4[0] = &PTR_LAB_10030634;
  FUN_10006304();
  ExceptionList = local_10;
  return;
}



int __fastcall FUN_10005ca4(int param_1)

{
  return param_1 + 4;
}



undefined4 * __thiscall FUN_10005cb4(undefined4 *param_1,undefined4 param_2,int param_3)

{
  param_1[2] = param_2;
  *param_1 = &PTR_LAB_10030634;
  param_1[1] = 0;
  FUN_10005534();
  param_1[8] = 0;
  if (param_3 == 0) {
    param_1[8] = FUN_100040b0;
  }
  else if (param_3 == 1) {
    param_1[8] = FUN_10004000;
  }
  return param_1;
}



void FUN_10005dc0(int *param_1,undefined4 param_2)

{
  char cVar1;
  undefined1 auStackY_104 [128];
  undefined **local_5c [9];
  int local_38 [4];
  int local_28;
  int local_20;
  undefined ***local_1c;
  int *local_18;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10005ec0;
  local_10 = ExceptionList;
  local_14 = auStackY_104 + 0x88;
  local_8 = 0;
  local_1c = local_5c;
  ExceptionList = &local_10;
  FUN_10005cb4(param_1,param_2);
  local_8 = 1;
  local_18 = local_38;
  FUN_10005534();
  cVar1 = FUN_10005ed4(local_18);
  if ((cVar1 != '\0') && (local_38[0] - 1U < 3)) {
    local_20 = FUN_100055d4();
    local_20 = local_28 + local_20;
    (**(code **)(*param_1 + 0x18))();
  }
  local_8 = 0;
  local_5c[0] = &PTR_LAB_10030634;
  FUN_10006304();
  ExceptionList = local_10;
  return;
}



undefined4 __fastcall FUN_10005ed4(int param_1)

{
  int iVar1;
  undefined4 *unaff_retaddr;
  undefined4 auStack_24 [5];
  undefined4 *puStack_10;
  
  (**(code **)(**(int **)(param_1 + 8) + 0x14))(0);
  iVar1 = (**(code **)(**(int **)(param_1 + 8) + 0x18))();
  if (iVar1 < 8) {
    return 0;
  }
  puStack_10 = auStack_24;
  FUN_10006084(puStack_10);
  *unaff_retaddr = *puStack_10;
  unaff_retaddr[1] = puStack_10[1];
  unaff_retaddr[2] = puStack_10[2];
  unaff_retaddr[3] = puStack_10[3];
  unaff_retaddr[4] = puStack_10[4];
  return 1;
}



undefined4 __fastcall FUN_10006084(int param_1)

{
  byte bVar1;
  uint uVar2;
  undefined4 unaff_EBP;
  byte *pbVar3;
  byte *pbVar4;
  bool bVar5;
  byte *apbStack_50 [2];
  undefined1 auStack_48 [4];
  undefined1 uStack_44;
  undefined1 auStack_40 [4];
  undefined1 local_3c [4];
  undefined1 auStack_38 [4];
  undefined1 uStack_34;
  undefined4 uStack_30;
  int iStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  byte local_20 [8];
  undefined4 uStack_18;
  undefined4 uStack_14;
  
  apbStack_50[0] = (byte *)0x100060a1;
  uStack_18 = (**(code **)(**(int **)(param_1 + 8) + 0x10))();
  local_20[4] = 0;
  apbStack_50[0] = local_20;
  (**(code **)(**(int **)(param_1 + 8) + 4))(4);
  (**(code **)(**(int **)(param_1 + 8) + 4))(4,local_3c);
  uStack_24 = (**(code **)(param_1 + 0x20))(local_3c);
  pbVar3 = &DAT_1014fb90;
  pbVar4 = local_20;
  do {
    bVar1 = *pbVar4;
    bVar5 = bVar1 < *pbVar3;
    if (bVar1 != *pbVar3) {
LAB_10006115:
      uVar2 = -(uint)bVar5 | 1;
      goto LAB_1000611a;
    }
    if (bVar1 == 0) break;
    bVar1 = pbVar4[1];
    bVar5 = bVar1 < pbVar3[1];
    if (bVar1 != pbVar3[1]) goto LAB_10006115;
    pbVar4 = pbVar4 + 2;
    pbVar3 = pbVar3 + 2;
  } while (bVar1 != 0);
  uVar2 = 0;
LAB_1000611a:
  if (uVar2 == 0) {
    uStack_44 = 0;
    (**(code **)(**(int **)(param_1 + 8) + 4))(4,auStack_48);
    FUN_10005594(1,apbStack_50,uStack_30,iStack_2c + -4);
    return uStack_14;
  }
  pbVar3 = &DAT_1014fb88;
  pbVar4 = local_20;
  do {
    bVar1 = *pbVar4;
    bVar5 = bVar1 < *pbVar3;
    if (bVar1 != *pbVar3) {
LAB_10006149:
      uVar2 = -(uint)bVar5 | 1;
      goto LAB_1000614e;
    }
    if (bVar1 == 0) break;
    bVar1 = pbVar4[1];
    bVar5 = bVar1 < pbVar3[1];
    if (bVar1 != pbVar3[1]) goto LAB_10006149;
    pbVar4 = pbVar4 + 2;
    pbVar3 = pbVar3 + 2;
  } while (bVar1 != 0);
  uVar2 = 0;
LAB_1000614e:
  if (uVar2 == 0) {
    local_3c[0] = 0;
    (**(code **)(**(int **)(param_1 + 8) + 4))(4,auStack_40);
    FUN_10005594(2,auStack_48,uStack_30,iStack_2c + -4);
    return uStack_14;
  }
  pbVar3 = &DAT_1014fb80;
  pbVar4 = local_20;
  do {
    bVar1 = *pbVar4;
    bVar5 = bVar1 < *pbVar3;
    if (bVar1 != *pbVar3) {
LAB_1000617d:
      uVar2 = -(uint)bVar5 | 1;
      goto LAB_10006182;
    }
    if (bVar1 == 0) break;
    bVar1 = pbVar4[1];
    bVar5 = bVar1 < pbVar3[1];
    if (bVar1 != pbVar3[1]) goto LAB_1000617d;
    pbVar4 = pbVar4 + 2;
    pbVar3 = pbVar3 + 2;
  } while (bVar1 != 0);
  uVar2 = 0;
LAB_10006182:
  if (uVar2 == 0) {
    uStack_34 = 0;
    (**(code **)(**(int **)(param_1 + 8) + 4))(4,auStack_38);
    FUN_10005594(3,auStack_40,uStack_30,iStack_2c + -4);
    return uStack_14;
  }
  FUN_10005594(0,local_20,uStack_28,uStack_24);
  return unaff_EBP;
}



void __fastcall FUN_10006304(int param_1)

{
  if (*(int *)(param_1 + 4) != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      if (*(undefined4 **)(param_1 + 8) != (undefined4 *)0x0) {
        (**(code **)**(undefined4 **)(param_1 + 8))(1);
      }
      *(undefined4 *)(param_1 + 8) = 0;
    }
    *(undefined4 *)(param_1 + 4) = 0;
  }
  return;
}



void __fastcall FUN_10006720(int param_1)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  
  pcVar2 = (char *)(param_1 + 6);
  *(undefined1 *)(param_1 + 4) = 1;
  pcVar3 = &DAT_1014f600;
  *(undefined1 *)(param_1 + 5) = 0;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
    *pcVar2 = cVar1;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  *(undefined4 *)(param_1 + 0xc) = 0;
  return;
}



void __fastcall FUN_100068a0(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10006900;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_100010f0();
  *param_1 = &PTR_LAB_100308b4;
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_10006910(undefined4 *param_1,undefined4 param_2)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10006980;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10001160(param_2);
  *param_1 = &PTR_LAB_100308b4;
  ExceptionList = local_10;
  return;
}



void FUN_10006990(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_100069f0;
  local_10 = ExceptionList;
  local_8 = 0xffffffff;
  ExceptionList = &local_10;
  FUN_100011e0();
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_10006a00(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10006a60;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_100010f0();
  *param_1 = &PTR_LAB_100308a4;
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_10006a70(undefined4 *param_1,undefined4 param_2)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10006ae0;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10001160(param_2);
  *param_1 = &PTR_LAB_100308a4;
  ExceptionList = local_10;
  return;
}



void FUN_10006af0(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10006b50;
  local_10 = ExceptionList;
  local_8 = 0xffffffff;
  ExceptionList = &local_10;
  FUN_100011e0();
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_10006b60(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10006bc0;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_100010f0();
  *param_1 = &PTR_LAB_100308c4;
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_10006bd0(undefined4 *param_1,undefined4 param_2)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10006c40;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10001160(param_2);
  *param_1 = &PTR_LAB_100308c4;
  ExceptionList = local_10;
  return;
}



void FUN_10006c50(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10006cb0;
  local_10 = ExceptionList;
  local_8 = 0xffffffff;
  ExceptionList = &local_10;
  FUN_100011e0();
  ExceptionList = local_10;
  return;
}



undefined4 * __fastcall FUN_10006cc0(undefined4 *param_1)

{
  *param_1 = &PTR_LAB_100307d4;
  return param_1;
}



void __fastcall FUN_10006cd0(undefined4 *param_1)

{
  *param_1 = &PTR_LAB_100307d4;
  return;
}



undefined4 * __fastcall FUN_10006ce0(undefined4 *param_1)

{
  *param_1 = &PTR_LAB_100307e4;
  return param_1;
}



void __fastcall FUN_10006cf0(undefined4 *param_1)

{
  *param_1 = &PTR_LAB_100307e4;
  return;
}



undefined4 * __thiscall FUN_10006fd0(undefined4 *param_1,undefined4 param_2)

{
  void *pvVar1;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10007050;
  local_10 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_10;
  param_1[2] = param_2;
  *param_1 = &PTR_LAB_10030824;
  param_1[3] = 0;
  *(undefined1 *)(param_1 + 4) = 1;
  param_1[1] = 0;
  pvVar1 = operator_new(param_1[2]);
  param_1[3] = pvVar1;
  ExceptionList = local_10;
  return param_1;
}



void __thiscall FUN_10007060(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  *param_1 = &PTR_LAB_10030824;
  param_1[1] = 0;
  *(undefined1 *)(param_1 + 4) = 0;
  param_1[2] = param_2;
  param_1[3] = param_3;
  return;
}



void __fastcall FUN_100070e0(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10007170;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  *param_1 = &PTR_LAB_10030824;
  local_8 = 0;
  if (*(char *)(param_1 + 4) != '\0') {
    FUN_1002dde0(param_1[3]);
    param_1[3] = 0;
  }
  *param_1 = &PTR_LAB_100307e4;
  ExceptionList = local_10;
  return;
}



undefined4 __fastcall FUN_10007210(int param_1)

{
  return *(undefined4 *)(param_1 + 0xc);
}



void __thiscall
FUN_10007220(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  *param_1 = &PTR_LAB_10030864;
  param_1[1] = param_2;
  param_1[3] = param_4;
  param_1[2] = param_3;
  return;
}



void __fastcall FUN_100072a0(undefined4 *param_1)

{
  *param_1 = &PTR_LAB_100307e4;
  return;
}



void __fastcall FUN_100077d0(int *param_1)

{
  int iVar1;
  int iVar2;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10007910;
  local_10 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_10;
  while (*param_1 != 0) {
    if (*(undefined4 **)*param_1 != (undefined4 *)0x0) {
      (**(code **)**(undefined4 **)*param_1)(1);
    }
    iVar1 = *param_1;
    iVar2 = *(int *)(iVar1 + 4);
    *param_1 = iVar2;
    if (iVar2 == 0) {
      param_1[1] = 0;
    }
    FUN_1002dde0(iVar1);
  }
  local_8 = 0xffffffff;
  while (*param_1 != 0) {
    iVar1 = *param_1;
    iVar2 = *(int *)(iVar1 + 4);
    *param_1 = iVar2;
    if (iVar2 == 0) {
      param_1[1] = 0;
    }
    FUN_1002dde0(iVar1);
  }
  *param_1 = 0;
  param_1[1] = 0;
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_10007920(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  return;
}



void __fastcall FUN_100079d0(int *param_1)

{
  int iVar1;
  int iVar2;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10007b10;
  local_10 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_10;
  while (*param_1 != 0) {
    if (*(undefined4 **)*param_1 != (undefined4 *)0x0) {
      (**(code **)**(undefined4 **)*param_1)(1);
    }
    iVar1 = *param_1;
    iVar2 = *(int *)(iVar1 + 4);
    *param_1 = iVar2;
    if (iVar2 == 0) {
      param_1[1] = 0;
    }
    FUN_1002dde0(iVar1);
  }
  local_8 = 0xffffffff;
  while (*param_1 != 0) {
    iVar1 = *param_1;
    iVar2 = *(int *)(iVar1 + 4);
    *param_1 = iVar2;
    if (iVar2 == 0) {
      param_1[1] = 0;
    }
    FUN_1002dde0(iVar1);
  }
  *param_1 = 0;
  param_1[1] = 0;
  ExceptionList = local_10;
  return;
}



undefined4 * __fastcall FUN_10007b20(undefined4 *param_1)

{
  param_1[0xf] = 0;
  param_1[0xe] = 0;
  param_1[0xc] = 0;
  param_1[0xb] = 0;
  param_1[8] = 0;
  param_1[7] = 0;
  param_1[6] = 0;
  *(undefined1 *)((int)param_1 + 0xf) = 0;
  *(undefined1 *)((int)param_1 + 0xe) = 0;
  *(undefined2 *)(param_1 + 3) = 0;
  param_1[2] = 0;
  param_1[1] = 0;
  *param_1 = 0;
  param_1[4] = 140000;
  param_1[5] = 140000;
  param_1[9] = 0x40;
  param_1[0xd] = 100;
  param_1[10] = 100;
  *(undefined2 *)(param_1 + 0x50) = 4;
  return param_1;
}



void __thiscall FUN_10007b80(int *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar1 = param_1[0xe];
  param_1[0xe] = param_2;
  iVar1 = param_2 - iVar1;
  if (param_1[7] < iVar1) {
    param_1[7] = iVar1;
  }
  if (iVar1 < param_1[8]) {
    param_1[8] = iVar1;
  }
  if ((short)param_1[3] == 0) {
    iVar1 = (param_2 - param_1[(param_1[0xf] - (uint)*(ushort *)(param_1 + 0x50) & 0x3f) + 0x10]) /
            ((int)((uint)*(ushort *)(param_1 + 0x50) * 5) >> 2);
    if (0 < iVar1) {
      param_1[5] = (int)(2000000000 / (longlong)iVar1);
    }
  }
  else {
    *(short *)(param_1 + 3) = (short)param_1[3] + -1;
  }
  param_1[param_1[0xf] + 0x10] = param_2;
  param_1[0xf] = param_1[0xf] + 1U & 0x3f;
  if (*(char *)((int)param_1 + 0xf) == '\0') {
    iVar1 = param_1[5];
    param_1[4] = iVar1;
  }
  else {
    iVar1 = param_1[5];
    iVar4 = param_1[2] - (*param_1 * iVar1) / 0x4c4b4;
    iVar2 = param_1[6] - iVar4;
    if (param_1[0xb] < iVar2) {
      param_1[0xb] = iVar2;
    }
    if (iVar2 < param_1[0xc]) {
      param_1[0xc] = iVar2;
    }
    iVar3 = param_1[9];
    param_1[9] = iVar3 + -1;
    if (iVar3 == 0) {
      param_1[10] = param_1[0xb] - param_1[0xc];
      iVar3 = param_1[0xd];
      param_1[0xd] = iVar3 + -500;
      param_1[9] = 0x40;
      if (iVar3 + -500 < 200) {
        param_1[0xd] = 200;
      }
      if (param_1[7] - param_1[8] < 0x2711) {
        if (param_1[7] - param_1[8] < 0x1771) {
          *(undefined2 *)(param_1 + 0x50) = 0x10;
        }
        else {
          *(undefined2 *)(param_1 + 0x50) = 0x20;
        }
      }
      else {
        *(undefined2 *)(param_1 + 0x50) = 0x40;
      }
      param_1[7] = 0;
      param_1[0xc] = 0;
      param_1[0xb] = 0;
      param_1[8] = 1000000;
    }
    if ((iVar2 < -0x300) || (0x300 < iVar2)) {
      iVar3 = 2000;
      iVar2 = param_1[6] + (iVar2 / 0x300) * -0x300;
      param_1[6] = iVar2;
      iVar2 = iVar2 - iVar4;
    }
    else if ((iVar2 < -param_1[10]) || (param_1[10] < iVar2)) {
      iVar3 = 2000;
    }
    else {
      iVar3 = param_1[0xd];
    }
    param_1[4] = iVar2 * iVar3 + iVar1;
    param_1[6] = param_1[6] + 8;
  }
  if (500000 < iVar1) {
    param_1[5] = 500000;
    iVar1 = param_1[5];
  }
  if (iVar1 < 20000) {
    param_1[5] = 20000;
  }
  iVar1 = param_1[4];
  if (500000 < iVar1) {
    param_1[4] = 500000;
    iVar1 = param_1[4];
  }
  if (iVar1 < 20000) {
    param_1[4] = 20000;
  }
  return;
}



void __fastcall FUN_10007db0(int param_1)

{
  FUN_10007ea0();
  *(undefined1 *)(param_1 + 0xf) = 1;
  *(undefined4 *)(param_1 + 0x18) = 0;
  return;
}



void __fastcall FUN_10007dd0(int param_1)

{
  FUN_10007ea0();
  *(undefined1 *)(param_1 + 0xf) = 1;
  return;
}



void __thiscall FUN_10007df0(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x18) = param_2;
  return;
}



undefined4 __fastcall FUN_10007e00(int param_1)

{
  return *(undefined4 *)(param_1 + 0x18);
}



undefined4 __fastcall FUN_10007e10(int param_1)

{
  return *(undefined4 *)(param_1 + 0x10);
}



undefined4 __fastcall FUN_10007e20(int param_1)

{
  return *(undefined4 *)(param_1 + 0x14);
}



void __thiscall FUN_10007e30(int param_1,undefined4 param_2,undefined4 param_3)

{
  *(undefined4 *)(param_1 + 8) = param_3;
  *(undefined4 *)(param_1 + 4) = param_2;
  return;
}



undefined4 __fastcall FUN_10007e50(undefined4 *param_1)

{
  return *param_1;
}



void __thiscall FUN_10007e60(undefined4 *param_1,undefined4 param_2)

{
  *param_1 = param_2;
  return;
}



undefined1 __fastcall FUN_10007e70(int param_1)

{
  return *(undefined1 *)(param_1 + 0xe);
}



undefined1 __fastcall FUN_10007e80(int param_1)

{
  return *(undefined1 *)(param_1 + 0xf);
}



void __thiscall FUN_10007e90(int param_1,undefined1 param_2)

{
  *(undefined1 *)(param_1 + 0xe) = param_2;
  return;
}



void __fastcall FUN_10007ea0(int param_1)

{
  undefined2 uVar1;
  
  *(undefined4 *)(param_1 + 0x10) = 500000;
  uVar1 = *(undefined2 *)(param_1 + 0x140);
  *(undefined2 *)(param_1 + 0x140) = 4;
  *(undefined2 *)(param_1 + 0xc) = uVar1;
  *(undefined4 *)(param_1 + 0x34) = 0x640;
  *(undefined4 *)(param_1 + 0x24) = 0x40;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 1000000;
  *(undefined4 *)(param_1 + 0x28) = 100;
  return;
}



void __fastcall FUN_10007ef0(int param_1)

{
  *(undefined1 *)(param_1 + 0xf) = 0;
  return;
}



void __thiscall FUN_10007f30(undefined4 param_1,uint param_2)

{
  FUN_100081b4();
  if ((param_2 & 1) == 0) {
    return;
  }
  FUN_1002dde0(param_1);
  return;
}



void __thiscall FUN_10007f60(undefined4 param_1,uint param_2)

{
  FUN_1000d4d0();
  if ((param_2 & 1) == 0) {
    return;
  }
  FUN_1002dde0(param_1);
  return;
}



undefined4 * __thiscall FUN_10008050(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  
  *param_1 = &PTR_LAB_10031d14;
  iVar1 = 0x41;
  puVar2 = param_2;
  puVar3 = param_1;
  while( true ) {
    puVar3 = puVar3 + 1;
    puVar2 = puVar2 + 1;
    if (iVar1 == 0) break;
    iVar1 = iVar1 + -1;
    *puVar3 = *puVar2;
  }
  *(undefined1 *)puVar3 = *(undefined1 *)puVar2;
  puVar2 = (undefined4 *)((int)param_2 + 0x109);
  puVar3 = (undefined4 *)((int)param_1 + 0x109);
  for (iVar1 = 0x41; iVar1 != 0; iVar1 = iVar1 + -1) {
    *puVar3 = *puVar2;
    puVar2 = puVar2 + 1;
    puVar3 = puVar3 + 1;
  }
  *(undefined1 *)puVar3 = *(undefined1 *)puVar2;
  puVar2 = (undefined4 *)((int)param_2 + 0x20e);
  puVar3 = (undefined4 *)((int)param_1 + 0x20e);
  for (iVar1 = 0x41; iVar1 != 0; iVar1 = iVar1 + -1) {
    *puVar3 = *puVar2;
    puVar2 = puVar2 + 1;
    puVar3 = puVar3 + 1;
  }
  *(undefined1 *)puVar3 = *(undefined1 *)puVar2;
  return param_1;
}



undefined4 * __thiscall FUN_10008100(undefined4 *param_1,char *param_2)

{
  char cVar1;
  char *pcVar2;
  
  pcVar2 = (char *)(param_1 + 1);
  *param_1 = &PTR_LAB_10031d34;
  do {
    cVar1 = *param_2;
    param_2 = param_2 + 1;
    *pcVar2 = cVar1;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  return param_1;
}



undefined4 * __thiscall FUN_10008104(undefined4 *param_1,char *param_2)

{
  char cVar1;
  char *pcVar2;
  
  pcVar2 = (char *)(param_1 + 1);
  *param_1 = &PTR_LAB_10031d34;
  do {
    cVar1 = *param_2;
    param_2 = param_2 + 1;
    *pcVar2 = cVar1;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  return param_1;
}



void __fastcall FUN_10008130(undefined4 *param_1)

{
  *param_1 = &PTR_LAB_10031d34;
  return;
}



char * __thiscall FUN_10008160(char *param_1,char *param_2,char *param_3,char *param_4)

{
  char cVar1;
  char *pcVar2;
  
  pcVar2 = param_1;
  do {
    cVar1 = *param_2;
    param_2 = param_2 + 1;
    *pcVar2 = cVar1;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  pcVar2 = param_1 + 0x41;
  do {
    cVar1 = *param_3;
    param_3 = param_3 + 1;
    *pcVar2 = cVar1;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  pcVar2 = param_1 + 0x146;
  do {
    cVar1 = *param_4;
    param_4 = param_4 + 1;
    *pcVar2 = cVar1;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  return param_1;
}



undefined4 __thiscall FUN_100081b0(char *param_1,undefined4 param_2)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  
  pcVar3 = &DAT_1014fc50;
  pcVar2 = param_1;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
    *pcVar2 = cVar1;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  pcVar2 = param_1 + 0x41;
  pcVar3 = &DAT_1014fc50;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
    *pcVar2 = cVar1;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  param_1 = param_1 + 0x146;
  pcVar2 = &DAT_1014fc50;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
    *param_1 = cVar1;
    param_1 = param_1 + 1;
  } while (cVar1 != '\0');
  return param_2;
}



void __fastcall FUN_100081b4(char *param_1)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  
  pcVar3 = &DAT_1014fc50;
  pcVar2 = param_1;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
    *pcVar2 = cVar1;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  pcVar2 = param_1 + 0x41;
  pcVar3 = &DAT_1014fc50;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
    *pcVar2 = cVar1;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  param_1 = param_1 + 0x146;
  pcVar2 = &DAT_1014fc50;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
    *param_1 = cVar1;
    param_1 = param_1 + 1;
  } while (cVar1 != '\0');
  return;
}



void __fastcall FUN_100082d0(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  *(undefined1 *)(param_1 + 2) = 0;
  return;
}



void __fastcall FUN_10008380(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_100084c0;
  local_8 = 0;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  for (piVar1 = (int *)*param_1; piVar1 != (int *)0x0; piVar1 = (int *)piVar1[1]) {
    if (*piVar1 != 0) {
      FUN_10007f30(1);
    }
  }
  local_8 = 0xffffffff;
  while (*param_1 != 0) {
    iVar2 = *param_1;
    iVar3 = *(int *)(iVar2 + 4);
    *param_1 = iVar3;
    if (iVar3 == 0) {
      param_1[1] = 0;
    }
    FUN_1002dde0(iVar2);
  }
  *param_1 = 0;
  param_1[1] = 0;
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_100084d0(undefined4 *param_1,undefined4 param_2)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10008540;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10008104(param_2);
  *param_1 = &PTR_LAB_10031d24;
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_10008550(undefined4 *param_1)

{
  *param_1 = &PTR_LAB_10031d34;
  return;
}



void FUN_10008750(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  int local_20;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10008810;
  local_10 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_10;
  FUN_1000c780(param_1,param_2,param_3);
  local_8 = 1;
  (**(code **)(local_20 + 0xc))(param_5,param_4);
  FUN_1000c8b0();
  local_8 = 0;
  FUN_1000c810();
  ExceptionList = local_10;
  return;
}



void FUN_10008820(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int local_1c;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_100088b0;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_1000c700(param_1);
  local_8 = 0;
  (**(code **)(local_1c + 4))(param_3,param_2);
  FUN_1000c8b0();
  local_8 = 0xffffffff;
  FUN_1000c810();
  ExceptionList = local_10;
  return;
}



void * FUN_100088c0(undefined4 param_1)

{
  undefined4 uVar1;
  void *pvVar2;
  undefined4 uVar3;
  int local_30;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_100089f0;
  local_10 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_10;
  FUN_1000c700(param_1);
  local_8 = 1;
  uVar1 = (**(code **)(local_30 + 0x18))();
  pvVar2 = operator_new(0x14);
  if (pvVar2 == (void *)0x0) {
    pvVar2 = (void *)0x0;
  }
  else {
    FUN_10006fd0(uVar1);
  }
  uVar3 = FUN_10007210();
  (**(code **)(local_30 + 4))(uVar1,uVar3);
  FUN_1000c8b0();
  local_8 = 0;
  FUN_1000c810();
  ExceptionList = local_10;
  return pvVar2;
}



undefined4 FUN_10008a00(undefined4 param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10008af0;
  local_10 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_10;
  puVar1 = (undefined4 *)FUN_1000d3c0();
  uVar2 = FUN_1000d2b0(param_1);
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  ExceptionList = local_10;
  return uVar2;
}



undefined4 * __thiscall
FUN_10008b00(undefined4 *param_1,undefined4 param_2,char *param_3,undefined2 param_4)

{
  char cVar1;
  char *pcVar2;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10008b90;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10008050(param_2);
  *param_1 = &PTR_LAB_10031d44;
  pcVar2 = (char *)(param_1 + 0xc5);
  *(undefined2 *)((int)param_1 + 0x31a) = param_4;
  do {
    cVar1 = *param_3;
    param_3 = param_3 + 1;
    *pcVar2 = cVar1;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  ExceptionList = local_10;
  return param_1;
}



void __fastcall FUN_10008ba0(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10008c10;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  *param_1 = &PTR_LAB_10031d44;
  local_8 = 0xffffffff;
  FUN_1000bb90();
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_10008cb0(undefined4 *param_1,int param_2)

{
  char cVar1;
  undefined2 uVar2;
  void *pvVar3;
  char *pcVar4;
  char *pcVar5;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10008d70;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10006ce0();
  local_8 = 0;
  pcVar5 = (char *)(param_2 + 0x314);
  *param_1 = &PTR_LAB_10031d54;
  uVar2 = *(undefined2 *)(param_2 + 0x31a);
  param_1[3] = 0;
  *(undefined2 *)((int)param_1 + 10) = uVar2;
  pcVar4 = (char *)(param_1 + 1);
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
    *pcVar4 = cVar1;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  pvVar3 = operator_new(8);
  if (pvVar3 == (void *)0x0) {
    pvVar3 = (void *)0x0;
  }
  else {
    FUN_1000d480(param_2);
  }
  param_1[3] = pvVar3;
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_10008d80(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10008e00;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  *param_1 = &PTR_LAB_10031d54;
  local_8 = 0;
  if (param_1[3] != 0) {
    FUN_10007f60(1);
  }
  param_1[3] = 0;
  local_8 = 0xffffffff;
  FUN_10006cf0();
  ExceptionList = local_10;
  return;
}



undefined4 FUN_10008fb0(void)

{
  return DAT_10054760;
}



void FUN_10009060(int param_1,int param_2,int param_3)

{
  int iVar1;
  
  iVar1 = 0;
  if (0 < param_3) {
    do {
      if (*(char *)(iVar1 + param_2) == '\0') break;
      *(char *)(iVar1 + param_1) = *(char *)(iVar1 + param_2);
      iVar1 = iVar1 + 1;
    } while (iVar1 < param_3);
  }
  *(undefined1 *)(iVar1 + param_1) = 0;
  return;
}



void FUN_10009120(byte *param_1,void *param_2)

{
  byte bVar1;
  
  bVar1 = *param_1;
  memmove(param_2,param_1 + 1,(uint)bVar1);
  *(undefined1 *)((uint)bVar1 + (int)param_2) = 0;
  return;
}



undefined4 * __thiscall FUN_100091b0(undefined4 *param_1,char *param_2)

{
  char cVar1;
  HANDLE pvVar2;
  char *pcVar3;
  undefined1 auStack_3a [18];
  undefined1 local_28 [12];
  undefined1 *local_1c;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10009280;
  local_10 = ExceptionList;
  local_14 = auStack_3a + -0x12;
  pcVar3 = (char *)(param_1 + 1);
  ExceptionList = &local_10;
  *param_1 = 0;
  do {
    cVar1 = *param_2;
    param_2 = param_2 + 1;
    *pcVar3 = cVar1;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  local_8 = 0;
  pvVar2 = CreateSemaphoreA((LPSECURITY_ATTRIBUTES)0x0,1,1,(LPCSTR)(param_1 + 1));
  *param_1 = pvVar2;
  if (pvVar2 == (HANDLE)0x0) {
    local_1c = local_28;
    FUN_100010f0();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_1c,(ThrowInfo *)&DAT_10030570);
  }
  ExceptionList = local_10;
  return param_1;
}



void __fastcall FUN_10009290(int *param_1)

{
  if (*param_1 != 0) {
    CloseHandle((HANDLE)*param_1);
    *param_1 = 0;
  }
  return;
}



void __fastcall FUN_100092c0(undefined4 *param_1)

{
  ReleaseSemaphore((HANDLE)*param_1,1,(LPLONG)0x0);
  return;
}



void __fastcall FUN_100092f0(undefined4 *param_1)

{
  DWORD DVar1;
  undefined1 local_24 [12];
  undefined1 local_18 [12];
  undefined1 *local_c;
  
  DVar1 = WaitForSingleObject((HANDLE)*param_1,10000);
  if (DVar1 == 0) {
    return;
  }
  if (DVar1 == 0x102) {
    FUN_100010f0();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_24,(ThrowInfo *)&DAT_10030570);
  }
  local_c = local_18;
  FUN_100010f0();
                    // WARNING: Subroutine does not return
  _CxxThrowException(local_c,(ThrowInfo *)&DAT_10030570);
}



undefined4 FUN_10009370(LPCSTR param_1)

{
  HANDLE hObject;
  
  hObject = OpenSemaphoreA(0x1f0003,0,param_1);
  if (hObject == (HANDLE)0x0) {
    return 0;
  }
  CloseHandle(hObject);
  return 1;
}



undefined4 * __fastcall FUN_100093c0(undefined4 *param_1)

{
  HANDLE pvVar1;
  undefined1 auStack_18 [16];
  
  *param_1 = 0;
  pvVar1 = CreateMutexA((LPSECURITY_ATTRIBUTES)0x0,0,(LPCSTR)0x0);
  *param_1 = pvVar1;
  if (pvVar1 == (HANDLE)0x0) {
    FUN_100010f0();
                    // WARNING: Subroutine does not return
    _CxxThrowException(auStack_18,(ThrowInfo *)&DAT_10030570);
  }
  return param_1;
}



undefined4 * __fastcall FUN_100093c4(undefined4 *param_1)

{
  HANDLE pvVar1;
  undefined1 local_18 [16];
  
  *param_1 = 0;
  pvVar1 = CreateMutexA((LPSECURITY_ATTRIBUTES)0x0,0,(LPCSTR)0x0);
  *param_1 = pvVar1;
  if (pvVar1 == (HANDLE)0x0) {
    FUN_100010f0();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_18,(ThrowInfo *)&DAT_10030570);
  }
  return param_1;
}



void __fastcall FUN_10009420(undefined4 *param_1)

{
  if ((HANDLE)*param_1 != (HANDLE)0x0) {
    CloseHandle((HANDLE)*param_1);
    *param_1 = 0;
  }
  return;
}



undefined4 __fastcall FUN_10009450(undefined4 *param_1)

{
  DWORD DVar1;
  
  DVar1 = WaitForSingleObject((HANDLE)*param_1,0);
  if (DVar1 == 0) {
    return 1;
  }
  return 0;
}



undefined4 __fastcall FUN_10009454(undefined4 *param_1)

{
  DWORD DVar1;
  
  DVar1 = WaitForSingleObject((HANDLE)*param_1,0);
  if (DVar1 == 0) {
    return 1;
  }
  return 0;
}



void __fastcall FUN_10009480(undefined4 *param_1)

{
  WaitForSingleObject((HANDLE)*param_1,4000);
  return;
}



void __fastcall FUN_100094a0(undefined4 *param_1)

{
  ReleaseMutex((HANDLE)*param_1);
  return;
}



uint * __thiscall FUN_100094c0(uint *param_1,uint param_2)

{
  void *pvVar1;
  
  *param_1 = param_2;
  param_1[4] = 0;
  param_1[3] = 0;
  param_1[2] = 0;
  param_1[1] = 0;
  pvVar1 = operator_new(param_2);
  param_1[4] = (uint)pvVar1;
  return param_1;
}



uint * __thiscall FUN_100094c4(uint *param_1,uint param_2)

{
  void *pvVar1;
  
  *param_1 = param_2;
  param_1[4] = 0;
  param_1[3] = 0;
  param_1[2] = 0;
  param_1[1] = 0;
  pvVar1 = operator_new(param_2);
  param_1[4] = (uint)pvVar1;
  return param_1;
}



void __fastcall FUN_10009500(int param_1)

{
  FUN_1002dde0(*(undefined4 *)(param_1 + 0x10));
  *(undefined4 *)(param_1 + 0x10) = 0;
  return;
}



undefined4 __thiscall FUN_10009520(int *param_1,int param_2,uint param_3)

{
  undefined1 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined1 local_14 [4];
  
  iVar3 = param_1[2];
  if (*param_1 - param_1[3] < (int)(param_3 + 2)) {
    return 0xb;
  }
  FUN_10004090(local_14,param_3 & 0xffff);
  iVar2 = 0;
  do {
    iVar4 = iVar2 + 1;
    *(undefined1 *)(param_1[4] + iVar3) = local_14[iVar2];
    iVar3 = iVar3 + 1;
    if (iVar3 == *param_1) {
      iVar3 = 0;
    }
    iVar2 = iVar2 + 1;
  } while (iVar2 < 2);
  iVar2 = 0;
  if (0 < (int)param_3) {
    do {
      iVar4 = iVar4 + 1;
      puVar1 = (undefined1 *)(iVar2 + param_2);
      iVar2 = iVar2 + 1;
      *(undefined1 *)(param_1[4] + iVar3) = *puVar1;
      iVar3 = iVar3 + 1;
      if (iVar3 == *param_1) {
        iVar3 = 0;
      }
    } while (iVar2 < (int)param_3);
  }
  param_1[2] = iVar3;
  param_1[3] = param_1[3] + iVar4;
  return 0xc;
}



undefined4 __thiscall FUN_100095e0(int *param_1,int param_2,int param_3,uint *param_4)

{
  undefined1 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined1 local_24 [4];
  undefined1 auStack_20 [12];
  uint uStack_14;
  
  iVar2 = param_1[3];
  iVar3 = param_1[1];
  *param_4 = 0;
  if (iVar2 == 0) {
    return 10;
  }
  iVar2 = 0;
  do {
    iVar4 = iVar2 + 1;
    puVar1 = (undefined1 *)(param_1[4] + iVar3);
    iVar3 = iVar3 + 1;
    local_24[iVar2] = *puVar1;
    if (iVar3 == *param_1) {
      iVar3 = 0;
    }
    iVar2 = iVar2 + 1;
  } while (iVar2 < 2);
  uStack_14 = FUN_10004060(local_24);
  uStack_14 = uStack_14 & 0xffff;
  if (param_3 < (int)uStack_14) {
    FUN_100010f0();
                    // WARNING: Subroutine does not return
    _CxxThrowException(auStack_20,(ThrowInfo *)&DAT_10030570);
  }
  iVar2 = 0;
  if (uStack_14 != 0) {
    do {
      puVar1 = (undefined1 *)(param_1[4] + iVar3);
      iVar3 = iVar3 + 1;
      *(undefined1 *)(iVar2 + param_2) = *puVar1;
      iVar2 = iVar2 + 1;
      iVar4 = iVar4 + 1;
      if (iVar3 == *param_1) {
        iVar3 = 0;
      }
    } while (iVar2 < (int)uStack_14);
  }
  param_1[1] = iVar3;
  param_1[3] = param_1[3] - iVar4;
  *param_4 = uStack_14;
  return 0xc;
}



undefined4 __thiscall FUN_100096d0(int *param_1,uint *param_2)

{
  undefined1 *puVar1;
  uint uVar2;
  int iVar3;
  undefined1 *puVar4;
  undefined1 local_18 [2];
  undefined1 local_16 [6];
  
  puVar4 = local_18;
  iVar3 = param_1[1];
  if (param_1[3] == 0) {
    return 10;
  }
  do {
    puVar1 = (undefined1 *)(param_1[4] + iVar3);
    iVar3 = iVar3 + 1;
    *puVar4 = *puVar1;
    puVar4 = puVar4 + 1;
    if (iVar3 == *param_1) {
      iVar3 = 0;
    }
  } while ((int)puVar4 < (int)local_16);
  uVar2 = FUN_10004060(local_18);
  *param_2 = uVar2 & 0xffff;
  return 0xc;
}



undefined4 __thiscall FUN_10009740(int *param_1,int param_2)

{
  if (*param_1 - param_1[3] < param_2 + 2) {
    return 0;
  }
  return 1;
}



void __thiscall FUN_10009770(int *param_1,int param_2)

{
  undefined1 *puVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = 0;
  iVar3 = param_1[1];
  if (0 < param_1[3]) {
    do {
      puVar1 = (undefined1 *)(param_1[4] + iVar3);
      iVar3 = iVar3 + 1;
      *(undefined1 *)(iVar2 + param_2) = *puVar1;
      if (iVar3 == *param_1) {
        iVar3 = 0;
      }
      iVar2 = iVar2 + 1;
    } while (iVar2 < param_1[3]);
  }
  param_1[1] = iVar3;
  param_1[3] = 0;
  return;
}



void __fastcall FUN_100097b0(int param_1)

{
  *(undefined4 *)(param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 4) = 0;
  return;
}



undefined4 __thiscall FUN_100097c0(undefined4 param_1,undefined4 param_2)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10009860;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_100094c4(param_2);
  local_8 = 0;
  FUN_100093c4();
  ExceptionList = local_10;
  return param_1;
}



void __fastcall FUN_10009870(int param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10009940;
  local_10 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_10;
  if (*(int *)(param_1 + 0x14) != 0) {
    ExceptionList = &local_10;
    CloseHandle(*(HANDLE *)(param_1 + 0x14));
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  local_8 = 0xffffffff;
  FUN_1002dde0(*(undefined4 *)(param_1 + 0x10));
  *(undefined4 *)(param_1 + 0x10) = 0;
  ExceptionList = local_10;
  return;
}



undefined1 FUN_10009950(void)

{
  undefined1 uVar1;
  
  uVar1 = FUN_10009454();
  return uVar1;
}



void __fastcall FUN_10009970(int param_1)

{
  ReleaseMutex(*(HANDLE *)(param_1 + 0x14));
  return;
}



void FUN_10009990(ushort *param_1,int param_2)

{
  for (; 0 < param_2; param_2 = param_2 + -1) {
    *param_1 = *param_1 >> 8 | *param_1 << 8;
    param_1 = param_1 + 1;
  }
  return;
}



void FUN_100099d0(undefined4 param_1,undefined4 *param_2,short *param_3,byte param_4,byte param_5,
                 byte param_6,int param_7)

{
  byte *pbVar1;
  byte bVar2;
  byte *pbVar3;
  short *psVar4;
  uint uVar5;
  uint uVar6;
  
  uVar5 = (uint)param_5;
  uVar6 = (uint)param_4;
  if (uVar5 == 1) {
    for (uVar5 = param_7 * uVar6 >> 2; uVar5 != 0; uVar5 = uVar5 - 1) {
      *(undefined4 *)param_3 = *param_2;
      param_2 = param_2 + 1;
      param_3 = param_3 + 2;
    }
    for (uVar6 = param_7 * uVar6 & 3; uVar6 != 0; uVar6 = uVar6 - 1) {
      *(undefined1 *)param_3 = *(undefined1 *)param_2;
      param_2 = (undefined4 *)((int)param_2 + 1);
      param_3 = (short *)((int)param_3 + 1);
    }
    return;
  }
  if (uVar6 == 2) {
    psVar4 = (short *)((int)param_2 + (uint)param_6 * 2);
    for (; 4 < param_7; param_7 = param_7 + -4) {
      *param_3 = *psVar4;
      param_3[1] = CONCAT11(*(undefined1 *)((int)psVar4 + uVar5 * 2 + 1),(char)psVar4[uVar5]);
      param_3[2] = CONCAT11(*(undefined1 *)((int)psVar4 + uVar5 * 4 + 1),(char)psVar4[uVar5 * 2]);
      param_3[3] = psVar4[uVar5 * 3];
      param_3 = param_3 + 4;
      psVar4 = psVar4 + uVar5 * 4;
    }
    if (0 < param_7) {
      do {
        param_7 = param_7 + -1;
        *param_3 = *psVar4;
        param_3 = param_3 + 1;
        psVar4 = psVar4 + uVar5;
      } while (0 < param_7);
    }
  }
  else if (uVar6 == 1) {
    pbVar3 = (byte *)((int)param_2 + (uint)param_6);
    for (; 4 < param_7; param_7 = param_7 + -4) {
      *param_3 = (ushort)*pbVar3 << 8;
      param_3[1] = (ushort)pbVar3[uVar5] << 8;
      param_3[2] = (ushort)pbVar3[uVar5 * 2] << 8;
      pbVar1 = pbVar3 + uVar5 * 3;
      pbVar3 = pbVar3 + uVar5 * 4;
      param_3[3] = (ushort)*pbVar1 << 8;
      param_3 = param_3 + 4;
    }
    for (; 0 < param_7; param_7 = param_7 + -1) {
      bVar2 = *pbVar3;
      pbVar3 = pbVar3 + uVar5;
      *param_3 = (ushort)bVar2 << 8;
      param_3 = param_3 + 1;
    }
  }
  return;
}



void __fastcall FUN_100099dc(short *param_1,undefined4 *param_2)

{
  byte *pbVar1;
  byte bVar2;
  byte *pbVar3;
  short *psVar4;
  uint uVar5;
  uint uVar6;
  byte in_stack_00000010;
  byte in_stack_00000014;
  byte in_stack_00000018;
  int in_stack_0000001c;
  
  uVar5 = (uint)in_stack_00000014;
  uVar6 = (uint)in_stack_00000010;
  if (uVar5 == 1) {
    for (uVar5 = in_stack_0000001c * uVar6 >> 2; uVar5 != 0; uVar5 = uVar5 - 1) {
      *(undefined4 *)param_1 = *param_2;
      param_2 = param_2 + 1;
      param_1 = param_1 + 2;
    }
    for (uVar6 = in_stack_0000001c * uVar6 & 3; uVar6 != 0; uVar6 = uVar6 - 1) {
      *(undefined1 *)param_1 = *(undefined1 *)param_2;
      param_2 = (undefined4 *)((int)param_2 + 1);
      param_1 = (short *)((int)param_1 + 1);
    }
    return;
  }
  if (uVar6 == 2) {
    psVar4 = (short *)((int)param_2 + (uint)in_stack_00000018 * 2);
    for (; 4 < in_stack_0000001c; in_stack_0000001c = in_stack_0000001c + -4) {
      *param_1 = *psVar4;
      param_1[1] = CONCAT11(*(undefined1 *)((int)psVar4 + uVar5 * 2 + 1),(char)psVar4[uVar5]);
      param_1[2] = CONCAT11(*(undefined1 *)((int)psVar4 + uVar5 * 4 + 1),(char)psVar4[uVar5 * 2]);
      param_1[3] = psVar4[uVar5 * 3];
      param_1 = param_1 + 4;
      psVar4 = psVar4 + uVar5 * 4;
    }
    if (0 < in_stack_0000001c) {
      do {
        in_stack_0000001c = in_stack_0000001c + -1;
        *param_1 = *psVar4;
        param_1 = param_1 + 1;
        psVar4 = psVar4 + uVar5;
      } while (0 < in_stack_0000001c);
    }
  }
  else if (uVar6 == 1) {
    pbVar3 = (byte *)((int)param_2 + (uint)in_stack_00000018);
    for (; 4 < in_stack_0000001c; in_stack_0000001c = in_stack_0000001c + -4) {
      *param_1 = (ushort)*pbVar3 << 8;
      param_1[1] = (ushort)pbVar3[uVar5] << 8;
      param_1[2] = (ushort)pbVar3[uVar5 * 2] << 8;
      pbVar1 = pbVar3 + uVar5 * 3;
      pbVar3 = pbVar3 + uVar5 * 4;
      param_1[3] = (ushort)*pbVar1 << 8;
      param_1 = param_1 + 4;
    }
    for (; 0 < in_stack_0000001c; in_stack_0000001c = in_stack_0000001c + -1) {
      bVar2 = *pbVar3;
      pbVar3 = pbVar3 + uVar5;
      *param_1 = (ushort)bVar2 << 8;
      param_1 = param_1 + 1;
    }
  }
  return;
}



void FUN_10009b20(int *param_1,short *param_2,undefined2 *param_3,char param_4,byte param_5,
                 undefined4 param_6,int param_7)

{
  short sVar1;
  byte bVar2;
  int iVar3;
  int local_14;
  
  if (param_5 == 1) {
    FUN_100099dc();
    param_1[2] = 0;
    param_1[1] = 0;
    return;
  }
  local_14 = param_7;
  if (param_4 == '\x02') {
    while (0 < local_14) {
      local_14 = local_14 + -1;
      iVar3 = 0;
      if (*param_1 == 0x8000) {
        bVar2 = 0;
        if (param_5 != 0) {
          do {
            sVar1 = *param_2;
            bVar2 = bVar2 + 1;
            param_2 = param_2 + 1;
            iVar3 = iVar3 + sVar1;
          } while (bVar2 < param_5);
        }
      }
      else {
        bVar2 = 0;
        if (param_5 != 0) {
          do {
            sVar1 = *param_2;
            bVar2 = bVar2 + 1;
            param_2 = param_2 + 1;
            iVar3 = iVar3 + ((int)sVar1 * *param_1 >> 0xf);
          } while (bVar2 < param_5);
        }
      }
      if (param_1[1] < iVar3) {
        param_1[1] = iVar3;
      }
      else if (iVar3 < param_1[2]) {
        param_1[2] = iVar3;
      }
      if (iVar3 < 0x8000) {
        if (iVar3 < -0x8000) {
          iVar3 = -0x8000;
        }
      }
      else {
        iVar3 = 0x7fff;
      }
      *param_3 = (short)iVar3;
      param_3 = param_3 + 1;
    }
  }
  return;
}



void FUN_10009c60(int *param_1,undefined4 param_2,byte param_3,byte param_4,char param_5,int param_6
                 ,char param_7)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  ushort *puVar5;
  uint uVar6;
  ushort *puVar7;
  uint uVar8;
  int iVar9;
  undefined4 uStack_40;
  int local_20;
  
  uVar1 = FUN_10003920();
  uVar2 = FUN_10003930();
  puVar7 = (ushort *)(uint)param_4;
  uVar6 = (uint)param_3;
  uVar8 = (int)puVar7 * uVar6 & 0xff;
  iVar3 = (int)(0x4000 / (ulonglong)uVar8);
  local_20 = 0;
  if (0 < param_6) {
    do {
      iVar4 = FUN_10004630(iVar3,param_6);
      (**(code **)(*param_1 + 4))(uVar8 * iVar4,uVar1);
      if (param_7 != '\0') {
        iVar9 = iVar3 * iVar4;
        puVar5 = puVar7;
        if (0 < iVar9) {
          do {
            iVar9 = iVar9 + -1;
            *puVar5 = *puVar5 >> 8 | *puVar5 << 8;
            puVar5 = puVar5 + 1;
          } while (0 < iVar9);
          local_20 = param_6;
          param_7 = param_5;
        }
      }
      FUN_100099d0(0,puVar7,uVar8,uVar1,iVar3,uStack_40,iVar4);
      FUN_10003b00(local_20 * uVar6,uVar6 * iVar4,uVar2);
      param_6 = param_6 - iVar4;
      local_20 = local_20 + iVar4;
    } while (0 < param_6);
  }
  return;
}



void FUN_10009dd0(int *param_1,undefined4 param_2,byte param_3,byte param_4,char param_5,int param_6
                 ,char param_7)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  ushort *puVar5;
  ushort *puVar6;
  uint uVar7;
  int iVar8;
  int *unaff_retaddr;
  undefined4 uStack_40;
  
  iVar1 = FUN_10003920();
  iVar2 = FUN_10003930();
  puVar6 = (ushort *)(uint)param_4;
  uVar7 = (int)puVar6 * (uint)param_3 & 0xff;
  iVar3 = (int)(0x4000 / (ulonglong)uVar7);
  if (0 < param_6) {
    do {
      iVar4 = FUN_10004630(iVar3,param_6);
      (**(code **)(*param_1 + 4))(uVar7 * iVar4,iVar1);
      if (param_7 != '\0') {
        iVar8 = iVar3 * iVar4;
        puVar5 = puVar6;
        if (0 < iVar8) {
          do {
            iVar8 = iVar8 + -1;
            *puVar5 = *puVar5 >> 8 | *puVar5 << 8;
            puVar5 = puVar5 + 1;
          } while (0 < iVar8);
          param_7 = param_5;
        }
      }
      FUN_100099d0(0,puVar6,uVar7,iVar1,iVar3,uStack_40,iVar4);
      (**(code **)(*unaff_retaddr + 0x34))(iVar2 * iVar1,iVar1 * iVar4,uVar7);
      param_6 = param_6 - iVar4;
    } while (0 < param_6);
  }
  return;
}



void FUN_10009f40(int *param_1,undefined4 param_2,byte param_3,byte param_4,int param_5,char param_6
                 ,undefined1 *param_7)

{
  int iVar1;
  ushort *puVar2;
  int iVar3;
  int iVar4;
  int *unaff_retaddr;
  int iStack_4c;
  undefined4 uStack_48;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  uint uStack_38;
  ushort *puStack_34;
  undefined4 uStack_30;
  ushort *puStack_2c;
  int iStack_28;
  uint uStack_24;
  int iStack_20;
  undefined1 *puStack_1c;
  undefined1 *puStack_18;
  
  puStack_1c = (undefined1 *)(**(code **)(*param_1 + 0x10))();
  uStack_48 = 0x8000;
  iStack_40 = 0;
  iStack_44 = 0;
  puStack_2c = (ushort *)FUN_10003920();
  uStack_30 = FUN_10003930();
  puStack_34 = (ushort *)(uint)param_4;
  uStack_24 = (uint)param_3;
  uStack_38 = (int)puStack_34 * uStack_24 & 0xff;
  iStack_3c = (int)(0x4000 / (ulonglong)uStack_38);
  iStack_28 = 0;
  iVar4 = param_5;
  if (0 < param_5) {
    do {
      iVar1 = FUN_10004630(iStack_3c,iVar4);
      (**(code **)(*param_1 + 4))(uStack_38 * iVar1,puStack_2c);
      if (param_6 != '\0') {
        puVar2 = puStack_2c;
        for (iVar3 = (int)puStack_34 * iVar1; 0 < iVar3; iVar3 = iVar3 + -1) {
          *puVar2 = *puVar2 >> 8 | *puVar2 << 8;
          puVar2 = puVar2 + 1;
          iStack_20 = iVar4;
        }
      }
      iStack_4c = iVar1;
      FUN_10009b20(&uStack_48,puStack_2c,uStack_30,uStack_24,puStack_34,0);
      FUN_10003b00(iStack_28 * uStack_24,uStack_24 * iVar1,uStack_30);
      iVar4 = iVar4 - iVar1;
      iStack_28 = iStack_28 + iVar1;
    } while (0 < iVar4);
  }
  puStack_18 = param_7;
  if ((iStack_44 < 0x8000) && (-0x8001 < iStack_40)) {
    *param_7 = 0;
    return;
  }
  (**(code **)(*param_1 + 0x14))(puStack_1c);
  iVar4 = FUN_10004640(uStack_48,-iStack_44);
  uStack_48 = 0;
  iStack_44 = 0;
  iStack_4c = (int)(0x3fff8000 / (longlong)iVar4);
  puStack_34 = (ushort *)FUN_10003920();
  uStack_30 = FUN_10003930();
  puStack_2c = (ushort *)(uStack_38 * iStack_28 & 0xff);
  iStack_3c = 0;
  uStack_24 = (uint)(0x4000 / ZEXT48(puStack_2c));
  for (iVar4 = param_5; 0 < iVar4; iVar4 = iVar4 - iVar1) {
    iVar1 = FUN_10004630(uStack_24,iVar4);
    (**(code **)(*unaff_retaddr + 4))((int)puStack_2c * iVar1,puStack_34);
    if (param_6 != '\0') {
      iVar3 = uStack_38 * iVar1;
      puVar2 = puStack_34;
      if (0 < iVar3) {
        do {
          iVar3 = iVar3 + -1;
          *puVar2 = *puVar2 >> 8 | *puVar2 << 8;
          puVar2 = puVar2 + 1;
        } while (0 < iVar3);
        iStack_40 = iVar4;
        param_6 = (char)param_5;
      }
    }
    FUN_10009b20(&iStack_4c,puStack_34,uStack_30,iStack_28,uStack_38,0,iVar1);
    FUN_10003b00(iStack_3c * iStack_28,iStack_28 * iVar1,uStack_30);
    iStack_3c = iStack_3c + iVar1;
  }
  *puStack_1c = 1;
  return;
}



undefined4 * __fastcall FUN_1000a270(undefined4 *param_1)

{
  param_1[2] = 4;
  *param_1 = &PTR_LAB_10030584;
  *(undefined1 *)(param_1 + 1) = 0;
  *(undefined1 *)((int)param_1 + 5) = 0;
  *(undefined1 *)((int)param_1 + 6) = 0;
  *(undefined1 *)((int)param_1 + 7) = 0;
  return param_1;
}



undefined4 * __thiscall
FUN_1000a290(undefined4 *param_1,undefined1 param_2,undefined1 param_3,undefined1 param_4,
            undefined1 param_5,undefined4 param_6)

{
  *(undefined1 *)(param_1 + 1) = param_2;
  param_1[2] = param_6;
  *(undefined1 *)((int)param_1 + 7) = param_5;
  *(undefined1 *)((int)param_1 + 5) = param_3;
  *(undefined1 *)((int)param_1 + 6) = param_4;
  *param_1 = &PTR_LAB_10030584;
  return param_1;
}



void __fastcall FUN_1000a300(undefined4 *param_1)

{
  *param_1 = &PTR_LAB_10030584;
  return;
}



void __thiscall FUN_1000a530(int param_1,undefined1 *param_2)

{
  *param_2 = 0xbc;
  param_2[1] = *(undefined1 *)(param_1 + 4);
  param_2[2] = *(undefined1 *)(param_1 + 5);
  param_2[3] = *(undefined1 *)(param_1 + 6);
  param_2[4] = 0;
  return;
}



undefined4 __thiscall FUN_1000a560(int param_1,char *param_2)

{
  if (*param_2 == -0x44) {
    *(char *)(param_1 + 4) = param_2[1];
    *(char *)(param_1 + 5) = param_2[2];
    *(char *)(param_1 + 6) = param_2[3];
    return 1;
  }
  return 0;
}



undefined1 * __fastcall FUN_1000a610(undefined1 *param_1)

{
  param_1[0x18] = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  param_1[0xd] = 0;
  param_1[0xc] = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 4) = 0;
  param_1[1] = 0;
  *param_1 = 0;
  return param_1;
}



void __thiscall FUN_1000a634(int param_1,int param_2)

{
  undefined4 uVar1;
  
  if (DAT_100322c0 != '\0') {
    if ((param_2 <= *(int *)(param_1 + 0x60) - *(int *)(param_1 + 0x5c)) &&
       (-1 < *(int *)(param_1 + 0x5c))) {
      uVar1 = FUN_10004630(*(undefined4 *)(param_1 + 0x4c),*(int *)(param_1 + 0x60));
      uVar1 = FUN_10004660(*(undefined4 *)(param_1 + 0x5c),0,uVar1);
      *(undefined4 *)(param_1 + 0x5c) = uVar1;
      uVar1 = FUN_10004660(*(undefined4 *)(param_1 + 0x60),uVar1,*(undefined4 *)(param_1 + 0x4c));
      *(undefined4 *)(param_1 + 0x60) = uVar1;
      return;
    }
    FUN_1000aa90();
  }
  return;
}



undefined4 * __thiscall
FUN_1000a6c0(undefined4 *param_1,char *param_2,undefined4 param_3,int param_4,undefined4 param_5,
            undefined4 param_6,undefined1 param_7)

{
  char cVar1;
  void *pvVar2;
  char *pcVar3;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000a800;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  *param_1 = &PTR_LAB_100322d4;
  pcVar3 = (char *)(param_1 + 2);
  param_1[1] = param_3;
  do {
    cVar1 = *param_2;
    param_2 = param_2 + 1;
    *pcVar3 = cVar1;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  param_1[0x13] = param_4;
  param_1[0x15] = 0;
  param_1[0x14] = 0;
  FUN_1000a864(param_5,param_6,param_7);
  *(undefined1 *)(param_1 + 0x19) = 0;
  *(undefined1 *)((int)param_1 + 0x66) = 0;
  *(undefined1 *)((int)param_1 + 0x65) = 0;
  local_8 = 0;
  pvVar2 = operator_new(0x3ff0);
  if (pvVar2 == (void *)0x0) {
    pvVar2 = (void *)0x0;
  }
  else {
    FUN_10003940(param_4 * 2);
  }
  param_1[0x14] = pvVar2;
  ExceptionList = local_10;
  return param_1;
}



void __fastcall FUN_1000a814(undefined4 *param_1)

{
  *param_1 = &PTR_LAB_100322d4;
  if ((undefined4 *)param_1[0x15] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x15])(1);
  }
  param_1[0x15] = 0;
  if ((undefined4 *)param_1[0x14] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x14])(1);
  }
  param_1[0x14] = 0;
  return;
}



void __thiscall FUN_1000a864(int param_1,undefined4 param_2,undefined4 param_3,char param_4)

{
  *(char *)(param_1 + 0x58) = param_4;
  if (param_4 == '\0') {
    *(undefined4 *)(param_1 + 0x5c) = 0;
    *(undefined4 *)(param_1 + 0x60) = *(undefined4 *)(param_1 + 0x4c);
  }
  else {
    *(undefined4 *)(param_1 + 0x5c) = param_2;
    *(undefined4 *)(param_1 + 0x60) = param_3;
  }
  FUN_1000a634(1);
  return;
}



void __thiscall FUN_1000a8b0(int param_1,undefined4 param_2,undefined4 param_3,undefined1 param_4)

{
  *(undefined1 *)(param_1 + 0x58) = param_4;
  *(undefined4 *)(param_1 + 0x5c) = param_2;
  *(undefined4 *)(param_1 + 0x60) = param_3;
  FUN_1000a634(1);
  return;
}



void __thiscall FUN_1000a940(int param_1,undefined1 param_2)

{
  *(undefined1 *)(param_1 + 0x65) = param_2;
  return;
}



void __thiscall FUN_1000a950(int param_1,undefined1 param_2)

{
  *(undefined1 *)(param_1 + 0x66) = param_2;
  return;
}



void __thiscall FUN_1000a960(int param_1,undefined1 param_2)

{
  *(undefined1 *)(param_1 + 100) = param_2;
  return;
}



void __fastcall FUN_1000a974(int param_1)

{
  if (*(undefined4 **)(param_1 + 0x50) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x50))(1);
  }
  *(undefined4 *)(param_1 + 0x50) = 0;
  if (*(undefined4 **)(param_1 + 0x54) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x54))(1);
  }
  *(undefined4 *)(param_1 + 0x54) = 0;
  return;
}



undefined4 * __thiscall
FUN_1000a9c0(undefined4 *param_1,char *param_2,undefined4 param_3,int param_4)

{
  char cVar1;
  void *pvVar2;
  undefined4 *puVar3;
  uint uVar4;
  uint uVar5;
  char *pcVar6;
  
  param_1[0x13] = param_4;
  param_1[1] = param_3;
  *param_1 = &PTR_LAB_100322e4;
  pcVar6 = (char *)(param_1 + 2);
  param_1[0x15] = 0;
  param_1[0x14] = 0;
  uVar5 = param_4 * 2 + 0x400;
  do {
    cVar1 = *param_2;
    param_2 = param_2 + 1;
    *pcVar6 = cVar1;
    pcVar6 = pcVar6 + 1;
  } while (cVar1 != '\0');
  pvVar2 = operator_new(0x14);
  if (pvVar2 == (void *)0x0) {
    pvVar2 = (void *)0x0;
  }
  else {
    FUN_10006fd0(uVar5);
  }
  param_1[0x14] = pvVar2;
  puVar3 = (undefined4 *)FUN_10007210();
  for (uVar4 = uVar5 >> 2; uVar4 != 0; uVar4 = uVar4 - 1) {
    *puVar3 = 0;
    puVar3 = puVar3 + 1;
  }
  for (uVar5 = uVar5 & 3; uVar5 != 0; uVar5 = uVar5 - 1) {
    *(undefined1 *)puVar3 = 0;
    puVar3 = (undefined4 *)((int)puVar3 + 1);
  }
  return param_1;
}



void FUN_1000aa60(void)

{
  FUN_10007210();
  return;
}



undefined4 __fastcall FUN_1000aa70(int param_1)

{
  return *(undefined4 *)(param_1 + 0x50);
}



undefined4 __fastcall FUN_1000aa80(int param_1)

{
  return *(undefined4 *)(param_1 + 0x4c);
}



void __fastcall FUN_1000aa90(int param_1)

{
  *(undefined1 *)(param_1 + 0x58) = 1;
  *(undefined4 *)(param_1 + 0x60) = *(undefined4 *)(param_1 + 0x4c);
  *(undefined4 *)(param_1 + 0x5c) = 0;
  return;
}



void __fastcall FUN_1000ab90(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000abf0;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_100010f0();
  *param_1 = &PTR_LAB_100323f4;
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_1000ac00(undefined4 *param_1,undefined4 param_2)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000ac70;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10001160(param_2);
  *param_1 = &PTR_LAB_100323f4;
  ExceptionList = local_10;
  return;
}



void FUN_1000ac80(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1000ace0;
  local_10 = ExceptionList;
  local_8 = 0xffffffff;
  ExceptionList = &local_10;
  FUN_100011e0();
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_1000acf0(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000ad50;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_1000ab90();
  *param_1 = &PTR_LAB_10032454;
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_1000ad60(undefined4 *param_1,undefined4 param_2)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000add0;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_1000ac00(param_2);
  *param_1 = &PTR_LAB_10032454;
  ExceptionList = local_10;
  return;
}



void FUN_1000ade0(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1000ae40;
  local_10 = ExceptionList;
  local_8 = 0xffffffff;
  ExceptionList = &local_10;
  FUN_1000ac80();
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_1000ae50(undefined4 param_1,char *param_2)

{
  char cVar1;
  byte bVar2;
  bool bVar3;
  char *in_EAX;
  char *pcVar4;
  HANDLE hFindFile;
  int iVar5;
  uint uVar6;
  byte *pbVar7;
  CHAR *pCVar8;
  char *pcVar9;
  char *pcVar10;
  bool bVar11;
  char *in_stack_00000010;
  undefined1 local_6c8 [12];
  char local_6bc [264];
  char local_5b4 [784];
  _WIN32_FIND_DATAA _Stack_2a4;
  _WIN32_FIND_DATAA _Stack_164;
  HANDLE local_24;
  char *local_20;
  char *local_1c;
  char *local_18;
  
  local_5b4[0] = '\0';
  uVar6 = 0;
  local_1c = param_2;
  pcVar4 = strchr(in_EAX,0x3a);
  if (pcVar4 != (char *)0x0) {
    strncpy(local_5b4,in_EAX,3);
    uVar6 = 3;
    local_5b4[3] = 0;
  }
  iVar5 = -1;
  pcVar4 = in_EAX;
  do {
    if (iVar5 == 0) break;
    iVar5 = iVar5 + -1;
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  if (uVar6 < 0xfffffffeU - iVar5) {
    local_20 = (char *)uVar6;
    do {
      pcVar4 = local_20;
      if (in_EAX[(int)local_20] == '\\') {
        pcVar9 = in_EAX;
        pcVar10 = local_6bc;
        for (uVar6 = (uint)local_20 >> 2; uVar6 != 0; uVar6 = uVar6 - 1) {
          *(undefined4 *)pcVar10 = *(undefined4 *)pcVar9;
          pcVar9 = pcVar9 + 4;
          pcVar10 = pcVar10 + 4;
        }
        for (uVar6 = (uint)pcVar4 & 3; uVar6 != 0; uVar6 = uVar6 - 1) {
          *pcVar10 = *pcVar9;
          pcVar9 = pcVar9 + 1;
          pcVar10 = pcVar10 + 1;
        }
        local_6bc[(int)local_20] = '\0';
        bVar3 = true;
        local_24 = FindFirstFileA(local_6bc,&_Stack_2a4);
        if (local_24 == (HANDLE)0xffffffff) {
LAB_1000afb7:
          pcVar4 = strrchr(local_6bc,0x5c);
          if (pcVar4 == (char *)0x0) {
            pcVar4 = local_6bc;
          }
          else {
            pcVar4 = pcVar4 + 1;
          }
          iVar5 = -1;
          pcVar9 = local_5b4;
          do {
            pcVar10 = pcVar9;
            if (iVar5 == 0) break;
            iVar5 = iVar5 + -1;
            pcVar10 = pcVar9 + 1;
            cVar1 = *pcVar9;
            pcVar9 = pcVar10;
          } while (cVar1 != '\0');
          pcVar10 = pcVar10 + -1;
          do {
            cVar1 = *pcVar4;
            pcVar4 = pcVar4 + 1;
            *pcVar10 = cVar1;
            pcVar10 = pcVar10 + 1;
          } while (cVar1 != '\0');
        }
        else {
          pCVar8 = _Stack_2a4.cFileName;
          pbVar7 = &DAT_10150f40;
          do {
            bVar2 = *pCVar8;
            bVar11 = bVar2 < *pbVar7;
            if (bVar2 != *pbVar7) {
LAB_1000af74:
              uVar6 = -(uint)bVar11 | 1;
              goto LAB_1000af79;
            }
            if (bVar2 == 0) break;
            bVar2 = pCVar8[1];
            bVar11 = bVar2 < pbVar7[1];
            if (bVar2 != pbVar7[1]) goto LAB_1000af74;
            pCVar8 = pCVar8 + 2;
            pbVar7 = pbVar7 + 2;
          } while (bVar2 != 0);
          uVar6 = 0;
LAB_1000af79:
          if (uVar6 != 0) {
            pCVar8 = _Stack_2a4.cFileName;
            bVar3 = false;
            iVar5 = -1;
            pcVar4 = local_5b4;
            do {
              pcVar9 = pcVar4;
              if (iVar5 == 0) break;
              iVar5 = iVar5 + -1;
              pcVar9 = pcVar4 + 1;
              cVar1 = *pcVar4;
              pcVar4 = pcVar9;
            } while (cVar1 != '\0');
            pcVar9 = pcVar9 + -1;
            do {
              cVar1 = *pCVar8;
              pCVar8 = pCVar8 + 1;
              *pcVar9 = cVar1;
              pcVar9 = pcVar9 + 1;
            } while (cVar1 != '\0');
          }
          FindClose(local_24);
          if (bVar3) goto LAB_1000afb7;
        }
        pcVar9 = &DAT_10150f50;
        iVar5 = -1;
        pcVar4 = local_5b4;
        do {
          pcVar10 = pcVar4;
          if (iVar5 == 0) break;
          iVar5 = iVar5 + -1;
          pcVar10 = pcVar4 + 1;
          cVar1 = *pcVar4;
          pcVar4 = pcVar10;
        } while (cVar1 != '\0');
        pcVar10 = pcVar10 + -1;
        do {
          cVar1 = *pcVar9;
          pcVar9 = pcVar9 + 1;
          *pcVar10 = cVar1;
          pcVar10 = pcVar10 + 1;
        } while (cVar1 != '\0');
      }
      local_20 = (char *)((int)local_20 + 1U & 0xffff);
      iVar5 = -1;
      pcVar4 = in_EAX;
      do {
        if (iVar5 == 0) break;
        iVar5 = iVar5 + -1;
        cVar1 = *pcVar4;
        pcVar4 = pcVar4 + 1;
      } while (cVar1 != '\0');
    } while (local_20 < 0xfffffffeU - iVar5);
  }
  iVar5 = -1;
  pcVar4 = in_EAX;
  do {
    if (iVar5 == 0) break;
    iVar5 = iVar5 + -1;
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  if (in_EAX[-3 - iVar5] != '\\') {
    hFindFile = FindFirstFileA(in_EAX,&_Stack_164);
    if (hFindFile == (HANDLE)0xffffffff) {
      pcVar4 = strrchr(in_EAX,0x5c);
      if (pcVar4 != (char *)0x0) {
        in_EAX = pcVar4 + 1;
      }
      iVar5 = -1;
      pcVar4 = local_5b4;
      do {
        pcVar9 = pcVar4;
        if (iVar5 == 0) break;
        iVar5 = iVar5 + -1;
        pcVar9 = pcVar4 + 1;
        cVar1 = *pcVar4;
        pcVar4 = pcVar9;
      } while (cVar1 != '\0');
      pcVar9 = pcVar9 + -1;
      do {
        cVar1 = *in_EAX;
        in_EAX = in_EAX + 1;
        *pcVar9 = cVar1;
        pcVar9 = pcVar9 + 1;
      } while (cVar1 != '\0');
    }
    else {
      pCVar8 = _Stack_164.cFileName;
      iVar5 = -1;
      pcVar4 = local_5b4;
      do {
        pcVar9 = pcVar4;
        if (iVar5 == 0) break;
        iVar5 = iVar5 + -1;
        pcVar9 = pcVar4 + 1;
        cVar1 = *pcVar4;
        pcVar4 = pcVar9;
      } while (cVar1 != '\0');
      pcVar9 = pcVar9 + -1;
      do {
        cVar1 = *pCVar8;
        pCVar8 = pCVar8 + 1;
        *pcVar9 = cVar1;
        pcVar9 = pcVar9 + 1;
      } while (cVar1 != '\0');
      FindClose(hFindFile);
    }
  }
  pcVar4 = strrchr(local_5b4,0x5c);
  if (pcVar4 == (char *)0x0) {
    FUN_100010f0();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_6c8,(ThrowInfo *)&DAT_10030570);
  }
  pcVar9 = pcVar4 + 1;
  iVar5 = -1;
  pcVar10 = pcVar9;
  do {
    if (iVar5 == 0) break;
    iVar5 = iVar5 + -1;
    cVar1 = *pcVar10;
    pcVar10 = pcVar10 + 1;
  } while (cVar1 != '\0');
  for (iVar5 = -3 - iVar5; (0 < iVar5 && (pcVar4[iVar5 + 1] != '.')); iVar5 = iVar5 + -1) {
  }
  local_20 = pcVar4 + iVar5 + 1;
  if (pcVar4[iVar5 + 1] == '.') {
    pcVar10 = local_20;
    do {
      cVar1 = *pcVar10;
      pcVar10 = pcVar10 + 1;
      *in_stack_00000010 = cVar1;
      in_stack_00000010 = in_stack_00000010 + 1;
    } while (cVar1 != '\0');
    *local_20 = '\0';
  }
  else {
    pcVar10 = &DAT_1014fc50;
    do {
      cVar1 = *pcVar10;
      pcVar10 = pcVar10 + 1;
      *in_stack_00000010 = cVar1;
      in_stack_00000010 = in_stack_00000010 + 1;
    } while (cVar1 != '\0');
  }
  do {
    cVar1 = *pcVar9;
    pcVar9 = pcVar9 + 1;
    *local_18 = cVar1;
    local_18 = local_18 + 1;
  } while (cVar1 != '\0');
  pcVar9 = local_5b4;
  pcVar4[1] = '\0';
  do {
    cVar1 = *pcVar9;
    pcVar9 = pcVar9 + 1;
    *local_1c = cVar1;
    local_1c = local_1c + 1;
  } while (cVar1 != '\0');
  return;
}



void FUN_1000b340(LPCSTR param_1,undefined2 *param_2,undefined2 *param_3,undefined2 *param_4,
                 undefined2 *param_5)

{
  UINT uMode;
  DWORD DVar1;
  BOOL BVar2;
  undefined1 auStack_92 [18];
  DWORD local_80;
  undefined1 local_7c [12];
  undefined1 local_70 [12];
  undefined1 local_64 [12];
  LPCVOID local_58;
  undefined1 local_54 [12];
  uint local_48;
  LPVOID local_44;
  undefined1 local_40 [12];
  undefined1 *local_34;
  undefined1 *local_30;
  undefined1 *local_2c;
  undefined1 *local_28;
  undefined1 *local_24;
  DWORD local_20;
  undefined2 *local_1c;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000b530;
  local_10 = ExceptionList;
  local_14 = auStack_92 + -0x12;
  local_58 = (LPCVOID)0x0;
  local_80 = 0;
  ExceptionList = &local_10;
  uMode = SetErrorMode(0x8000);
  local_8 = 0;
  local_20 = GetFileVersionInfoSizeA(param_1,&local_80);
  if (local_20 == 0) {
    DVar1 = GetLastError();
    switch(DVar1) {
    case 0:
    case 0xb:
      local_30 = local_70;
      FUN_100010f0();
                    // WARNING: Subroutine does not return
      _CxxThrowException(local_30,(ThrowInfo *)&DAT_10030570);
    default:
      local_24 = local_7c;
      FUN_100010f0();
                    // WARNING: Subroutine does not return
      _CxxThrowException(local_24,(ThrowInfo *)&DAT_10030570);
    case 2:
      local_34 = local_64;
      FUN_1000acf0();
                    // WARNING: Subroutine does not return
      _CxxThrowException(local_34,(ThrowInfo *)&DAT_100326c0);
    }
  }
  local_58 = operator_new(local_20);
  BVar2 = GetFileVersionInfoA(param_1,0,local_20,local_58);
  if (BVar2 == 0) {
    local_28 = local_54;
    FUN_100010f0();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_28,(ThrowInfo *)&DAT_10030570);
  }
  local_44 = (LPVOID)0x0;
  BVar2 = VerQueryValueA(local_58,&DAT_10150f50,&local_44,&local_48);
  if (BVar2 == 0) {
    local_2c = local_40;
    FUN_100010f0();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_2c,(ThrowInfo *)&DAT_10030570);
  }
  local_1c = param_4;
  *param_2 = *(undefined2 *)((int)local_44 + 10);
  *param_3 = *(undefined2 *)((int)local_44 + 8);
  *param_4 = *(undefined2 *)((int)local_44 + 0xe);
  *param_5 = *(undefined2 *)((int)local_44 + 0xc);
  FUN_1002dde0(local_58);
  local_58 = (LPCVOID)0x0;
  SetErrorMode(uMode);
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_1000b540(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  short local_20 [2];
  ushort local_1c [2];
  ushort local_18 [2];
  ushort local_14 [4];
  
  FUN_1000b340(param_2,local_14,local_18,local_1c,local_20);
  switch((int)local_20[0] / 1000) {
  case 1:
    uVar1 = 1;
    break;
  case 2:
    uVar1 = 2;
    break;
  case 3:
    uVar1 = 3;
    break;
  case 4:
    uVar1 = 4;
    break;
  default:
    uVar1 = 4;
  }
  FUN_1000a290(local_14[0] & 0xff,local_18[0] & 0xff,local_1c[0] & 0xff,local_20[0] % 1000 & 0xff,
               uVar1);
  return;
}



LPVOID FUN_1000b620(HMODULE param_1,LPCSTR param_2,ushort param_3,DWORD *param_4)

{
  HGLOBAL hResData;
  DWORD DVar1;
  undefined1 auStackY_f8 [128];
  undefined1 local_4c [12];
  undefined1 local_40 [12];
  undefined1 local_34 [12];
  undefined1 *local_28;
  undefined1 *local_24;
  undefined1 *local_20;
  LPVOID local_1c;
  HRSRC local_18;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1000b770;
  local_10 = ExceptionList;
  local_14 = auStackY_f8 + 0x8c;
  local_8 = 0;
  ExceptionList = &local_10;
  local_18 = FindResourceA(param_1,(LPCSTR)(uint)param_3,param_2);
  if (local_18 == (HRSRC)0x0) {
    local_20 = local_4c;
    FUN_100010f0();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_10030570);
  }
  hResData = LoadResource(param_1,local_18);
  if (hResData == (HGLOBAL)0x0) {
    local_24 = local_40;
    FUN_1000ab90();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_24,(ThrowInfo *)&DAT_10032670);
  }
  local_1c = LockResource(hResData);
  if (local_1c == (LPVOID)0x0) {
    local_28 = local_34;
    FUN_1000ab90();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_28,(ThrowInfo *)&DAT_10032670);
  }
  DVar1 = SizeofResource(param_1,local_18);
  *param_4 = DVar1;
  FreeResource(hResData);
  ExceptionList = local_10;
  return local_1c;
}



void FUN_1000b9f0(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  
  uVar1 = __allshr();
  param_3[1] = uVar1;
  *param_3 = param_1;
  return;
}



char * __fastcall FUN_1000ba50(char *param_1)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000bb00;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10008100(&DAT_1014fc50);
  pcVar3 = &DAT_1014fc50;
  param_1[0x22c] = '\0';
  param_1[0x22d] = '\0';
  param_1[0x22e] = '\0';
  param_1[0x22f] = '\0';
  param_1[0x229] = '\0';
  param_1[0x228] = '\0';
  param_1[0x224] = '\0';
  param_1[0x225] = '\0';
  param_1[0x226] = '\0';
  param_1[0x227] = '\0';
  param_1[0x220] = '\0';
  param_1[0x221] = '\0';
  param_1[0x222] = '\0';
  param_1[0x223] = '\0';
  param_1[0x21c] = '\0';
  param_1[0x21d] = '\0';
  param_1[0x21e] = '\0';
  param_1[0x21f] = '\0';
  param_1[0x218] = '\0';
  param_1[0x219] = '\0';
  param_1[0x21a] = '\0';
  param_1[0x21b] = '\0';
  pcVar2 = param_1;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
    *pcVar2 = cVar1;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  ExceptionList = local_10;
  return param_1;
}



void FUN_1000bb10(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1000bb80;
  local_10 = ExceptionList;
  local_8 = 0xffffffff;
  ExceptionList = &local_10;
  FUN_10008130();
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_1000bb90(undefined4 *param_1)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1000bc40;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  *param_1 = &PTR_LAB_10031d14;
  pcVar2 = (char *)(param_1 + 1);
  pcVar3 = &DAT_1014fc50;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
    *pcVar2 = cVar1;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  pcVar3 = &DAT_1014fc50;
  pcVar2 = (char *)((int)param_1 + 0x109);
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
    *pcVar2 = cVar1;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  pcVar3 = &DAT_1014fc50;
  pcVar2 = (char *)((int)param_1 + 0x20e);
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
    *pcVar2 = cVar1;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  local_8 = 0xffffffff;
  FUN_10006cd0();
  ExceptionList = local_10;
  return;
}



undefined4 * __thiscall FUN_1000bc50(undefined4 *param_1,char *param_2,char *param_3,char *param_4)

{
  char cVar1;
  byte bVar2;
  bool bVar3;
  CHAR *lpFileName;
  char *pcVar4;
  HANDLE hFindFile;
  int iVar5;
  uint uVar6;
  uint uVar7;
  byte *pbVar8;
  CHAR *pCVar9;
  CHAR *pCVar10;
  char *pcVar11;
  char *pcVar12;
  bool bVar13;
  undefined1 auStack_3ba [14];
  _WIN32_FIND_DATAA local_3ac;
  CHAR local_26c [264];
  _WIN32_FIND_DATAA local_164;
  CHAR *local_24;
  char *local_20;
  HANDLE local_1c;
  uint local_18;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000bf30;
  local_10 = ExceptionList;
  local_14 = auStack_3ba + -0x12;
  local_24 = local_26c;
  ExceptionList = &local_10;
  FUN_10006cc0();
  local_8 = 0;
  *(undefined1 *)(param_1 + 1) = 0;
  local_20 = (char *)(param_1 + 1);
  *param_1 = &PTR_LAB_10031d14;
  local_18 = 0;
  pcVar4 = strchr(param_2,0x3a);
  if (pcVar4 != (char *)0x0) {
    strncpy(local_20,param_2,3);
    local_18 = 3;
    *(undefined1 *)((int)param_1 + 7) = 0;
  }
  iVar5 = -1;
  pcVar4 = param_2;
  do {
    if (iVar5 == 0) break;
    iVar5 = iVar5 + -1;
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  if (local_18 < 0xfffffffeU - iVar5) {
    do {
      uVar7 = local_18;
      if (param_2[local_18] == '\\') {
        pCVar10 = param_2;
        pCVar9 = local_26c;
        for (uVar6 = local_18 >> 2; uVar6 != 0; uVar6 = uVar6 - 1) {
          *(undefined4 *)pCVar9 = *(undefined4 *)pCVar10;
          pCVar10 = pCVar10 + 4;
          pCVar9 = pCVar9 + 4;
        }
        for (uVar7 = uVar7 & 3; lpFileName = local_24, uVar7 != 0; uVar7 = uVar7 - 1) {
          *pCVar9 = *pCVar10;
          pCVar10 = pCVar10 + 1;
          pCVar9 = pCVar9 + 1;
        }
        bVar3 = true;
        local_26c[local_18] = '\0';
        local_1c = FindFirstFileA(lpFileName,&local_3ac);
        if (local_1c == (HANDLE)0xffffffff) {
LAB_1000bdc4:
          pcVar4 = strrchr(local_24,0x5c);
          if (pcVar4 == (char *)0x0) {
            pcVar4 = local_26c;
          }
          else {
            pcVar4 = pcVar4 + 1;
          }
          iVar5 = -1;
          pcVar11 = local_20;
          do {
            pcVar12 = pcVar11;
            if (iVar5 == 0) break;
            iVar5 = iVar5 + -1;
            pcVar12 = pcVar11 + 1;
            cVar1 = *pcVar11;
            pcVar11 = pcVar12;
          } while (cVar1 != '\0');
          pcVar12 = pcVar12 + -1;
          do {
            cVar1 = *pcVar4;
            pcVar4 = pcVar4 + 1;
            *pcVar12 = cVar1;
            pcVar12 = pcVar12 + 1;
          } while (cVar1 != '\0');
        }
        else {
          pbVar8 = &DAT_10150f40;
          pCVar10 = local_3ac.cFileName;
          do {
            bVar2 = *pCVar10;
            bVar13 = bVar2 < *pbVar8;
            if (bVar2 != *pbVar8) {
LAB_1000bd8c:
              uVar7 = -(uint)bVar13 | 1;
              goto LAB_1000bd91;
            }
            if (bVar2 == 0) break;
            bVar2 = pCVar10[1];
            bVar13 = bVar2 < pbVar8[1];
            if (bVar2 != pbVar8[1]) goto LAB_1000bd8c;
            pCVar10 = pCVar10 + 2;
            pbVar8 = pbVar8 + 2;
          } while (bVar2 != 0);
          uVar7 = 0;
LAB_1000bd91:
          if (uVar7 != 0) {
            bVar3 = false;
            pCVar10 = local_3ac.cFileName;
            iVar5 = -1;
            pcVar4 = local_20;
            do {
              pcVar11 = pcVar4;
              if (iVar5 == 0) break;
              iVar5 = iVar5 + -1;
              pcVar11 = pcVar4 + 1;
              cVar1 = *pcVar4;
              pcVar4 = pcVar11;
            } while (cVar1 != '\0');
            pcVar11 = pcVar11 + -1;
            do {
              cVar1 = *pCVar10;
              pCVar10 = pCVar10 + 1;
              *pcVar11 = cVar1;
              pcVar11 = pcVar11 + 1;
            } while (cVar1 != '\0');
          }
          FindClose(local_1c);
          if (bVar3) goto LAB_1000bdc4;
        }
        pcVar11 = &DAT_10150f50;
        iVar5 = -1;
        pcVar4 = local_20;
        do {
          pcVar12 = pcVar4;
          if (iVar5 == 0) break;
          iVar5 = iVar5 + -1;
          pcVar12 = pcVar4 + 1;
          cVar1 = *pcVar4;
          pcVar4 = pcVar12;
        } while (cVar1 != '\0');
        pcVar12 = pcVar12 + -1;
        do {
          cVar1 = *pcVar11;
          pcVar11 = pcVar11 + 1;
          *pcVar12 = cVar1;
          pcVar12 = pcVar12 + 1;
        } while (cVar1 != '\0');
      }
      local_18 = local_18 + 1 & 0xffff;
      iVar5 = -1;
      pcVar4 = param_2;
      do {
        if (iVar5 == 0) break;
        iVar5 = iVar5 + -1;
        cVar1 = *pcVar4;
        pcVar4 = pcVar4 + 1;
      } while (cVar1 != '\0');
    } while (local_18 < 0xfffffffeU - iVar5);
  }
  iVar5 = -1;
  pcVar4 = param_2;
  do {
    if (iVar5 == 0) break;
    iVar5 = iVar5 + -1;
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  if (param_2[-3 - iVar5] != '\\') {
    hFindFile = FindFirstFileA(param_2,&local_164);
    if (hFindFile == (HANDLE)0xffffffff) {
      pcVar4 = strrchr(param_2,0x5c);
      if (pcVar4 != (char *)0x0) {
        param_2 = pcVar4 + 1;
      }
      iVar5 = -1;
      do {
        pcVar4 = local_20;
        if (iVar5 == 0) break;
        iVar5 = iVar5 + -1;
        pcVar4 = local_20 + 1;
        cVar1 = *local_20;
        local_20 = pcVar4;
      } while (cVar1 != '\0');
      pcVar4 = pcVar4 + -1;
      do {
        cVar1 = *param_2;
        param_2 = param_2 + 1;
        *pcVar4 = cVar1;
        pcVar4 = pcVar4 + 1;
      } while (cVar1 != '\0');
    }
    else {
      pCVar10 = local_164.cFileName;
      iVar5 = -1;
      pcVar4 = local_20;
      do {
        pcVar11 = pcVar4;
        if (iVar5 == 0) break;
        iVar5 = iVar5 + -1;
        pcVar11 = pcVar4 + 1;
        cVar1 = *pcVar4;
        pcVar4 = pcVar11;
      } while (cVar1 != '\0');
      pcVar11 = pcVar11 + -1;
      do {
        cVar1 = *pCVar10;
        pCVar10 = pCVar10 + 1;
        *pcVar11 = cVar1;
        pcVar11 = pcVar11 + 1;
      } while (cVar1 != '\0');
      FindClose(hFindFile);
    }
  }
  pcVar4 = (char *)((int)param_1 + 0x109);
  do {
    cVar1 = *param_3;
    param_3 = param_3 + 1;
    *pcVar4 = cVar1;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  pcVar4 = (char *)((int)param_1 + 0x20e);
  do {
    cVar1 = *param_4;
    param_4 = param_4 + 1;
    *pcVar4 = cVar1;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  ExceptionList = local_10;
  return param_1;
}



undefined4 * __thiscall FUN_1000bf40(undefined4 *param_1,undefined4 param_2)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000bfb0;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10006cc0();
  local_8 = 0;
  *param_1 = &PTR_LAB_10031d14;
  FUN_1000c6d4(param_2);
  ExceptionList = local_10;
  return param_1;
}



undefined4 * __thiscall FUN_1000bfc0(undefined4 *param_1,undefined4 param_2)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000c070;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10006cc0();
  local_8 = 0;
  pcVar2 = (char *)(param_1 + 1);
  pcVar3 = &DAT_1014fc50;
  *param_1 = &PTR_LAB_10031d14;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
    *pcVar2 = cVar1;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  pcVar3 = &DAT_1014fc50;
  pcVar2 = (char *)((int)param_1 + 0x109);
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
    *pcVar2 = cVar1;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  pcVar3 = &DAT_1014fc50;
  pcVar2 = (char *)((int)param_1 + 0x20e);
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
    *pcVar2 = cVar1;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  FUN_1000c604(param_2);
  ExceptionList = local_10;
  return param_1;
}



void __thiscall FUN_1000c0d0(int param_1,char *param_2)

{
  sprintf(param_2,&DAT_10150f90,param_1 + 0x109,param_1 + 0x20e);
  return;
}



void FUN_1000c330(int param_1)

{
  DWORD DVar1;
  BOOL BVar2;
  undefined1 auStack_192 [26];
  CHAR local_178 [264];
  undefined1 local_70 [12];
  undefined1 local_64 [12];
  HANDLE local_58;
  FILETIME local_54;
  FILETIME local_4c;
  undefined1 local_44 [12];
  undefined1 local_38 [16];
  undefined1 *local_28;
  undefined1 *local_24;
  FILETIME *local_20;
  FILETIME *local_1c;
  LPCSTR local_18;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000c4f0;
  local_10 = ExceptionList;
  local_14 = auStack_192 + -0x12;
  local_18 = local_178;
  ExceptionList = &local_10;
  FUN_1000c694(local_18);
  DVar1 = GetFileAttributesA(local_18);
  if (DVar1 == 0xffffffff) {
    FUN_1000ab90();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_70,(ThrowInfo *)&DAT_10032670);
  }
  if (*(char *)(param_1 + 0x228) == '\0') {
    DVar1 = DVar1 & 0xfffffffd;
  }
  else {
    DVar1 = DVar1 | 2;
  }
  BVar2 = SetFileAttributesA(local_18,DVar1);
  if (BVar2 == 0) {
    FUN_1000ab90();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_64,(ThrowInfo *)&DAT_10032670);
  }
  local_58 = (HANDLE)0x0;
  local_8 = 0;
  local_20 = &local_54;
  FUN_1000b9f0(*(undefined4 *)(param_1 + 0x218),*(undefined4 *)(param_1 + 0x21c),local_20);
  local_1c = &local_4c;
  FUN_1000b9f0(*(undefined4 *)(param_1 + 0x220),*(undefined4 *)(param_1 + 0x224),local_1c);
  local_58 = CreateFileA(local_18,0x40000000,0,(LPSECURITY_ATTRIBUTES)0x0,3,0,(HANDLE)0x0);
  if (local_58 == (HANDLE)0xffffffff) {
    local_24 = local_44;
    FUN_1000ab90();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_24,(ThrowInfo *)&DAT_10032670);
  }
  BVar2 = SetFileTime(local_58,local_20,(FILETIME *)0x0,local_1c);
  if (BVar2 == 0) {
    local_28 = local_38;
    FUN_1000ab90();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_28,(ThrowInfo *)&DAT_10032670);
  }
  CloseHandle(local_58);
  ExceptionList = local_10;
  return;
}



uint FUN_1000c500(undefined4 *param_1)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  char *pcVar4;
  undefined1 auStackY_1c4 [128];
  char local_124 [264];
  void *local_1c;
  uint local_18;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1000c5f0;
  local_10 = ExceptionList;
  local_14 = auStackY_1c4 + 0x88;
  local_1c = (void *)0x0;
  local_8 = 0;
  ExceptionList = &local_10;
  FUN_1000c694(local_124);
  iVar2 = -1;
  pcVar4 = local_124;
  do {
    if (iVar2 == 0) break;
    iVar2 = iVar2 + -1;
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  local_18 = 3 - iVar2;
  local_1c = operator_new(local_18);
  FUN_100040e0(local_1c,DAT_10150388);
  pcVar4 = local_124;
  pcVar3 = (char *)((int)local_1c + 4);
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
    *pcVar3 = cVar1;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  *param_1 = local_1c;
  ExceptionList = local_10;
  return local_18;
}



void FUN_1000c604(int param_1)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  char *pcVar4;
  undefined1 auStack_12c [12];
  char local_120 [268];
  undefined1 *puStack_14;
  
  iVar2 = FUN_100040b0(param_1);
  if (iVar2 != DAT_10150388) {
    puStack_14 = auStack_12c;
    FUN_10001250();
                    // WARNING: Subroutine does not return
    _CxxThrowException(puStack_14,(ThrowInfo *)&DAT_10030420);
  }
  pcVar3 = (char *)(param_1 + 4);
  pcVar4 = local_120;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
    *pcVar4 = cVar1;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  FUN_1000c6d4(local_120);
  return;
}



void __thiscall FUN_1000c694(int param_1,char *param_2)

{
  sprintf(param_2,s__s_s_s_10150fa0,param_1 + 4,param_1 + 0x109,param_1 + 0x20e);
  return;
}



void FUN_1000c6d4(void)

{
  FUN_1000ae50();
  return;
}



undefined4 * __thiscall FUN_1000c700(undefined4 *param_1,undefined4 param_2)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000c770;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10006ce0();
  local_8 = 0;
  *param_1 = &PTR_LAB_10032404;
  param_1[1] = 0;
  FUN_1000cbe4(param_2);
  ExceptionList = local_10;
  return param_1;
}



undefined4 * __thiscall
FUN_1000c780(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000c800;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10006ce0();
  local_8 = 0;
  *param_1 = &PTR_LAB_10032404;
  param_1[1] = 0;
  FUN_1000cb34(param_2,param_3,param_4);
  ExceptionList = local_10;
  return param_1;
}



void __fastcall FUN_1000c810(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1000c8a0;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  *param_1 = &PTR_LAB_10032404;
  local_8 = 0;
  if (param_1[1] != 0) {
    CloseHandle((HANDLE)param_1[1]);
    param_1[1] = 0;
  }
  local_8 = 0xffffffff;
  FUN_10006cf0();
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_1000c8b0(int param_1)

{
  if (*(HANDLE *)(param_1 + 4) != (HANDLE)0x0) {
    CloseHandle(*(HANDLE *)(param_1 + 4));
    *(undefined4 *)(param_1 + 4) = 0;
  }
  return;
}



void __fastcall FUN_1000cb34(int param_1)

{
  HANDLE pvVar1;
  CHAR aCStack_120 [264];
  undefined1 local_18 [12];
  undefined1 *local_c;
  
  *(undefined4 *)(param_1 + 4) = 0;
  FUN_1000c694(aCStack_120);
  pvVar1 = CreateFileA(aCStack_120,0x40000000,0,(LPSECURITY_ATTRIBUTES)0x0,2,0x10000000,(HANDLE)0x0)
  ;
  if (pvVar1 == (HANDLE)0xffffffff) {
    local_c = local_18;
    FUN_1000d840();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_c,(ThrowInfo *)&DAT_10032710);
  }
  *(HANDLE *)(param_1 + 4) = pvVar1;
  return;
}



void __fastcall FUN_1000cbe4(int param_1)

{
  HANDLE pvVar1;
  CHAR aCStack_120 [264];
  undefined1 local_18 [12];
  undefined1 *local_c;
  
  *(undefined4 *)(param_1 + 4) = 0;
  FUN_1000c694(aCStack_120);
  pvVar1 = CreateFileA(aCStack_120,0x80000000,1,(LPSECURITY_ATTRIBUTES)0x0,3,0x10000000,(HANDLE)0x0)
  ;
  if (pvVar1 == (HANDLE)0xffffffff) {
    local_c = local_18;
    FUN_1000d840();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_c,(ThrowInfo *)&DAT_10032710);
  }
  *(HANDLE *)(param_1 + 4) = pvVar1;
  return;
}



undefined4 * __thiscall FUN_1000cf74(undefined4 *param_1,char *param_2)

{
  char cVar1;
  byte bVar2;
  bool bVar3;
  HANDLE pvVar4;
  int iVar5;
  uint uVar6;
  char *pcVar7;
  char *pcVar8;
  char *pcVar9;
  byte *pbVar10;
  char *pcVar11;
  CHAR *pCVar12;
  bool bVar13;
  char local_4b0 [264];
  char local_3a8 [264];
  _WIN32_FIND_DATAA _Stack_2a0;
  _WIN32_FIND_DATAA _Stack_160;
  char *local_20;
  HANDLE local_1c;
  HANDLE local_18;
  undefined4 *local_14;
  
  pcVar8 = local_4b0;
  *param_1 = &PTR_LAB_10032014;
  pcVar9 = pcVar8;
  do {
    cVar1 = *param_2;
    param_2 = param_2 + 1;
    *pcVar9 = cVar1;
    pcVar9 = pcVar9 + 1;
  } while (cVar1 != '\0');
  iVar5 = -1;
  pcVar9 = pcVar8;
  do {
    if (iVar5 == 0) break;
    iVar5 = iVar5 + -1;
    cVar1 = *pcVar9;
    pcVar9 = pcVar9 + 1;
  } while (cVar1 != '\0');
  if (local_4b0[-3 - iVar5] != '\\') {
    pcVar7 = &DAT_10150f50;
    iVar5 = -1;
    pcVar9 = pcVar8;
    do {
      pcVar11 = pcVar9;
      if (iVar5 == 0) break;
      iVar5 = iVar5 + -1;
      pcVar11 = pcVar9 + 1;
      cVar1 = *pcVar9;
      pcVar9 = pcVar11;
    } while (cVar1 != '\0');
    pcVar11 = pcVar11 + -1;
    do {
      cVar1 = *pcVar7;
      pcVar7 = pcVar7 + 1;
      *pcVar11 = cVar1;
      pcVar11 = pcVar11 + 1;
    } while (cVar1 != '\0');
  }
  local_20 = (char *)(param_1 + 1);
  *(undefined1 *)(param_1 + 1) = 0;
  local_18 = (HANDLE)0x0;
  pcVar9 = strchr(pcVar8,0x3a);
  if (pcVar9 != (char *)0x0) {
    strncpy(local_20,pcVar8,3);
    *(undefined1 *)((int)param_1 + 7) = 0;
    local_18 = (HANDLE)0x3;
  }
  iVar5 = -1;
  pcVar9 = pcVar8;
  do {
    if (iVar5 == 0) break;
    iVar5 = iVar5 + -1;
    cVar1 = *pcVar9;
    pcVar9 = pcVar9 + 1;
  } while (cVar1 != '\0');
  if (local_18 < 0xfffffffeU - iVar5) {
    local_14 = param_1;
    do {
      pvVar4 = local_18;
      if (pcVar8[(int)local_18] == '\\') {
        pcVar9 = pcVar8;
        pcVar7 = local_3a8;
        for (uVar6 = (uint)local_18 >> 2; uVar6 != 0; uVar6 = uVar6 - 1) {
          *(undefined4 *)pcVar7 = *(undefined4 *)pcVar9;
          pcVar9 = pcVar9 + 4;
          pcVar7 = pcVar7 + 4;
        }
        for (uVar6 = (uint)pvVar4 & 3; uVar6 != 0; uVar6 = uVar6 - 1) {
          *pcVar7 = *pcVar9;
          pcVar9 = pcVar9 + 1;
          pcVar7 = pcVar7 + 1;
        }
        local_3a8[(int)local_18] = '\0';
        bVar3 = true;
        local_1c = FindFirstFileA(local_3a8,&_Stack_2a0);
        if (local_1c == (HANDLE)0xffffffff) {
LAB_1000d130:
          pcVar9 = strrchr(local_3a8,0x5c);
          if (pcVar9 == (char *)0x0) {
            pcVar9 = local_3a8;
          }
          else {
            pcVar9 = pcVar9 + 1;
          }
          iVar5 = -1;
          pcVar7 = local_20;
          do {
            pcVar11 = pcVar7;
            if (iVar5 == 0) break;
            iVar5 = iVar5 + -1;
            pcVar11 = pcVar7 + 1;
            cVar1 = *pcVar7;
            pcVar7 = pcVar11;
          } while (cVar1 != '\0');
          pcVar11 = pcVar11 + -1;
          do {
            cVar1 = *pcVar9;
            pcVar9 = pcVar9 + 1;
            *pcVar11 = cVar1;
            pcVar11 = pcVar11 + 1;
          } while (cVar1 != '\0');
        }
        else {
          pCVar12 = _Stack_2a0.cFileName;
          pbVar10 = &DAT_10150f40;
          do {
            bVar2 = *pCVar12;
            bVar13 = bVar2 < *pbVar10;
            if (bVar2 != *pbVar10) {
LAB_1000d0ed:
              uVar6 = -(uint)bVar13 | 1;
              goto LAB_1000d0f2;
            }
            if (bVar2 == 0) break;
            bVar2 = pCVar12[1];
            bVar13 = bVar2 < pbVar10[1];
            if (bVar2 != pbVar10[1]) goto LAB_1000d0ed;
            pCVar12 = pCVar12 + 2;
            pbVar10 = pbVar10 + 2;
          } while (bVar2 != 0);
          uVar6 = 0;
LAB_1000d0f2:
          if (uVar6 != 0) {
            pCVar12 = _Stack_2a0.cFileName;
            bVar3 = false;
            iVar5 = -1;
            pcVar9 = local_20;
            do {
              pcVar7 = pcVar9;
              if (iVar5 == 0) break;
              iVar5 = iVar5 + -1;
              pcVar7 = pcVar9 + 1;
              cVar1 = *pcVar9;
              pcVar9 = pcVar7;
            } while (cVar1 != '\0');
            pcVar7 = pcVar7 + -1;
            do {
              cVar1 = *pCVar12;
              pCVar12 = pCVar12 + 1;
              *pcVar7 = cVar1;
              pcVar7 = pcVar7 + 1;
            } while (cVar1 != '\0');
          }
          FindClose(local_1c);
          if (bVar3) goto LAB_1000d130;
        }
        pcVar7 = &DAT_10150f50;
        iVar5 = -1;
        pcVar9 = local_20;
        do {
          pcVar11 = pcVar9;
          if (iVar5 == 0) break;
          iVar5 = iVar5 + -1;
          pcVar11 = pcVar9 + 1;
          cVar1 = *pcVar9;
          pcVar9 = pcVar11;
        } while (cVar1 != '\0');
        pcVar11 = pcVar11 + -1;
        do {
          cVar1 = *pcVar7;
          pcVar7 = pcVar7 + 1;
          *pcVar11 = cVar1;
          pcVar11 = pcVar11 + 1;
        } while (cVar1 != '\0');
      }
      local_18 = (HANDLE)((int)local_18 + 1U & 0xffff);
      iVar5 = -1;
      pcVar9 = pcVar8;
      do {
        if (iVar5 == 0) break;
        iVar5 = iVar5 + -1;
        cVar1 = *pcVar9;
        pcVar9 = pcVar9 + 1;
      } while (cVar1 != '\0');
    } while (local_18 < 0xfffffffeU - iVar5);
    param_1 = local_14;
  }
  iVar5 = -1;
  pcVar9 = pcVar8;
  do {
    if (iVar5 == 0) break;
    iVar5 = iVar5 + -1;
    cVar1 = *pcVar9;
    pcVar9 = pcVar9 + 1;
  } while (cVar1 != '\0');
  if (pcVar8[-3 - iVar5] != '\\') {
    pvVar4 = FindFirstFileA(pcVar8,&_Stack_160);
    if (pvVar4 == (HANDLE)0xffffffff) {
      pcVar9 = strrchr(pcVar8,0x5c);
      if (pcVar9 != (char *)0x0) {
        pcVar8 = pcVar9 + 1;
      }
      iVar5 = -1;
      do {
        pcVar9 = local_20;
        if (iVar5 == 0) break;
        iVar5 = iVar5 + -1;
        pcVar9 = local_20 + 1;
        cVar1 = *local_20;
        local_20 = pcVar9;
      } while (cVar1 != '\0');
      pcVar9 = pcVar9 + -1;
      do {
        cVar1 = *pcVar8;
        pcVar8 = pcVar8 + 1;
        *pcVar9 = cVar1;
        pcVar9 = pcVar9 + 1;
      } while (cVar1 != '\0');
    }
    else {
      pCVar12 = _Stack_160.cFileName;
      local_18 = pvVar4;
      iVar5 = -1;
      pcVar8 = local_20;
      do {
        pcVar9 = pcVar8;
        if (iVar5 == 0) break;
        iVar5 = iVar5 + -1;
        pcVar9 = pcVar8 + 1;
        cVar1 = *pcVar8;
        pcVar8 = pcVar9;
      } while (cVar1 != '\0');
      pcVar9 = pcVar9 + -1;
      do {
        cVar1 = *pCVar12;
        pCVar12 = pCVar12 + 1;
        *pcVar9 = cVar1;
        pcVar9 = pcVar9 + 1;
      } while (cVar1 != '\0');
      FindClose(pvVar4);
    }
  }
  return param_1;
}



void __fastcall FUN_1000d2a0(undefined4 *param_1)

{
  *param_1 = &PTR_LAB_10032014;
  return;
}



void * __thiscall FUN_1000d2b0(int param_1,char *param_2)

{
  void *pvVar1;
  char acStack_538 [264];
  char local_430 [264];
  char local_328 [264];
  char local_220 [264];
  char local_118 [264];
  
  sprintf(acStack_538,&DAT_10150f90,param_1 + 4,param_2);
  _splitpath(param_2,local_430,local_328,local_220,local_118);
  pvVar1 = operator_new(0x314);
  if (pvVar1 == (void *)0x0) {
    pvVar1 = (void *)0x0;
  }
  else {
    FUN_1000bc50(param_1 + 4,local_220,local_118);
  }
  return pvVar1;
}



void FUN_1000d3c0(void)

{
  FUN_1000d3d0();
  return;
}



void * FUN_1000d3d0(void)

{
  char cVar1;
  UINT UVar2;
  void *pvVar3;
  int iVar4;
  char *pcVar5;
  LPSTR pCVar6;
  char *pcVar7;
  CHAR local_124 [264];
  undefined1 local_1c [16];
  
  UVar2 = GetWindowsDirectoryA(local_124,0x104);
  if ((UVar2 == 0) || (0x104 < UVar2)) {
    FUN_100010f0();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_1c,(ThrowInfo *)&DAT_10030570);
  }
  pcVar5 = &DAT_10150f50;
  iVar4 = -1;
  pCVar6 = local_124;
  do {
    pcVar7 = pCVar6;
    if (iVar4 == 0) break;
    iVar4 = iVar4 + -1;
    pcVar7 = pCVar6 + 1;
    cVar1 = *pCVar6;
    pCVar6 = pcVar7;
  } while (cVar1 != '\0');
  pcVar7 = pcVar7 + -1;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
    *pcVar7 = cVar1;
    pcVar7 = pcVar7 + 1;
  } while (cVar1 != '\0');
  pvVar3 = operator_new(0x10c);
  if (pvVar3 == (void *)0x0) {
    pvVar3 = (void *)0x0;
  }
  else {
    FUN_1000cf74(local_124);
  }
  return pvVar3;
}



undefined1 * __thiscall FUN_1000d470(undefined1 *param_1,undefined4 param_2)

{
  *param_1 = 0;
  *(undefined4 *)(param_1 + 4) = param_2;
  return param_1;
}



undefined1 * __fastcall FUN_1000d480(undefined1 *param_1)

{
  HMODULE pHVar1;
  CHAR local_110 [264];
  
  *(undefined4 *)(param_1 + 4) = 0;
  *param_1 = 1;
  FUN_1000c694(local_110);
  pHVar1 = LoadLibraryA(local_110);
  *(HMODULE *)(param_1 + 4) = pHVar1;
  return param_1;
}



void __fastcall FUN_1000d4d0(char *param_1)

{
  if ((*(HMODULE *)(param_1 + 4) != (HMODULE)0x0) && (*param_1 != '\0')) {
    FreeLibrary(*(HMODULE *)(param_1 + 4));
    param_1[4] = '\0';
    param_1[5] = '\0';
    param_1[6] = '\0';
    param_1[7] = '\0';
  }
  return;
}



void __thiscall FUN_1000d500(int param_1,LPCSTR param_2,ushort param_3)

{
  undefined1 auStackY_d8 [128];
  undefined1 local_30 [12];
  undefined1 *local_24;
  HRSRC local_20;
  int local_1c;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1000d5c0;
  local_10 = ExceptionList;
  local_14 = auStackY_d8 + 0x8c;
  local_8 = 0;
  ExceptionList = &local_10;
  local_1c = param_1;
  local_20 = FindResourceA(*(HMODULE *)(param_1 + 4),(LPCSTR)(uint)param_3,param_2);
  if (local_20 == (HRSRC)0x0) {
    local_24 = local_30;
    FUN_100010f0();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_24,(ThrowInfo *)&DAT_10030570);
  }
  SizeofResource(*(HMODULE *)(local_1c + 4),local_20);
  ExceptionList = local_10;
  return;
}



void __thiscall
FUN_1000d5d0(int param_1,undefined4 param_2,short param_3,undefined4 *param_4,uint *param_5,
            uint param_6)

{
  undefined4 *puVar1;
  uint uVar2;
  uint uVar3;
  
  puVar1 = (undefined4 *)FUN_1000b620(*(undefined4 *)(param_1 + 4),param_2,(int)param_3,param_5);
  uVar3 = *param_5;
  if ((int)param_6 < (int)*param_5) {
    uVar3 = param_6;
  }
  for (uVar2 = uVar3 >> 2; uVar2 != 0; uVar2 = uVar2 - 1) {
    *param_4 = *puVar1;
    puVar1 = puVar1 + 1;
    param_4 = param_4 + 1;
  }
  for (uVar3 = uVar3 & 3; uVar3 != 0; uVar3 = uVar3 - 1) {
    *(undefined1 *)param_4 = *(undefined1 *)puVar1;
    puVar1 = (undefined4 *)((int)puVar1 + 1);
    param_4 = (undefined4 *)((int)param_4 + 1);
  }
  return;
}



int * __thiscall FUN_1000d630(int param_1,undefined4 param_2,short param_3)

{
  undefined4 uVar1;
  int *piVar2;
  undefined4 local_14;
  int *local_10;
  
  local_14 = 0;
  uVar1 = FUN_1000b620(*(undefined4 *)(param_1 + 4),param_2,(int)param_3,&local_14);
  piVar2 = operator_new(0x14);
  if (piVar2 == (int *)0x0) {
    piVar2 = (int *)0x0;
  }
  else {
    local_10 = piVar2;
    FUN_10006fd0(local_14);
    piVar2 = local_10;
  }
  (**(code **)(*piVar2 + 0xc))(local_14,uVar1);
  (**(code **)(*piVar2 + 0x14))(0);
  return piVar2;
}



undefined4 __thiscall FUN_1000d6d0(int param_1,undefined4 param_2)

{
  DWORD DVar1;
  CHAR aCStack_328 [784];
  undefined1 local_18 [12];
  undefined1 *local_c;
  
  DVar1 = GetModuleFileNameA(*(HMODULE *)(param_1 + 4),aCStack_328,0x30d);
  if (DVar1 == 0) {
    local_c = local_18;
    FUN_100010f0();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_c,(ThrowInfo *)&DAT_10030570);
  }
  FUN_1000b540();
  return param_2;
}



void FUN_1000d750(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1000d7b0;
  local_10 = ExceptionList;
  local_8 = 0xffffffff;
  ExceptionList = &local_10;
  FUN_1000ac80();
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_1000d7c0(undefined4 *param_1,undefined4 param_2)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000d830;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_1000ac00(param_2);
  *param_1 = &PTR_LAB_10032444;
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_1000d840(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000d8a0;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_1000ab90();
  *param_1 = &PTR_LAB_10032444;
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_1000d9e0(undefined4 *param_1,undefined4 param_2)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000da50;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10001160(param_2);
  *param_1 = &PTR_LAB_100327b4;
  ExceptionList = local_10;
  return;
}



void FUN_1000da60(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1000dac0;
  local_10 = ExceptionList;
  local_8 = 0xffffffff;
  ExceptionList = &local_10;
  FUN_100011e0();
  ExceptionList = local_10;
  return;
}



void FUN_1000dad0(HMODULE param_1,undefined4 param_2)

{
  DWORD DVar1;
  undefined1 auStack_bda [798];
  CHAR local_8bc [264];
  undefined1 local_7b4 [268];
  undefined1 local_6a8 [788];
  undefined1 local_394 [860];
  undefined1 local_38 [12];
  undefined1 *local_2c;
  undefined1 *local_28;
  undefined1 *local_24;
  undefined1 *local_20;
  LPSTR local_1c;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000dc70;
  local_10 = ExceptionList;
  local_14 = auStack_bda + -0x12;
  local_20 = local_7b4;
  local_1c = local_8bc;
  switch(param_2) {
  case 0:
    ExceptionList = &local_10;
    local_14 = auStack_bda + -0x12;
    FUN_1001ab10();
    break;
  case 1:
    local_8 = 0;
    ExceptionList = &local_10;
    DVar1 = GetModuleFileNameA(param_1,local_1c,0x104);
    if (DVar1 == 0) {
      local_2c = local_38;
      FUN_100010f0();
                    // WARNING: Subroutine does not return
      _CxxThrowException(local_2c,(ThrowInfo *)&DAT_10030570);
    }
    local_28 = local_6a8;
    FUN_1000bf40(local_1c);
    local_8 = 1;
    FUN_10009060(local_20,local_1c,0x41);
    FUN_10008050(local_28);
    local_24 = local_394;
    FUN_1000e2a0();
    local_8 = 2;
    FUN_1001e190(local_24);
    local_8 = 1;
    FUN_1000e360();
    local_8 = 0;
    FUN_1000bb90();
  }
  ExceptionList = local_10;
  return;
}



undefined4 * __thiscall FUN_1000dc80(undefined4 *param_1,char *param_2,undefined1 param_3)

{
  char cVar1;
  void *pvVar2;
  char *pcVar3;
  undefined4 in_stack_0000031c;
  undefined1 auStackY_c4 [128];
  undefined1 local_24 [4];
  undefined1 local_20;
  undefined1 local_1f;
  undefined1 local_1e;
  undefined1 local_1d;
  undefined4 local_1c;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000de00;
  local_10 = ExceptionList;
  local_14 = auStackY_c4 + 0x88;
  ExceptionList = &local_10;
  *param_1 = &PTR_LAB_10032784;
  param_1[1] = 0;
  FUN_10008050(&param_3);
  local_8 = 0;
  param_1[199] = in_stack_0000031c;
  FUN_1000a270();
  local_8 = 2;
  pcVar3 = (char *)(param_1 + 200);
  do {
    cVar1 = *param_2;
    param_2 = param_2 + 1;
    *pcVar3 = cVar1;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  pvVar2 = operator_new(8);
  if (pvVar2 == (void *)0x0) {
    pvVar2 = (void *)0x0;
  }
  else {
    FUN_1000d470(param_1[199]);
  }
  param_1[1] = pvVar2;
  FUN_1000d6d0(local_24);
  *(undefined1 *)(param_1 + 0xda) = local_20;
  *(undefined1 *)((int)param_1 + 0x369) = local_1f;
  *(undefined1 *)((int)param_1 + 0x36a) = local_1e;
  *(undefined1 *)((int)param_1 + 0x36b) = local_1d;
  param_1[0xdb] = local_1c;
  local_8 = 2;
  FUN_1000a300();
  local_8 = 1;
  FUN_1000bb90();
  ExceptionList = local_10;
  return param_1;
}



void __fastcall FUN_1000de10(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1000ded0;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  *param_1 = &PTR_LAB_10032784;
  local_8 = 1;
  if (param_1[1] != 0) {
    FUN_10007f60(1);
  }
  param_1[1] = 0;
  local_8 = 0;
  FUN_1000a300();
  local_8 = 0xffffffff;
  FUN_1000bb90();
  ExceptionList = local_10;
  return;
}



undefined4 __fastcall FUN_1000dee0(int param_1)

{
  return *(undefined4 *)(param_1 + 4);
}



void __thiscall FUN_1000e030(int param_1,undefined4 *param_2)

{
  *param_2 = &PTR_LAB_10030584;
  *(undefined1 *)(param_2 + 1) = *(undefined1 *)(param_1 + 0x368);
  *(undefined1 *)((int)param_2 + 5) = *(undefined1 *)(param_1 + 0x369);
  *(undefined1 *)((int)param_2 + 6) = *(undefined1 *)(param_1 + 0x36a);
  *(undefined1 *)((int)param_2 + 7) = *(undefined1 *)(param_1 + 0x36b);
  param_2[2] = *(undefined4 *)(param_1 + 0x36c);
  return;
}



void FUN_1000e070(void)

{
  timeGetTime();
  return;
}



ulonglong FUN_1000e080(void)

{
  BOOL BVar1;
  DWORD DVar2;
  undefined8 uVar3;
  ulonglong uVar4;
  LARGE_INTEGER local_14;
  LARGE_INTEGER local_c;
  
  switch(DAT_10032770) {
  case 99:
    break;
  case 100:
    DVar2 = timeGetTime();
    return (ulonglong)(DVar2 * 1000);
  case 0x65:
    QueryPerformanceCounter(&local_14);
    uVar3 = __alldiv(local_14.s.LowPart,local_14.s.HighPart,DAT_10054780,DAT_10054784);
    uVar4 = __alldiv(uVar3,100000,0);
    return uVar4;
  default:
    return 0;
  }
  BVar1 = QueryPerformanceFrequency(&local_c);
  if (BVar1 == 0) {
    DAT_10032770 = 100;
  }
  else {
    DAT_10054784 = local_c.s.HighPart;
    DAT_10032770 = 0x65;
    DAT_10054780 = local_c.s.LowPart;
  }
  uVar4 = FUN_1000e080();
  return uVar4;
}



void __fastcall FUN_1000e170(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1000e1e0;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  *param_1 = &PTR_LAB_10032794;
  DAT_10054760 = 0;
  local_8 = 0xffffffff;
  FUN_1000de10();
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_1000e1f0(undefined4 *param_1,int param_2)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000e290;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10008050(param_2);
  FUN_1000dc80(param_2 + 0x314);
  *param_1 = &PTR_LAB_10032794;
  DAT_10054760 = param_1;
  ExceptionList = local_10;
  return;
}



int __thiscall FUN_1000e2a0(int param_1,undefined1 param_2)

{
  char cVar1;
  char *pcVar2;
  char *in_stack_00000318;
  undefined4 in_stack_0000031c;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000e350;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10008050(&param_2);
  *(undefined4 *)(param_1 + 0x358) = in_stack_0000031c;
  pcVar2 = (char *)(param_1 + 0x314);
  do {
    cVar1 = *in_stack_00000318;
    in_stack_00000318 = in_stack_00000318 + 1;
    *pcVar2 = cVar1;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  local_8 = 0;
  FUN_1000bb90();
  ExceptionList = local_10;
  return param_1;
}



void FUN_1000e360(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1000e3c0;
  local_10 = ExceptionList;
  local_8 = 0xffffffff;
  ExceptionList = &local_10;
  FUN_1000bb90();
  ExceptionList = local_10;
  return;
}



void FUN_1000e3d0(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1000e430;
  local_10 = ExceptionList;
  local_8 = 0xffffffff;
  ExceptionList = &local_10;
  FUN_100011e0();
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_1000e440(undefined4 *param_1,undefined4 param_2)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000e4b0;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10001160(param_2);
  *param_1 = &PTR_LAB_100327d4;
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_1000e4c0(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000e520;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_100010f0();
  *param_1 = &PTR_LAB_100327d4;
  ExceptionList = local_10;
  return;
}



void FUN_1000e530(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1000e590;
  local_10 = ExceptionList;
  local_8 = 0xffffffff;
  ExceptionList = &local_10;
  FUN_100011e0();
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_1000e5a0(undefined4 *param_1,undefined4 param_2)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000e610;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10001160(param_2);
  *param_1 = &PTR_LAB_100327c4;
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_1000e620(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000e680;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_100010f0();
  *param_1 = &PTR_LAB_100327c4;
  ExceptionList = local_10;
  return;
}



void FUN_1000e690(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1000e6f0;
  local_10 = ExceptionList;
  local_8 = 0xffffffff;
  ExceptionList = &local_10;
  FUN_100011e0();
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_1000e700(undefined4 *param_1,undefined4 param_2)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000e770;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10001160(param_2);
  *param_1 = &PTR_LAB_100327a4;
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_1000e780(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000e7e0;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_100010f0();
  *param_1 = &PTR_LAB_100327a4;
  ExceptionList = local_10;
  return;
}



void FUN_1000e8b0(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1000e910;
  local_10 = ExceptionList;
  local_8 = 0xffffffff;
  ExceptionList = &local_10;
  FUN_10010340();
  ExceptionList = local_10;
  return;
}



void FUN_1000e920(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1000e980;
  local_10 = ExceptionList;
  local_8 = 0xffffffff;
  ExceptionList = &local_10;
  FUN_1000e8b0();
  ExceptionList = local_10;
  return;
}



undefined4 * __thiscall FUN_1000e990(undefined4 *param_1,undefined4 param_2,undefined1 param_3)

{
  uint uVar1;
  uint uVar2;
  undefined1 auStack_4a [14];
  char local_3c [32];
  char *local_1c;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000eab0;
  local_10 = ExceptionList;
  local_14 = auStack_4a + -0x12;
  local_1c = local_3c;
  ExceptionList = &local_10;
  FUN_10010530(param_2,param_3);
  local_8 = 0;
  *param_1 = &PTR_LAB_10032b24;
  FUN_10019b90();
  FUN_10019b90();
  *(undefined2 *)(param_1 + 0xc) = 0;
  *(undefined2 *)(param_1 + 0x19) = 0;
  param_1[0x1a] = 0;
  param_1[0x17] = 0;
  param_1[0x13] = 0x3f800000;
  param_1[0x12] = 0x3f800000;
  param_1[0x14] = 0x3f800000;
  param_1[0x18] = 0x447a0000;
  param_1[0x15] = 0x3c23d70a;
  param_1[0x16] = 0x3f7f9724;
  *(undefined2 *)((int)param_1 + 0x66) = 300;
  uVar1 = FUN_10010350();
  sprintf(local_1c,s_Comp__d_10151700,uVar1 & 0xff);
  FUN_10010360(local_1c);
  uVar1 = 0;
  do {
    uVar2 = uVar1 + 1 & 0xff;
    *(undefined1 *)((int)param_1 + uVar1 + 0x42) = 0;
    uVar1 = uVar2;
  } while (uVar2 < 5);
  ExceptionList = local_10;
  return param_1;
}



void __fastcall FUN_1000eac0(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1000eb30;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  *param_1 = &PTR_LAB_10032b24;
  local_8 = 0xffffffff;
  FUN_1000e920();
  ExceptionList = local_10;
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void __fastcall FUN_1000eb44(int param_1)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  
  fVar6 = _DAT_10151660;
  fVar1 = *(float *)(param_1 + 0x5c) * (float)_DAT_10151628;
  if (_DAT_10151660 < fVar1) {
    fVar1 = _DAT_10151660;
  }
  *(char *)(param_1 + 0x3b) = (char)(longlong)ROUND(fVar1);
  fVar3 = (float)*(byte *)(param_1 + 0x39) * _DAT_10151664;
  fVar5 = (float)_DAT_10151640;
  fVar4 = (float)_DAT_10151638;
  fVar1 = (float)*(byte *)(param_1 + 0x3a) * _DAT_10151664 * _DAT_10151668;
  *(float *)(param_1 + 0x4c) = (float)_DAT_10151638 - fVar3 * (float)_DAT_10151630;
  fVar2 = (float)_DAT_10151650;
  *(float *)(param_1 + 0x48) =
       ((float)*(byte *)(param_1 + 0x3a) * fVar5 + fVar4) * fVar3 * (float)_DAT_10151648;
  *(float *)(param_1 + 0x60) = fVar1 * fVar2 + (float)_DAT_10151658;
  if (*(int *)(param_1 + 0x68) < 0x3f800001) {
    *(char *)(param_1 + 0x3c) = (char)(longlong)ROUND(fVar6 * *(float *)(param_1 + 0x68));
  }
  else {
    *(undefined1 *)(param_1 + 0x3c) = 0x7f;
  }
  *(float *)(param_1 + 0x68) = *(float *)(param_1 + 0x68) * _DAT_10151670;
  return;
}



void FUN_1000f530(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1000f590;
  local_10 = ExceptionList;
  local_8 = 0xffffffff;
  ExceptionList = &local_10;
  FUN_1000e8b0();
  ExceptionList = local_10;
  return;
}



undefined4 * __thiscall FUN_1000f5a0(undefined4 *param_1,undefined4 param_2,undefined1 param_3)

{
  uint uVar1;
  uint uVar2;
  undefined1 auStack_4a [14];
  char local_3c [32];
  char *local_1c;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1000f6c0;
  local_10 = ExceptionList;
  local_14 = auStack_4a + -0x12;
  local_1c = local_3c;
  ExceptionList = &local_10;
  FUN_100104b0(param_2,param_3);
  local_8 = 0;
  *param_1 = &PTR_LAB_10032cb4;
  FUN_10019ab0();
  FUN_10019ab0();
  uVar1 = FUN_10010350();
  sprintf(local_1c,s_5Delay__d_1015184f + 1,uVar1 & 0xff);
  FUN_10010360(local_1c);
  param_1[0x13] = 120000;
  param_1[0x1b] = 0;
  param_1[0x1a] = 0;
  param_1[0x18] = 0;
  param_1[0x17] = 0;
  param_1[0x12] = param_1[0x13] * 0x19;
  param_1[0x16] = 0;
  param_1[0x15] = 0;
  param_1[0x19] = 0;
  param_1[0x1c] = 0;
  *(undefined2 *)(param_1 + 0x14) = 1;
  uVar1 = 0;
  do {
    uVar2 = uVar1 + 1 & 0xff;
    *(undefined1 *)((int)param_1 + uVar1 + 0x40) = 0;
    uVar1 = uVar2;
  } while (uVar2 < 6);
  ExceptionList = local_10;
  return param_1;
}



void __fastcall FUN_1000f6d0(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1000f740;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  *param_1 = &PTR_LAB_10032cb4;
  local_8 = 0xffffffff;
  FUN_1000f530();
  ExceptionList = local_10;
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void __fastcall FUN_1000f754(int param_1)

{
  float fVar1;
  float fVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  
  iVar3 = *(short *)(param_1 + 0x50) + -1;
  *(short *)(param_1 + 0x50) = (short)iVar3;
  if (iVar3 == 0) {
    iVar4 = *(int *)(param_1 + 0x48) / 0x19;
    iVar3 = *(int *)(param_1 + 0x4c);
    *(undefined2 *)(param_1 + 0x50) = 0x19;
    *(undefined4 *)(param_1 + 0x48) = 0;
    if ((iVar3 + 4000 < iVar4) || (iVar4 < iVar3 + -4000)) {
      *(int *)(param_1 + 0x4c) = iVar4;
    }
    else if (iVar3 + 100 < iVar4) {
      *(int *)(param_1 + 0x4c) = iVar3 + 0x32;
    }
    else if (iVar4 < iVar3 + -100) {
      *(int *)(param_1 + 0x4c) = iVar3 + -0x32;
    }
  }
  FUN_10003ad0();
  iVar3 = FUN_1001fcf0();
  *(int *)(param_1 + 0x48) = *(int *)(param_1 + 0x48) + iVar3;
  FUN_10003ad0();
  uVar5 = FUN_1001fcf0();
  *(undefined4 *)(param_1 + 0x4c) = uVar5;
  if (*(char *)(param_1 + 0x36) == '\0') {
    *(uint *)(param_1 + 0x68) =
         ((uint)*(byte *)(param_1 + 0x35) * 0x193bf60) /
         (uint)((*(int *)(param_1 + 0x4c) * 3) / 100);
  }
  else {
    *(uint *)(param_1 + 0x68) =
         ((uint)*(byte *)(param_1 + 0x35) * 0x193bf60) /
         (uint)((*(int *)(param_1 + 0x4c) << 2) / 100);
  }
  if (0x1ffff < *(uint *)(param_1 + 0x68)) {
    *(undefined4 *)(param_1 + 0x68) = 0x1ffff;
  }
  fVar2 = _DAT_101517c0;
  *(float *)(param_1 + 0x54) =
       _DAT_101517c0 + *(float *)(&DAT_10054150 + (uint)*(byte *)(param_1 + 0x38) * 8);
  fVar1 = (float)_DAT_101517b8;
  *(float *)(param_1 + 0x58) =
       fVar2 + *(float *)(&DAT_10054154 + (uint)*(byte *)(param_1 + 0x38) * 8);
  *(float *)(param_1 + 100) = (float)*(byte *)(param_1 + 0x37) * fVar1;
  if (*(int *)(param_1 + 0x70) < 0x3f800001) {
    *(char *)(param_1 + 0x39) = (char)(longlong)ROUND(*(float *)(param_1 + 0x70) * _DAT_101517cc);
  }
  else {
    *(undefined1 *)(param_1 + 0x39) = 0x7f;
  }
  *(float *)(param_1 + 0x70) = *(float *)(param_1 + 0x70) * _DAT_101517c8;
  return;
}



void __fastcall FUN_10010220(undefined4 *param_1)

{
  *param_1 = &PTR_LAB_10032db4;
  return;
}



void FUN_10010290(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_100102f0;
  local_10 = ExceptionList;
  local_8 = 0xffffffff;
  ExceptionList = &local_10;
  FUN_10010220();
  ExceptionList = local_10;
  return;
}



undefined4 * __thiscall FUN_10010300(undefined4 *param_1,undefined4 param_2,undefined1 param_3)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  
  param_1[1] = 0;
  *param_1 = &PTR_LAB_10032db4;
  *(undefined1 *)(param_1 + 3) = param_3;
  pcVar2 = (char *)((int)param_1 + 0xd);
  param_1[2] = param_2;
  pcVar3 = &DAT_1014fc50;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
    *pcVar2 = cVar1;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  return param_1;
}



undefined4 * __thiscall FUN_10010304(undefined4 *param_1,undefined4 param_2,undefined1 param_3)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  
  param_1[1] = 0;
  *param_1 = &PTR_LAB_10032db4;
  *(undefined1 *)(param_1 + 3) = param_3;
  pcVar2 = (char *)((int)param_1 + 0xd);
  param_1[2] = param_2;
  pcVar3 = &DAT_1014fc50;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
    *pcVar2 = cVar1;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  return param_1;
}



void __fastcall FUN_10010340(undefined4 *param_1)

{
  *param_1 = &PTR_LAB_10032db4;
  return;
}



undefined1 __fastcall FUN_10010350(int param_1)

{
  return *(undefined1 *)(param_1 + 0xc);
}



void __thiscall FUN_10010360(int param_1,char *param_2)

{
  char cVar1;
  char *pcVar2;
  
  pcVar2 = (char *)(param_1 + 0xd);
  do {
    cVar1 = *param_2;
    param_2 = param_2 + 1;
    *pcVar2 = cVar1;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  return;
}



void __thiscall FUN_100103a0(undefined4 *param_1,undefined4 param_2,undefined1 param_3)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10010410;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10010304(param_2,param_3);
  *param_1 = &PTR_LAB_10032df4;
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_10010420(undefined4 *param_1,undefined4 param_2,undefined1 param_3)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_100104a0;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10010304(param_2,param_3);
  *(undefined2 *)(param_1 + 0xc) = 0;
  *param_1 = &PTR_LAB_10032e34;
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_100104b0(undefined4 *param_1,undefined4 param_2,undefined1 param_3)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10010520;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10010420(param_2,param_3);
  *param_1 = &PTR_LAB_10032e74;
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_10010530(undefined4 *param_1,undefined4 param_2,undefined1 param_3)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_100105a0;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10010420(param_2,param_3);
  *param_1 = &PTR_LAB_10032eb4;
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_100105b0(undefined4 *param_1,undefined4 param_2,undefined1 param_3)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  undefined1 auStack_6a [14];
  char local_5c [68];
  char *local_18;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10010660;
  local_10 = ExceptionList;
  local_14 = auStack_6a + -0x12;
  local_18 = local_5c;
  ExceptionList = &local_10;
  FUN_100103a0(param_2,param_3);
  local_8 = 0;
  *param_1 = &PTR_LAB_10032f04;
  sprintf(local_18,s_FTestDevice__d_101519ff + 1,(uint)*(byte *)(param_1 + 3));
  pcVar2 = (char *)((int)param_1 + 0xd);
  pcVar3 = local_5c;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
    *pcVar2 = cVar1;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  param_1[0xc] = 0x42a00000;
  param_1[0xd] = 0;
  ExceptionList = local_10;
  return;
}



undefined4 * __thiscall FUN_10010700(undefined4 *param_1,undefined4 param_2,undefined1 param_3)

{
  uint uVar1;
  uint uVar2;
  undefined1 auStack_4a [14];
  char local_3c [32];
  char *local_1c;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10010800;
  local_10 = ExceptionList;
  local_14 = auStack_4a + -0x12;
  local_1c = local_3c;
  ExceptionList = &local_10;
  FUN_10010530(param_2,param_3);
  local_8 = 0;
  *param_1 = &PTR_LAB_10033144;
  FUN_10019b30();
  FUN_10019b30();
  uVar1 = FUN_10010350();
  sprintf(local_1c,s_CDist__d_10151c0f + 1,uVar1 & 0xff);
  FUN_10010360(local_1c);
  *(undefined1 *)(param_1 + 0xe) = 0;
  *(undefined2 *)(param_1 + 0x17) = 0;
  param_1[0x12] = 0;
  param_1[0x11] = 0;
  param_1[0x16] = 0;
  param_1[0x15] = 0;
  param_1[0x14] = 0;
  uVar1 = 0;
  do {
    uVar2 = uVar1 + 1 & 0xff;
    *(undefined1 *)((int)param_1 + uVar1 + 0x4c) = 0;
    uVar1 = uVar2;
  } while (uVar2 < 4);
  FUN_10011210();
  ExceptionList = local_10;
  return param_1;
}



void __fastcall FUN_10010810(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10010880;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  *param_1 = &PTR_LAB_10033144;
  local_8 = 0xffffffff;
  FUN_1000e920();
  ExceptionList = local_10;
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void __fastcall FUN_10010894(int param_1)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  uint uVar8;
  uint uVar9;
  int iVar10;
  uint uVar11;
  int iVar12;
  ulonglong local_24;
  
  if (*(int *)(param_1 + 0x50) < 0x3f800001) {
    *(char *)(param_1 + 0x3c) = (char)(longlong)ROUND(*(float *)(param_1 + 0x50) * _DAT_10151b54);
  }
  else {
    *(undefined1 *)(param_1 + 0x3c) = 0x7f;
  }
  uVar8 = (uint)*(byte *)(param_1 + 0x3b);
  *(float *)(param_1 + 0x50) = *(float *)(param_1 + 0x50) * _DAT_10151b4c;
  if (uVar8 == 0) {
    *(undefined1 *)(param_1 + 0x38) = 1;
  }
  else {
    *(undefined1 *)(param_1 + 0x38) = 0;
  }
  local_24 = (ulonglong)uVar8;
  fVar1 = (float)local_24;
  local_24 = (ulonglong)(uint)*(byte *)(param_1 + 0x3a);
  fVar4 = fVar1 * _DAT_10151b50 * (float)_DAT_10151b20;
  fVar1 = (float)local_24;
  local_24._0_2_ = (ushort)(longlong)ROUND(fVar4);
  uVar11 = (uint)(ushort)local_24;
  fVar6 = fVar1 * _DAT_10151b50 * (float)_DAT_10151b20;
  *(float *)(param_1 + 0x54) =
       ((float)(&DAT_10054550)[*(byte *)(param_1 + 0x3a)] + (float)_DAT_10151b28) *
       (float)_DAT_10151b30;
  uVar9 = (uint)(ushort)(longlong)ROUND(fVar6);
  local_24 = (ulonglong)uVar11;
  fVar7 = (float)local_24;
  local_24 = (ulonglong)uVar9;
  iVar12 = uVar11 * 5 + 5 + uVar9;
  fVar6 = fVar6 - (float)local_24;
  fVar1 = *(float *)(&DAT_10151ab8 + (uVar11 * 5 + 6 + uVar9) * 4);
  fVar2 = *(float *)(&DAT_10151ab8 + iVar12 * 4);
  iVar10 = uVar9 + uVar11 * 5;
  fVar3 = *(float *)(&DAT_10151ab8 + iVar12 * 4);
  fVar5 = (*(float *)(&DAT_10151ab8 + (uVar11 * 5 + 1 + uVar9) * 4) -
          *(float *)(&DAT_10151ab8 + iVar10 * 4)) * fVar6 + *(float *)(&DAT_10151ab8 + iVar10 * 4);
  *(short *)(param_1 + 0x5c) = (short)((int)(uVar8 * 0x20) >> 7);
  *(float *)(param_1 + 0x58) =
       (fVar5 + (((fVar1 - fVar2) * fVar6 + fVar3) - fVar5) * (fVar4 - fVar7)) *
       (float)_DAT_10151b38 * (float)_DAT_10151b40;
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void FUN_10011210(void)

{
  float10 fVar1;
  float10 fVar2;
  float10 fVar3;
  float10 fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  uint uVar8;
  float10 fVar9;
  float10 fVar10;
  float10 fVar11;
  uint local_14;
  
  if (DAT_100d47a0 == '\0') {
    local_14 = 0;
    do {
      fVar3 = (float10)_DAT_10151c00;
      fVar4 = (float10)_DAT_10151c04;
      fVar1 = (float10)_DAT_10151c08;
      uVar8 = 0x80;
      fVar5 = _DAT_10151bfc;
      fVar6 = _DAT_10151bfc;
      fVar7 = _DAT_10151bfc;
      do {
        fVar9 = (float10)fsin((float10)fVar5);
        fVar10 = (float10)fVar6;
        fVar11 = (float10)fVar7;
        fVar2 = (float10)_DAT_10151bf0;
        fVar7 = fVar7 + (float)_DAT_10151bf0;
        fVar11 = (fVar10 * fVar11 * (float10)_DAT_10151c0c +
                 ((float10)_DAT_10151be0 - fVar10) * fVar9 * (float10)_DAT_10151c0c) *
                 (float10)_DAT_10151be8;
        *(float *)(&DAT_100d47a4 + (uVar8 + local_14 * 0x100) * 4) = (float)fVar11;
        *(float *)(local_14 * 0x400 + 0x100d4ba4 + uVar8 * -4) = (float)-fVar11;
        fVar6 = (float)(fVar10 + fVar2);
        fVar5 = fVar5 + (float)((float10)local_14 * (float10)local_14 * fVar3 * fVar4 + fVar1);
        uVar8 = uVar8 + 1 & 0xffff;
      } while (uVar8 < 0x100);
      *(float *)(&DAT_100d47a4 + local_14 * 0x400) = -*(float *)(&DAT_100d4ba0 + local_14 * 0x400);
      local_14 = local_14 + 1 & 0xffff;
    } while (local_14 < 0x20);
    DAT_100d47a0 = '\x01';
  }
  return;
}



undefined4 * __thiscall FUN_10011350(undefined4 *param_1,undefined1 param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  void *pvVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint local_3c;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10011b90;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  param_1[1] = 0;
  *param_1 = 0;
  FUN_1001ec50(param_1);
  local_8 = 0;
  iVar3 = 4;
  *(undefined2 *)(param_1 + 0x28) = 0;
  puVar1 = param_1 + 0x29;
  do {
    *puVar1 = 0x358637bd;
    puVar1[1] = 0x358637bd;
    iVar3 = iVar3 + -1;
    puVar1[2] = 0x358637bd;
    puVar1[10] = 0;
    puVar1[9] = 0;
    puVar1[8] = 0;
    *(undefined2 *)(puVar1 + 7) = 0;
    puVar1[6] = 0;
    puVar1[5] = 0;
    puVar1[4] = 0x358637bd;
    puVar1[3] = 0x358637bd;
    puVar1 = puVar1 + 0xb;
  } while (iVar3 != 0);
  FUN_100093c0();
  local_8 = 1;
  FUN_10018ac0();
  param_1[0x82] = 0;
  *(undefined2 *)(param_1 + 0x7e) = 0;
  *(undefined2 *)(param_1 + 0x7a) = 0;
  *(undefined1 *)(param_1 + 0x76) = 0;
  *(undefined1 *)(param_1 + 0x71) = 0;
  param_1[0x61] = 0;
  param_1[0x5c] = 0;
  param_1[0x5d] = param_3;
  *(undefined1 *)(param_1 + 0x5e) = param_2;
  *(undefined1 *)((int)param_1 + 0x179) = 1;
  param_1[0x5f] = 0x3f800000;
  param_1[0x60] = 0x3f800000;
  param_1[0x62] = 10;
  uVar4 = 0;
  do {
    uVar5 = uVar4 + 1;
    param_1[uVar4 + 99] = 0;
    uVar4 = uVar5;
  } while (uVar5 < 0xe);
  uVar4 = 0;
  do {
    uVar5 = uVar4 + 1;
    param_1[uVar4 + 0x72] = 0;
    uVar4 = uVar5;
  } while (uVar5 < 4);
  uVar4 = 0;
  do {
    uVar5 = uVar4 + 1;
    param_1[uVar4 + 0x77] = 0;
    uVar4 = uVar5;
  } while (uVar5 < 3);
  uVar4 = 0;
  do {
    uVar5 = uVar4 + 1;
    param_1[uVar4 + 0x7b] = 0;
    uVar4 = uVar5;
  } while (uVar5 < 3);
  uVar4 = 0;
  do {
    uVar5 = uVar4 + 1;
    param_1[uVar4 + 0x7f] = 0;
    uVar4 = uVar5;
  } while (uVar5 < 3);
  uVar4 = 0;
  do {
    puVar1 = param_1 + uVar4 * 0x40 + 0x583;
    do {
      *puVar1 = 0x358637bd;
      puVar1 = puVar1 + 1;
    } while ((int)puVar1 < (int)(param_1 + uVar4 * 0x40 + 0x5c3));
    uVar4 = uVar4 + 1 & 0xffff;
  } while (uVar4 < 3);
  uVar4 = 0;
  do {
    puVar1 = param_1 + uVar4 * 0x40 + 0x83;
    do {
      *puVar1 = 0;
      puVar1 = puVar1 + 1;
    } while (puVar1 < param_1 + uVar4 * 0x40 + 0xc3);
    uVar4 = uVar4 + 1 & 0xffff;
  } while (uVar4 < 0x12);
  if (DAT_100e0128 == '\0') {
    FUN_100046b0();
    DAT_100e0128 = '\x01';
  }
  local_8 = 2;
  pvVar2 = operator_new(0xa0);
  if (pvVar2 == (void *)0x0) {
    pvVar2 = (void *)0x0;
  }
  else {
    FUN_10015400(param_1,0);
  }
  param_1[0x5c] = pvVar2;
  FUN_10014034(pvVar2);
  FUN_1001eef0(0,0,0x1d);
  pvVar2 = operator_new(0xd04);
  if (pvVar2 == (void *)0x0) {
    pvVar2 = (void *)0x0;
  }
  else {
    FUN_10023920(param_1,1);
  }
  FUN_10014064(pvVar2);
  FUN_1001eef0(1,1,0xc);
  pvVar2 = operator_new(0xd04);
  if (pvVar2 == (void *)0x0) {
    pvVar2 = (void *)0x0;
  }
  else {
    FUN_10023920(param_1,2);
  }
  FUN_10014064(pvVar2);
  FUN_1001eef0(2,2,0xc);
  pvVar2 = operator_new(0x1910);
  if (pvVar2 == (void *)0x0) {
    pvVar2 = (void *)0x0;
  }
  else {
    FUN_10026f70(param_1,3,param_1[0x5d]);
  }
  FUN_10014064(pvVar2);
  FUN_1001eef0(3,3,0x20);
  pvVar2 = operator_new(0x1920);
  if (pvVar2 == (void *)0x0) {
    pvVar2 = (void *)0x0;
  }
  else {
    FUN_1002a380(param_1,4,param_1[0x5d]);
  }
  FUN_10014064(pvVar2);
  FUN_1001eef0(4,4,0x21);
  pvVar2 = operator_new(0x74);
  if (pvVar2 == (void *)0x0) {
    pvVar2 = (void *)0x0;
  }
  else {
    FUN_1000f5a0(param_1,5);
  }
  FUN_100140b4(pvVar2);
  FUN_1001eef0(5,5,6);
  pvVar2 = operator_new(0x60);
  if (pvVar2 == (void *)0x0) {
    pvVar2 = (void *)0x0;
  }
  else {
    FUN_10010700(param_1,6);
  }
  FUN_10014104(pvVar2);
  FUN_1001eef0(6,6,4);
  pvVar2 = operator_new(0x8c);
  if (pvVar2 == (void *)0x0) {
    pvVar2 = (void *)0x0;
  }
  else {
    FUN_10016490(param_1,7);
  }
  FUN_10014104(pvVar2);
  FUN_1001eef0(7,7,8);
  pvVar2 = operator_new(0x6c);
  if (pvVar2 == (void *)0x0) {
    pvVar2 = (void *)0x0;
  }
  else {
    FUN_1000e990(param_1,8);
  }
  FUN_10014104(pvVar2);
  FUN_1001eef0(8,8,5);
  local_3c = 0;
  if (*(char *)(param_1 + 0x71) != '\0') {
    do {
      (**(code **)(*(int *)param_1[local_3c + 99] + 0x1c))();
      local_3c = local_3c + 1 & 0xff;
    } while (local_3c < *(byte *)(param_1 + 0x71));
  }
  uVar4 = 0;
  if (*(char *)(param_1 + 0x71) != '\0') {
    do {
      (**(code **)(*(int *)param_1[uVar4 + 99] + 0x20))(0);
      uVar4 = uVar4 + 1 & 0xff;
    } while (uVar4 < *(byte *)(param_1 + 0x71));
  }
  FUN_1001fcd0(140000);
  FUN_1001f980(0);
  FUN_10012c14();
  ExceptionList = local_10;
  return param_1;
}



void __fastcall FUN_10011ba0(int param_1)

{
  undefined4 *puVar1;
  uint uVar2;
  uint local_1c;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10011d60;
  local_10 = ExceptionList;
  local_8 = 1;
  ExceptionList = &local_10;
  FUN_1001bf40(param_1);
  uVar2 = 0;
  if (*(short *)(param_1 + 0x1e8) != 0) {
    do {
      *(undefined4 *)(param_1 + 0x1dc + uVar2 * 4) = 0;
      uVar2 = uVar2 + 1 & 0xffff;
    } while (uVar2 < *(ushort *)(param_1 + 0x1e8));
  }
  *(undefined2 *)(param_1 + 0x1e8) = 0;
  uVar2 = 0;
  if (CONCAT11(*(undefined1 *)(param_1 + 0x1f9),*(undefined1 *)(param_1 + 0x1f8)) != 0) {
    do {
      *(undefined4 *)(param_1 + 0x1ec + uVar2 * 4) = 0;
      uVar2 = uVar2 + 1 & 0xffff;
    } while (uVar2 < *(ushort *)(param_1 + 0x1f8));
  }
  *(undefined2 *)(param_1 + 0x1f8) = 0;
  uVar2 = 0;
  if (*(char *)(param_1 + 0x1d8) != '\0') {
    do {
      *(undefined4 *)(param_1 + 0x1c8 + uVar2 * 4) = 0;
      uVar2 = uVar2 + 1 & 0xffff;
    } while (uVar2 < *(byte *)(param_1 + 0x1d8));
  }
  *(undefined1 *)(param_1 + 0x1d8) = 0;
  local_1c = 0;
  if (*(char *)(param_1 + 0x1c4) != '\0') {
    do {
      puVar1 = *(undefined4 **)(param_1 + 0x18c + local_1c * 4);
      if (puVar1 != (undefined4 *)0x0) {
        (**(code **)*puVar1)(1);
      }
      *(undefined4 *)(param_1 + 0x18c + local_1c * 4) = 0;
      local_1c = local_1c + 1 & 0xffff;
    } while (local_1c < *(byte *)(param_1 + 0x1c4));
  }
  local_8 = 0;
  FUN_10009420();
  local_8 = 0xffffffff;
  FUN_1001eeb0();
  ExceptionList = local_10;
  return;
}



undefined1 __fastcall FUN_10011d70(int param_1)

{
  return *(undefined1 *)(param_1 + 0x178);
}



void __thiscall FUN_10011d84(int param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  
  FUN_10009480();
  iVar2 = 0;
  *(undefined4 *)(param_1 + 0x174) = param_2;
  if (*(char *)(param_1 + 0x1c4) != '\0') {
    do {
      cVar1 = FUN_10010350();
      if (cVar1 == '\x03') break;
      iVar2 = (iVar2 + 1) * 0x10000 >> 0x10;
    } while (iVar2 < (int)(uint)*(byte *)(param_1 + 0x1c4));
  }
  FUN_10028290(*(undefined4 *)(param_1 + 0x174));
  iVar2 = 0;
  if (*(char *)(param_1 + 0x1c4) != '\0') {
    do {
      cVar1 = FUN_10010350();
      if (cVar1 == '\x04') break;
      iVar2 = (iVar2 + 1) * 0x10000 >> 0x10;
    } while (iVar2 < (int)(uint)*(byte *)(param_1 + 0x1c4));
  }
  FUN_1002b8c0(*(undefined4 *)(param_1 + 0x174));
  FUN_100094a0();
  return;
}



undefined4 __thiscall FUN_10011e60(int param_1,char param_2)

{
  char cVar1;
  int iVar2;
  
  iVar2 = 0;
  if (*(char *)(param_1 + 0x1c4) != '\0') {
    do {
      cVar1 = FUN_10010350();
      if (cVar1 == param_2) {
        return *(undefined4 *)(param_1 + 0x18c + iVar2 * 4);
      }
      iVar2 = (iVar2 + 1) * 0x10000 >> 0x10;
    } while (iVar2 < (int)(uint)*(byte *)(param_1 + 0x1c4));
  }
  return 0;
}



void __thiscall FUN_10011ed0(int param_1,undefined4 *param_2,uint param_3)

{
  undefined4 uVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined1 auStack_ca [14];
  undefined1 local_bc [24];
  undefined1 local_a4;
  undefined1 local_a3;
  undefined1 local_a0;
  undefined1 local_9f [7];
  undefined1 local_98;
  char local_97;
  undefined1 local_96;
  undefined1 local_95;
  undefined4 local_94;
  undefined4 local_90;
  undefined4 local_8c;
  undefined4 local_88;
  undefined1 local_84;
  undefined1 local_83;
  undefined1 local_82;
  undefined1 local_80;
  undefined1 local_7f;
  undefined1 local_7c;
  undefined1 local_7b;
  undefined1 local_78;
  undefined1 local_77;
  undefined1 local_74;
  undefined1 local_73 [7];
  undefined1 local_6c;
  undefined1 local_6b [7];
  undefined1 local_64;
  undefined1 local_63 [7];
  undefined1 local_5c;
  undefined1 local_5b;
  undefined1 local_58;
  undefined1 local_57;
  uint local_54;
  undefined4 local_50;
  int local_4c;
  int local_48;
  undefined1 *local_44;
  undefined1 *local_40;
  undefined1 *local_3c;
  undefined1 *local_38;
  undefined1 *local_34;
  undefined1 *local_30;
  undefined1 *local_2c;
  undefined1 *local_28;
  undefined4 local_24;
  int local_20;
  uint local_1c;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10012930;
  local_10 = ExceptionList;
  local_14 = auStack_ca + -0x12;
  local_1c = (uint)*(byte *)(param_1 + 0x178);
  local_28 = &local_5c;
  local_2c = &local_78;
  local_38 = &local_74;
  local_3c = &local_a0;
  local_40 = &local_6c;
  local_44 = &local_64;
  local_30 = &local_80;
  local_34 = &local_a4;
  local_20 = param_1;
  switch(*(undefined1 *)param_2) {
  case 0x13:
    DAT_100dc7b0 = 0x4e;
    DAT_100dc7b1 = *(undefined1 *)(param_1 + 0x178);
    puVar5 = &DAT_100dc7b2;
    ExceptionList = &local_10;
    for (uVar2 = param_3 >> 2; uVar2 != 0; uVar2 = uVar2 - 1) {
      *puVar5 = *param_2;
      param_2 = param_2 + 1;
      puVar5 = puVar5 + 1;
    }
    for (uVar2 = param_3 & 3; uVar2 != 0; uVar2 = uVar2 - 1) {
      *(undefined1 *)puVar5 = *(undefined1 *)param_2;
      param_2 = (undefined4 *)((int)param_2 + 1);
      puVar5 = (undefined4 *)((int)puVar5 + 1);
    }
    local_14 = auStack_ca + -0x12;
    FUN_1001d690(&DAT_100dc7b0,param_3 + 2);
    break;
  case 0x14:
    switch(*(undefined1 *)((int)param_2 + 1)) {
    case 0:
      local_7c = 0;
      local_7b = *(undefined1 *)(param_1 + 0x158);
      ExceptionList = &local_10;
      local_14 = auStack_ca + -0x12;
      FUN_1001ded0(local_1c,0x23,&local_7c,2);
      break;
    case 1:
      local_58 = 1;
      local_57 = *(undefined1 *)(param_1 + 0x159);
      ExceptionList = &local_10;
      local_14 = auStack_ca + -0x12;
      FUN_1001ded0(local_1c,0x23,&local_58,2);
      break;
    case 2:
      local_5c = 2;
      local_5b = *(undefined1 *)(param_1 + 0x15a);
      ExceptionList = &local_10;
      local_14 = auStack_ca + -0x12;
      FUN_1001ded0(local_1c,0x23,local_28,2);
      break;
    case 3:
      local_78 = 3;
      local_77 = *(undefined1 *)(param_1 + 0x15b);
      ExceptionList = &local_10;
      local_14 = auStack_ca + -0x12;
      FUN_1001ded0(local_1c,0x23,local_2c,2);
      break;
    case 4:
      local_74 = 4;
      ExceptionList = &local_10;
      local_14 = auStack_ca + -0x12;
      FUN_100040e0(local_73,*(undefined4 *)(param_1 + 0x15c));
      FUN_1001ded0(local_1c,0x23,local_38,5);
      break;
    case 5:
    case 6:
    case 7:
    case 9:
    case 10:
    case 0xb:
    case 0xd:
    case 0xe:
    case 0xf:
    case 0x11:
    case 0x12:
    case 0x13:
      break;
    case 8:
      local_a0 = 8;
      ExceptionList = &local_10;
      local_14 = auStack_ca + -0x12;
      FUN_100040e0(local_9f,*(undefined4 *)(param_1 + 0x160));
      FUN_1001ded0(local_1c,0x23,local_3c,5);
      break;
    case 0xc:
      local_6c = 0xc;
      ExceptionList = &local_10;
      local_14 = auStack_ca + -0x12;
      FUN_100040e0(local_6b,*(undefined4 *)(param_1 + 0x164));
      FUN_1001ded0(local_1c,0x23,local_40,5);
      break;
    case 0x10:
      local_64 = 0x10;
      ExceptionList = &local_10;
      local_14 = auStack_ca + -0x12;
      FUN_100040e0(local_63,*(undefined4 *)(param_1 + 0x168));
      FUN_1001ded0(local_1c,0x23,local_44,5);
      break;
    case 0x14:
      local_80 = 0x14;
      local_7f = *(undefined1 *)(param_1 + 0x16c);
      ExceptionList = &local_10;
      local_14 = auStack_ca + -0x12;
      FUN_1001ded0(local_1c,0x23,local_30,2);
      break;
    case 0x15:
      local_a4 = 0x15;
      local_a3 = *(undefined1 *)(param_1 + 0x16d);
      ExceptionList = &local_10;
      local_14 = auStack_ca + -0x12;
      FUN_1001ded0(local_1c,0x23,local_34,2);
    }
    break;
  case 0x15:
    ExceptionList = &local_10;
    local_14 = auStack_ca + -0x12;
    FUN_10018b00(local_bc);
    FUN_1001ded0(local_1c,0x24,local_bc,0x17);
    break;
  case 0x16:
    ExceptionList = &local_10;
    local_14 = auStack_ca + -0x12;
    FUN_10020ec0(param_2,param_3);
    break;
  case 0x17:
    *(undefined1 *)(param_1 + 0x179) = *(undefined1 *)param_2;
    break;
  case 0x18:
  case 0x19:
  case 0x1a:
  case 0x1b:
    DAT_100dc7b0 = 0x4e;
    DAT_100dc7b1 = *(undefined1 *)(param_1 + 0x178);
    puVar5 = &DAT_100dc7b2;
    ExceptionList = &local_10;
    for (uVar2 = param_3 >> 2; uVar2 != 0; uVar2 = uVar2 - 1) {
      *puVar5 = *param_2;
      param_2 = param_2 + 1;
      puVar5 = puVar5 + 1;
    }
    for (uVar2 = param_3 & 3; uVar2 != 0; uVar2 = uVar2 - 1) {
      *(undefined1 *)puVar5 = *(undefined1 *)param_2;
      param_2 = (undefined4 *)((int)param_2 + 1);
      puVar5 = (undefined4 *)((int)puVar5 + 1);
    }
    local_14 = auStack_ca + -0x12;
    FUN_1001d690(&DAT_100dc7b0,param_3 + 2);
    break;
  case 0x1c:
    local_8 = 0;
    local_4c = param_1 + 8;
    ExceptionList = &local_10;
    local_14 = auStack_ca + -0x12;
    FUN_1001fd70();
    iVar4 = local_20;
    uVar2 = 0;
    if (*(char *)(local_20 + 0x1c4) != '\0') {
      do {
        (**(code **)(**(int **)(iVar4 + 0x18c + uVar2 * 4) + 0x20))(0);
        uVar2 = uVar2 + 1 & 0xff;
      } while (uVar2 < *(byte *)(iVar4 + 0x1c4));
    }
    uVar1 = FUN_1001f870();
    FUN_1001fdc0(uVar1);
    break;
  case 0x1d:
    local_8 = 2;
    local_48 = param_1 + 8;
    ExceptionList = &local_10;
    local_14 = auStack_ca + -0x12;
    uVar1 = FUN_1001f8e0();
    FUN_10021520(uVar1);
    local_50 = FUN_1001f8c0();
    uVar1 = FUN_1001f8e0();
    FUN_100208a0(local_50,uVar1);
    uVar1 = FUN_1001f8c0();
    iVar4 = local_20;
    uVar2 = 0;
    local_24 = uVar1;
    if (*(char *)(local_20 + 0x1c4) != '\0') {
      do {
        (**(code **)(**(int **)(iVar4 + 0x18c + uVar2 * 4) + 0x20))(uVar1);
        uVar2 = uVar2 + 1 & 0xff;
      } while (uVar2 < *(byte *)(iVar4 + 0x1c4));
    }
    uVar1 = FUN_1001f870();
    FUN_1001fdc0(uVar1);
    break;
  case 0x1e:
    local_8 = 4;
    ExceptionList = &local_10;
    local_14 = auStack_ca + -0x12;
    FUN_1001feb0();
    break;
  case 0x1f:
    local_8 = 6;
    ExceptionList = &local_10;
    local_14 = auStack_ca + -0x12;
    FUN_100201e0();
    break;
  case 0x20:
    ExceptionList = &local_10;
    local_14 = auStack_ca + -0x12;
    uVar1 = FUN_1001f870();
    FUN_1001f980(uVar1);
    break;
  case 0x21:
    ExceptionList = &local_10;
    local_14 = auStack_ca + -0x12;
    FUN_10014140();
    break;
  case 0x22:
  case 0x26:
  case 0x27:
    break;
  case 0x23:
    switch(*(undefined1 *)((int)param_2 + 1)) {
    case 0:
      ExceptionList = &local_10;
      local_14 = auStack_ca + -0x12;
      FUN_1001fbe0(*(undefined1 *)((int)param_2 + 2));
      break;
    case 1:
      if (*(char *)((int)param_2 + 2) == '\0') {
        ExceptionList = &local_10;
        local_14 = auStack_ca + -0x12;
        FUN_1001e100(param_1);
      }
      else {
        ExceptionList = &local_10;
        local_14 = auStack_ca + -0x12;
        FUN_1001bf50(param_1);
      }
      break;
    case 2:
      ExceptionList = &local_10;
      local_14 = auStack_ca + -0x12;
      FUN_10021190(*(undefined1 *)((int)param_2 + 2));
      break;
    case 3:
      ExceptionList = &local_10;
      local_14 = auStack_ca + -0x12;
      FUN_1001c0a0(param_1,*(undefined1 *)((int)param_2 + 2));
      break;
    case 4:
      ExceptionList = &local_10;
      local_14 = auStack_ca + -0x12;
      uVar1 = FUN_100040b0((undefined1 *)((int)param_2 + 2),local_bc);
      FUN_1001bfc0(local_20,uVar1);
      break;
    case 5:
    case 6:
    case 7:
    case 9:
    case 10:
    case 0xb:
    case 0xd:
    case 0xe:
    case 0xf:
    case 0x11:
    case 0x12:
    case 0x13:
      break;
    case 8:
      ExceptionList = &local_10;
      local_14 = auStack_ca + -0x12;
      uVar1 = FUN_100040b0((undefined1 *)((int)param_2 + 2),local_bc);
      FUN_1001bf70(local_20,uVar1);
      break;
    case 0xc:
      ExceptionList = &local_10;
      local_14 = auStack_ca + -0x12;
      uVar1 = FUN_100040b0((undefined1 *)((int)param_2 + 2),local_bc);
      FUN_1001c000(local_20,uVar1);
      break;
    case 0x10:
      ExceptionList = &local_10;
      local_14 = auStack_ca + -0x12;
      uVar1 = FUN_100040b0((undefined1 *)((int)param_2 + 2),local_bc);
      FUN_1001c050(local_20,uVar1);
      break;
    case 0x14:
      ExceptionList = &local_10;
      local_14 = auStack_ca + -0x12;
      FUN_10021170(*(undefined1 *)((int)param_2 + 2));
      break;
    case 0x15:
      *(undefined1 *)(param_1 + 0x16d) = *(undefined1 *)((int)param_2 + 2);
      break;
    case 0x16:
      *(undefined1 *)(param_1 + 0x16e) = *(undefined1 *)((int)param_2 + 2);
    }
    break;
  case 0x24:
    ExceptionList = &local_10;
    local_14 = auStack_ca + -0x12;
    FUN_10018ac0();
    FUN_10018ba0((undefined1 *)((int)param_2 + 1));
    FUN_1001fbe0(local_98);
    if (local_97 == '\0') {
      FUN_1001e100(local_20);
    }
    else {
      FUN_1001bf50(local_20);
    }
    FUN_10021190(local_96);
    FUN_1001c0a0(local_20,local_95);
    FUN_1001bfc0(local_20,local_94);
    FUN_1001bf70(local_20,local_90);
    FUN_1001c000(local_20,local_8c);
    FUN_1001c050(local_20,local_88);
    FUN_10021170(local_84);
    *(undefined1 *)(local_20 + 0x16d) = local_83;
    *(undefined1 *)(local_20 + 0x16e) = local_82;
    break;
  case 0x25:
    ExceptionList = &local_10;
    local_14 = auStack_ca + -0x12;
    FUN_10021010(param_2,param_3);
    break;
  case 0x28:
    DAT_100dc7b0 = 0x4e;
    DAT_100dc7b1 = *(undefined1 *)(param_1 + 0x178);
    puVar5 = &DAT_100dc7b2;
    ExceptionList = &local_10;
    for (uVar2 = param_3 >> 2; uVar2 != 0; uVar2 = uVar2 - 1) {
      *puVar5 = *param_2;
      param_2 = param_2 + 1;
      puVar5 = puVar5 + 1;
    }
    for (uVar2 = param_3 & 3; uVar2 != 0; uVar2 = uVar2 - 1) {
      *(undefined1 *)puVar5 = *(undefined1 *)param_2;
      param_2 = (undefined4 *)((int)param_2 + 1);
      puVar5 = (undefined4 *)((int)puVar5 + 1);
    }
    FUN_1001d690(&DAT_100dc7b0,param_3 + 2);
    break;
  case 0x29:
    iVar4 = 0;
    local_54 = (uint)*(byte *)((int)param_2 + 1);
    ExceptionList = &local_10;
    local_14 = auStack_ca + -0x12;
    if (*(char *)(param_1 + 0x1c4) != '\0') {
      ExceptionList = &local_10;
      local_14 = auStack_ca + -0x12;
      do {
        uVar2 = FUN_10010350();
        if ((uVar2 & 0xff) == local_54) {
          piVar3 = *(int **)(param_1 + 0x18c + iVar4 * 4);
          goto LAB_100128b9;
        }
        iVar4 = (iVar4 + 1) * 0x10000 >> 0x10;
      } while (iVar4 < (int)(uint)*(byte *)(param_1 + 0x1c4));
    }
    piVar3 = (int *)0x0;
LAB_100128b9:
    (**(code **)(*piVar3 + 0x28))((undefined1 *)((int)param_2 + 2),param_3 - 2);
  }
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_10012940(int param_1,undefined1 *param_2)

{
  char cVar1;
  undefined2 uVar2;
  int iVar3;
  undefined1 auStack_c [4];
  
  switch(*param_2) {
  case 0x13:
    uVar2 = FUN_10004060(param_2 + 1);
    iVar3 = FUN_1001a860(uVar2);
    if (iVar3 != 0) {
      FUN_10011d84(iVar3);
    }
    FUN_1001d3d0(*(undefined1 *)(param_1 + 0x178),0x27,auStack_c,0);
    return;
  case 0x14:
  case 0x15:
  case 0x16:
  case 0x17:
  case 0x1c:
  case 0x1d:
  case 0x1e:
  case 0x1f:
  case 0x20:
  case 0x21:
  case 0x22:
  case 0x23:
  case 0x24:
  case 0x25:
  case 0x26:
  case 0x27:
    break;
  case 0x18:
    FUN_10009480();
    cVar1 = FUN_10020440();
    if (cVar1 == '\0') {
      FUN_1001dfc0(0x14);
    }
    else {
      FUN_1001d320(0x4a);
    }
    FUN_100094a0();
    return;
  case 0x19:
    FUN_10009480();
    FUN_10020670();
    FUN_100094a0();
    return;
  case 0x1a:
    FUN_10009480();
    cVar1 = FUN_100208f0();
    if (cVar1 == '\0') {
      FUN_1001dfc0(0x15);
    }
    else {
      FUN_1001d320(0x4a);
    }
    FUN_100094a0();
    return;
  case 0x1b:
    FUN_10009480();
    cVar1 = FUN_10020bc0();
    if (cVar1 == '\0') {
      FUN_1001dfc0(0x15);
    }
    else {
      FUN_1001d320(0x4a);
    }
    FUN_100094a0();
    return;
  }
  return;
}



void __thiscall FUN_10012b40(int param_1,char param_2,undefined1 param_3,undefined1 param_4)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  
  iVar3 = 0;
  if (*(char *)(param_1 + 0x1c4) != '\0') {
    do {
      cVar1 = FUN_10010350();
      if (cVar1 == param_2) {
        piVar2 = *(int **)(param_1 + 0x18c + iVar3 * 4);
        goto LAB_10012b95;
      }
      iVar3 = (iVar3 + 1) * 0x10000 >> 0x10;
    } while (iVar3 < (int)(uint)*(byte *)(param_1 + 0x1c4));
  }
  piVar2 = (int *)0x0;
LAB_10012b95:
  (**(code **)(*piVar2 + 0x2c))(param_3,param_4);
  return;
}



void FUN_10012bc0(undefined1 param_1,undefined1 param_2,undefined1 param_3)

{
  FUN_10021340(param_1,param_2,param_3);
  return;
}



void FUN_10012c00(void)

{
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void __fastcall FUN_10012c14(float *param_1)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  byte *pbVar4;
  float fVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  bool bVar9;
  uint local_18;
  
  iVar2 = FUN_10015d30();
  iVar8 = *(int *)(iVar2 + 4);
  iVar2 = *(int *)(iVar2 + 8);
  local_18 = 0;
  do {
    pcVar3 = (char *)FUN_10015d10(local_18 & 0xff);
    fVar5 = _DAT_10151f30;
    if (*pcVar3 == '\0') {
      uVar6 = 0;
    }
    else {
      uVar6 = (uint)(byte)pcVar3[1];
    }
    iVar7 = (uint)(byte)pcVar3[2] + uVar6 * 0x80;
    cVar1 = *(char *)((int)param_1 + 0x16d);
    param_1[local_18 * 0xb + 0x2a] = _DAT_10151f30 + *(float *)(&DAT_10034550 + iVar7 * 8);
    param_1[local_18 * 0xb + 0x29] = fVar5 + *(float *)(&DAT_10034554 + iVar7 * 8);
    if (cVar1 == '\0') {
      param_1[local_18 * 0xb + 0x2d] =
           (float)(&DAT_10054550)[uVar6] * (float)(&DAT_10054550)[(byte)pcVar3[3]] + _DAT_10151f30;
    }
    else {
      param_1[local_18 * 0xb + 0x2d] =
           (*(float *)(&DAT_10034550 + iVar7 * 8) + *(float *)(&DAT_10034554 + iVar7 * 8)) *
           (float)(&DAT_10054550)[(byte)pcVar3[3]] * (float)_DAT_10151f20 + (float)_DAT_10151f28;
    }
    if (_DAT_10151f34 < (float)(&DAT_10054550)[uVar6] * param_1[local_18 * 0xb + 0x2e]) {
      pcVar3[5] = '\x7f';
    }
    else {
      pcVar3[5] = (char)(longlong)
                        ROUND((float)(&DAT_10054550)[uVar6] * param_1[local_18 * 0xb + 0x2e] *
                              _DAT_10151f3c);
    }
    fVar5 = param_1[local_18 * 0xb + 0x2e] * _DAT_10151f38;
    *(undefined2 *)(param_1 + local_18 * 0xb + 0x30) = 1;
    param_1[local_18 * 0xb + 0x2f] = (float)(param_1 + 0x583);
    param_1[local_18 * 0xb + 0x2e] = fVar5;
    if (pcVar3[4] == '\0') {
      if (param_1[local_18 * 0xb + 0x31] != 0.0) {
        param_1[local_18 * 0xb + 0x31] = 0.0;
      }
    }
    else {
      if (*(char *)(param_1 + 0x71) != '\0') {
        iVar7 = 0;
        do {
          cVar1 = FUN_10010350();
          if (cVar1 == '\x06') {
            fVar5 = param_1[iVar7 + 99];
            if (fVar5 != 0.0) goto LAB_10012e16;
            break;
          }
          iVar7 = (iVar7 + 1) * 0x10000 >> 0x10;
        } while (iVar7 < (int)(uint)*(byte *)(param_1 + 0x71));
      }
      fVar5 = 0.0;
LAB_10012e16:
      fVar5 = (float)__RTDynamicCast(fVar5,0,&CDevice::RTTI_Type_Descriptor,
                                     &CInsertEffect::RTTI_Type_Descriptor,0);
      param_1[local_18 * 0xb + 0x31] = fVar5;
    }
    if (iVar2 == 1) {
      bVar9 = local_18 == 0;
LAB_10012eba:
      if (!bVar9) goto LAB_10012ebe;
      if (*(char *)(param_1 + 0x71) != '\0') {
        iVar7 = 0;
        do {
          cVar1 = FUN_10010350();
          if (cVar1 == '\a') {
            fVar5 = param_1[iVar7 + 99];
            if (fVar5 != 0.0) goto LAB_10012f30;
            break;
          }
          iVar7 = (iVar7 + 1) * 0x10000 >> 0x10;
        } while (iVar7 < (int)(uint)*(byte *)(param_1 + 0x71));
      }
      fVar5 = 0.0;
LAB_10012f30:
      fVar5 = (float)__RTDynamicCast(fVar5,0,&CDevice::RTTI_Type_Descriptor,
                                     &CInsertEffect::RTTI_Type_Descriptor,0);
      param_1[local_18 * 0xb + 0x32] = fVar5;
    }
    else {
      if (iVar2 == 2) {
        bVar9 = local_18 == 1;
        goto LAB_10012eba;
      }
      if (iVar2 == 3) {
        bVar9 = local_18 == 2;
        goto LAB_10012eba;
      }
      if (iVar2 == 4) {
        bVar9 = local_18 == 3;
        goto LAB_10012eba;
      }
LAB_10012ebe:
      if (param_1[local_18 * 0xb + 0x32] != 0.0) {
        param_1[local_18 * 0xb + 0x32] = 0.0;
      }
    }
    if (iVar8 == 2) {
      bVar9 = local_18 == 0;
LAB_10012fd4:
      if (!bVar9) goto LAB_10012fd8;
      if (*(char *)(param_1 + 0x71) != '\0') {
        iVar7 = 0;
        do {
          cVar1 = FUN_10010350();
          if (cVar1 == '\b') {
            fVar5 = param_1[iVar7 + 99];
            if (fVar5 != 0.0) goto LAB_1001304a;
            break;
          }
          iVar7 = (iVar7 + 1) * 0x10000 >> 0x10;
        } while (iVar7 < (int)(uint)*(byte *)(param_1 + 0x71));
      }
      fVar5 = 0.0;
LAB_1001304a:
      fVar5 = (float)__RTDynamicCast(fVar5,0,&CDevice::RTTI_Type_Descriptor,
                                     &CInsertEffect::RTTI_Type_Descriptor,0);
      param_1[local_18 * 0xb + 0x33] = fVar5;
    }
    else {
      if (iVar8 == 3) {
        bVar9 = local_18 == 1;
        goto LAB_10012fd4;
      }
      if (iVar8 == 4) {
        bVar9 = local_18 == 2;
        goto LAB_10012fd4;
      }
      if (iVar8 == 5) {
        bVar9 = local_18 == 3;
        goto LAB_10012fd4;
      }
LAB_10012fd8:
      if (param_1[local_18 * 0xb + 0x33] != 0.0) {
        param_1[local_18 * 0xb + 0x33] = 0.0;
      }
    }
    local_18 = local_18 + 1 & 0xffff;
  } while (local_18 < 4);
  uVar6 = 0;
  if (*(short *)(param_1 + 0x7e) != 0) {
    do {
      (**(code **)(*(int *)param_1[uVar6 + 0x7b] + 0x40))();
      uVar6 = uVar6 + 1 & 0xffff;
    } while (uVar6 < *(ushort *)(param_1 + 0x7e));
  }
  pbVar4 = (byte *)FUN_10015d30();
  param_1[0x5f] = _DAT_10151f40 * (float)(&DAT_10054550)[*pbVar4] + _DAT_10151f30;
  if (iVar8 == 1) {
    iVar8 = 0;
    if (*(char *)(param_1 + 0x71) != '\0') {
      do {
        cVar1 = FUN_10010350();
        if (cVar1 == '\b') {
          fVar5 = param_1[iVar8 + 99];
          if (fVar5 != 0.0) goto LAB_1001315f;
          break;
        }
        iVar8 = (iVar8 + 1) * 0x10000 >> 0x10;
      } while (iVar8 < (int)(uint)*(byte *)(param_1 + 0x71));
    }
    fVar5 = 0.0;
LAB_1001315f:
    fVar5 = (float)__RTDynamicCast(fVar5,0,&CDevice::RTTI_Type_Descriptor,
                                   &CInsertEffect::RTTI_Type_Descriptor,0);
    param_1[0x61] = fVar5;
  }
  else if (param_1[0x61] != 0.0) {
    param_1[0x61] = 0.0;
  }
  if ((int)*param_1 < 0x3f800001) {
    pbVar4[0xc] = (byte)(longlong)ROUND(*param_1 * _DAT_10151f3c);
  }
  else {
    *param_1 = 1.0;
    pbVar4[0xc] = 0x7f;
  }
  if ((int)param_1[1] < 0x3f800001) {
    pbVar4[0xd] = (byte)(longlong)ROUND(param_1[1] * _DAT_10151f3c);
  }
  else {
    param_1[1] = 1.0;
    pbVar4[0xd] = 0x7f;
  }
  fVar5 = _DAT_10151f38 * param_1[1];
  *param_1 = *param_1 * _DAT_10151f38;
  param_1[1] = fVar5;
  return;
}



void __thiscall FUN_10013240(int param_1,int param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  
  iVar7 = *(int *)(param_2 + 0x944);
  cVar2 = FUN_10009450();
  if (cVar2 != '\0') {
    iVar5 = 0;
    do {
      if (*(char *)(param_2 + 0x804 + iVar5) == '\0') {
        (&DAT_100deec0)[iVar5] = 0;
        (&DAT_100def08)[iVar5] = 0;
        *(undefined1 *)(param_2 + 0x1188 + iVar5) = 0;
      }
      else {
        (&DAT_100def08)[iVar5] = *(undefined4 *)(param_2 + 0x844 + iVar5 * 4);
        (&DAT_100deec0)[iVar5] = param_1 + 0x20c + iVar5 * 0x100;
        *(undefined1 *)(param_2 + 0x1188 + iVar5) = 1;
      }
      iVar5 = (iVar5 + 1) * 0x10000 >> 0x10;
    } while (iVar5 < 0x12);
    if (0 < *(int *)(param_1 + 0x208)) {
      iVar5 = *(int *)(param_1 + 0x208);
      iVar4 = 0;
      iVar8 = 0x40 - iVar5;
      do {
        iVar6 = (&DAT_100def08)[iVar4];
        if (iVar6 != 0) {
          iVar1 = (&DAT_100deec0)[iVar4] + *(int *)(param_1 + 0x208) * 4;
          iVar3 = 0;
          if (0 < iVar8) {
            do {
              *(undefined4 *)(iVar6 + iVar3 * 4) = *(undefined4 *)(iVar1 + iVar3 * 4);
              *(undefined4 *)(iVar1 + iVar3 * 4) = 0x358637bd;
              iVar3 = iVar3 + 1;
            } while (iVar3 < iVar8);
            iVar6 = (&DAT_100def08)[iVar4];
          }
          (&DAT_100def08)[iVar4] = iVar6 + iVar5 * -4 + 0x100;
        }
        iVar4 = (iVar4 + 1) * 0x10000 >> 0x10;
      } while (iVar4 < 0x12);
      iVar7 = iVar7 - iVar8;
    }
    for (; 0 < iVar7; iVar7 = iVar7 + -0x40) {
      if (iVar7 < 0x40) {
        FUN_10013444(&DAT_100deec0);
        break;
      }
      FUN_10013444(&DAT_100def08);
      iVar5 = 0;
      do {
        if ((&DAT_100def08)[iVar5] != 0) {
          (&DAT_100def08)[iVar5] = (&DAT_100def08)[iVar5] + 0x100;
        }
        iVar5 = (iVar5 + 1) * 0x10000 >> 0x10;
      } while (iVar5 < 0x12);
    }
    *(int *)(param_1 + 0x208) = iVar7;
    if (0 < iVar7) {
      iVar7 = 0;
      do {
        iVar5 = (&DAT_100def08)[iVar7];
        if (iVar5 != 0) {
          iVar8 = 0;
          iVar4 = (&DAT_100deec0)[iVar7];
          if (0 < *(int *)(param_1 + 0x208)) {
            do {
              *(undefined4 *)(iVar5 + iVar8 * 4) = *(undefined4 *)(iVar4 + iVar8 * 4);
              *(undefined4 *)(iVar4 + iVar8 * 4) = 0x358637bd;
              iVar8 = iVar8 + 1;
            } while (iVar8 < *(int *)(param_1 + 0x208));
          }
        }
        iVar7 = (iVar7 + 1) * 0x10000 >> 0x10;
      } while (iVar7 < 0x12);
    }
    FUN_100094a0();
  }
  return;
}



// WARNING: Removing unreachable block (ram,0x100139d0)
// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void __thiscall FUN_10013444(float *param_1,undefined4 *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  undefined4 *puVar8;
  float *pfVar9;
  short sVar10;
  float *pfVar11;
  uint uVar12;
  uint uVar13;
  float *pfVar14;
  bool bVar15;
  float10 fVar16;
  float10 fVar17;
  float10 fVar18;
  float10 fVar19;
  float10 fVar20;
  undefined4 *local_60 [5];
  double dStack_4c;
  double local_44;
  float *local_3c;
  float *local_38;
  float *pfStack_34;
  uint local_30;
  uint uStack_2c;
  double dStack_24;
  double dStack_1c;
  
  if (((uint)param_1[0x62] & 0xf) == 0) {
    FUN_10012c14();
  }
  param_1[0x62] = (float)((int)param_1[0x62] + 1);
  FUN_1001ef20();
  *(ushort *)(param_1 + 0x28) = *(short *)(param_1 + 0x28) + 0x17U & 0x3f;
  local_38 = (float *)*param_2;
  if (local_38 == (float *)0x0) {
    local_38 = param_1 + 0x503;
  }
  else {
    pfVar14 = local_38;
    sVar10 = 0xf;
    do {
      *pfVar14 = 1e-06;
      pfVar14[1] = 1e-06;
      pfVar14[2] = 1e-06;
      pfVar14[3] = 1e-06;
      bVar15 = sVar10 != 0;
      pfVar14 = pfVar14 + 4;
      sVar10 = sVar10 + -1;
    } while (bVar15);
  }
  local_3c = (float *)param_2[1];
  if (local_3c == (float *)0x0) {
    local_3c = param_1 + 0x543;
  }
  else {
    pfVar14 = local_3c;
    sVar10 = 0xf;
    do {
      *pfVar14 = 1e-06;
      pfVar14[1] = 1e-06;
      pfVar14[2] = 1e-06;
      pfVar14[3] = 1e-06;
      bVar15 = sVar10 != 0;
      pfVar14 = pfVar14 + 4;
      sVar10 = sVar10 + -1;
    } while (bVar15);
  }
  local_60[0] = param_2 + 2;
  local_60[1] = param_2 + 3;
  local_60[2] = param_2 + 4;
  local_60[3] = param_2 + 0xb;
  local_30 = 0;
  if (*(char *)(param_1 + 0x76) != '\0') {
    uVar13 = 0;
    do {
      uVar12 = uVar13;
      puVar8 = local_60[uVar12];
      pfVar14 = (float *)*puVar8;
      local_44 = (double)CONCAT44(local_44._4_4_,pfVar14);
      if (pfVar14 == (float *)0x0) {
        *puVar8 = &DAT_1010012c;
        (**(code **)(*(int *)param_1[uVar12 + 0x72] + 0x38))(puVar8);
        pfVar14 = (float *)&DAT_1010012c;
        *local_60[uVar12] = local_44._0_4_;
      }
      else {
        (**(code **)(*(int *)param_1[uVar12 + 0x72] + 0x38))(puVar8);
      }
      if ((int *)param_1[uVar12 * 0xb + 0x31] != (int *)0x0) {
        (**(code **)(*(int *)param_1[uVar12 * 0xb + 0x31] + 0x3c))(pfVar14);
      }
      if ((int *)param_1[uVar12 * 0xb + 0x32] != (int *)0x0) {
        (**(code **)(*(int *)param_1[uVar12 * 0xb + 0x32] + 0x3c))(pfVar14);
      }
      if ((int *)param_1[uVar12 * 0xb + 0x33] != (int *)0x0) {
        (**(code **)(*(int *)param_1[uVar12 * 0xb + 0x33] + 0x3c))(pfVar14);
      }
      fVar1 = pfVar14[*(ushort *)(param_1 + 0x28)];
      if (0x80000000 < (uint)pfVar14[*(ushort *)(param_1 + 0x28)]) {
        fVar1 = -fVar1;
      }
      if (param_1[uVar12 * 0xb + 0x2e] < fVar1) {
        param_1[uVar12 * 0xb + 0x2e] = fVar1;
      }
      fVar1 = param_1[uVar12 * 0xb + 0x2d];
      local_30 = uVar12;
      pfStack_34 = pfVar14;
      pfVar9 = (float *)param_1[uVar12 * 0xb + 0x2f];
      pfVar11 = pfVar14;
      sVar10 = 0xf;
      while( true ) {
        fVar2 = pfVar11[3];
        fVar3 = pfVar11[2];
        fVar4 = pfVar11[1];
        *pfVar9 = *pfVar11 * fVar1 + *pfVar9;
        fVar4 = fVar4 * fVar1 + pfVar9[1];
        fVar2 = fVar2 * fVar1 + pfVar9[3];
        pfVar9[2] = fVar3 * fVar1 + pfVar9[2];
        pfVar11 = pfVar11 + 4;
        if (sVar10 == 0) break;
        pfVar9[3] = fVar2;
        pfVar9[1] = fVar4;
        pfVar9 = pfVar9 + 4;
        sVar10 = sVar10 + -1;
      }
      pfVar9[3] = fVar2;
      pfVar9[1] = fVar4;
      if (pfVar14 == (float *)&DAT_1010012c) {
        fVar16 = (float10)param_1[uVar12 * 0xb + 0x2c];
        fVar17 = (float10)param_1[uVar12 * 0xb + 0x2b];
        fVar19 = (float10)_DAT_10151f48;
        fVar20 = (float10)param_1[uVar12 * 0xb + 0x2a] * (float10)_DAT_10151f50 +
                 fVar16 * (float10)_DAT_10151f48;
        fVar18 = (float10)_DAT_10151f50;
        param_1[uVar12 * 0xb + 0x2c] = (float)fVar20;
        fVar19 = fVar18 * (float10)param_1[uVar12 * 0xb + 0x29] + fVar17 * fVar19;
        dStack_4c = (double)((fVar20 - fVar16) * (float10)_DAT_10151f58);
        param_1[uVar12 * 0xb + 0x2b] = (float)fVar19;
        local_44 = (double)((fVar19 - fVar17) * (float10)_DAT_10151f58);
        pfVar14 = (float *)&DAT_1010012c;
        pfVar9 = local_3c;
        pfVar11 = local_38;
        uVar13 = 0xf;
        do {
          fVar19 = fVar16 + (float10)dStack_4c;
          fVar1 = pfVar14[2];
          fVar2 = *pfVar14;
          fVar3 = pfVar14[1];
          fVar18 = fVar17 + (float10)local_44;
          fVar4 = pfVar14[2];
          uStack_2c = uVar13;
          dStack_24 = (double)(fVar19 + (float10)dStack_4c);
          fVar5 = pfVar14[3];
          dStack_1c = (double)(fVar18 + (float10)local_44);
          fVar6 = pfVar14[1];
          fVar7 = *pfVar14;
          pfVar11[3] = (float)((float10)pfVar14[3] * fVar19 + (float10)pfVar11[3]);
          pfVar11[2] = (float)((float10)fVar1 * fVar19 + (float10)pfVar11[2]);
          pfVar11[1] = (float)((float10)fVar6 * fVar16 + (float10)pfVar11[1]);
          pfVar14 = pfVar14 + 4;
          *pfVar11 = (float)(fVar16 * (float10)fVar7 + (float10)*pfVar11);
          pfVar9[3] = (float)((float10)fVar5 * fVar18 + (float10)pfVar9[3]);
          pfVar9[2] = (float)((float10)fVar4 * fVar18 + (float10)pfVar9[2]);
          *pfVar9 = (float)((float10)fVar2 * fVar17 + (float10)*pfVar9);
          pfVar9[1] = (float)((float10)fVar3 * fVar17 + (float10)pfVar9[1]);
          pfVar11 = pfVar11 + 4;
          pfVar9 = pfVar9 + 4;
          fVar17 = (float10)(double)(fVar18 + (float10)local_44);
          fVar16 = (float10)(double)(fVar19 + (float10)dStack_4c);
          bVar15 = uVar13 != 0;
          uVar13 = uVar13 - 1 & 0xffff;
        } while (bVar15);
      }
      uVar13 = uVar12 + 1 & 0xffff;
    } while (uVar13 < *(byte *)(param_1 + 0x76));
  }
  pfVar9 = local_38;
  pfVar14 = local_3c;
  local_30 = 0;
  if (*(short *)(param_1 + 0x7a) != 0) {
    uVar13 = 0;
    do {
      (**(code **)(*(int *)param_1[uVar13 + 0x77] + 0x38))(param_1[uVar13 + 0x7f],pfVar9,pfVar14);
      uVar13 = uVar13 + 1 & 0xffff;
    } while (uVar13 < *(ushort *)(param_1 + 0x7a));
  }
  local_3c = pfVar14;
  local_38 = pfVar9;
  if (param_1[0x61] != 0.0) {
    (**(code **)(*(int *)param_1[0x61] + 0x38))(pfVar9,pfVar14);
  }
  fVar1 = param_1[0x5f] * (float)_DAT_10151f50 + param_1[0x60] * (float)_DAT_10151f48;
  param_1[0x60] = fVar1;
  pfVar14 = local_38;
  sVar10 = 0xf;
  while( true ) {
    *pfVar14 = *pfVar14 * fVar1;
    pfVar14[1] = pfVar14[1] * fVar1;
    pfVar14[2] = pfVar14[2] * fVar1;
    if (sVar10 == 0) break;
    pfVar14[3] = pfVar14[3] * fVar1;
    pfVar14 = pfVar14 + 4;
    sVar10 = sVar10 + -1;
  }
  pfVar14[3] = pfVar14[3] * fVar1;
  pfVar14 = local_3c;
  sVar10 = 0xf;
  while( true ) {
    *pfVar14 = *pfVar14 * fVar1;
    pfVar14[1] = pfVar14[1] * fVar1;
    pfVar14[2] = pfVar14[2] * fVar1;
    if (sVar10 == 0) break;
    pfVar14[3] = pfVar14[3] * fVar1;
    pfVar14 = pfVar14 + 4;
    sVar10 = sVar10 + -1;
  }
  pfVar14[3] = pfVar14[3] * fVar1;
  fVar1 = local_38[*(ushort *)(param_1 + 0x28)];
  if (0x80000000 < (uint)local_38[*(ushort *)(param_1 + 0x28)]) {
    fVar1 = -fVar1;
  }
  if (*param_1 < fVar1) {
    *param_1 = fVar1;
  }
  fVar1 = local_3c[*(ushort *)(param_1 + 0x28)];
  if (0x80000000 < (uint)local_3c[*(ushort *)(param_1 + 0x28)]) {
    fVar1 = -fVar1;
  }
  if (param_1[1] < fVar1) {
    param_1[1] = fVar1;
  }
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void __thiscall FUN_100139e0(int param_1,int param_2,uint param_3)

{
  int iVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  char cVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  float *pfVar12;
  uint uVar13;
  int iVar14;
  float *pfVar15;
  uint uVar16;
  uint local_20;
  
  local_20 = param_3;
  if (0x4000 < (int)param_3) {
    local_20 = 0x4000;
  }
  DAT_100df894 = local_20;
  DAT_100df754 = 1;
  DAT_100df755 = 1;
  uVar13 = 2;
  do {
    (&DAT_100df754)[uVar13] = 0;
    uVar16 = DAT_100df894;
    uVar13 = uVar13 + 1 & 0xffff;
  } while (uVar13 < 0x12);
  DAT_100df794 = &DAT_100e012c;
  _DAT_100df798 = &DAT_100f012c;
  cVar7 = FUN_10009450();
  if (cVar7 != '\0') {
    iVar14 = 0;
    do {
      if ((&DAT_100df754)[iVar14] == '\0') {
        (&DAT_100def08)[iVar14] = 0;
        (&DAT_100deec0)[iVar14] = 0;
        (&DAT_100e00d8)[iVar14] = 0;
      }
      else {
        (&DAT_100def08)[iVar14] = (&DAT_100df794)[iVar14];
        (&DAT_100e00d8)[iVar14] = 1;
        (&DAT_100deec0)[iVar14] = param_1 + 0x20c + iVar14 * 0x100;
      }
      iVar14 = (iVar14 + 1) * 0x10000 >> 0x10;
    } while (iVar14 < 0x12);
    if (0 < *(int *)(param_1 + 0x208)) {
      iVar14 = *(int *)(param_1 + 0x208);
      iVar11 = 0;
      iVar8 = 0x40 - iVar14;
      do {
        iVar10 = (&DAT_100def08)[iVar11];
        if (iVar10 != 0) {
          iVar1 = (&DAT_100deec0)[iVar11] + *(int *)(param_1 + 0x208) * 4;
          iVar9 = 0;
          if (0 < iVar8) {
            do {
              *(undefined4 *)(iVar10 + iVar9 * 4) = *(undefined4 *)(iVar1 + iVar9 * 4);
              *(undefined4 *)(iVar1 + iVar9 * 4) = 0x358637bd;
              iVar9 = iVar9 + 1;
            } while (iVar9 < iVar8);
            iVar10 = (&DAT_100def08)[iVar11];
          }
          (&DAT_100def08)[iVar11] = iVar10 + iVar14 * -4 + 0x100;
        }
        iVar11 = (iVar11 + 1) * 0x10000 >> 0x10;
      } while (iVar11 < 0x12);
      uVar16 = uVar16 - iVar8;
    }
    for (; 0 < (int)uVar16; uVar16 = uVar16 - 0x40) {
      if ((int)uVar16 < 0x40) {
        FUN_10013444(&DAT_100deec0);
        break;
      }
      FUN_10013444(&DAT_100def08);
      iVar14 = 0;
      do {
        if ((&DAT_100def08)[iVar14] != 0) {
          (&DAT_100def08)[iVar14] = (&DAT_100def08)[iVar14] + 0x100;
        }
        iVar14 = (iVar14 + 1) * 0x10000 >> 0x10;
      } while (iVar14 < 0x12);
    }
    *(uint *)(param_1 + 0x208) = uVar16;
    if (0 < (int)uVar16) {
      iVar14 = 0;
      do {
        iVar8 = (&DAT_100def08)[iVar14];
        if (iVar8 != 0) {
          iVar10 = 0;
          iVar11 = (&DAT_100deec0)[iVar14];
          if (0 < *(int *)(param_1 + 0x208)) {
            do {
              *(undefined4 *)(iVar8 + iVar10 * 4) = *(undefined4 *)(iVar11 + iVar10 * 4);
              *(undefined4 *)(iVar11 + iVar10 * 4) = 0x358637bd;
              iVar10 = iVar10 + 1;
            } while (iVar10 < *(int *)(param_1 + 0x208));
          }
        }
        iVar14 = (iVar14 + 1) * 0x10000 >> 0x10;
      } while (iVar14 < 0x12);
    }
    FUN_100094a0();
  }
  fVar6 = _DAT_10151f7c;
  fVar5 = _DAT_10151f78;
  uVar13 = 0;
  pfVar15 = (float *)&DAT_100e0128;
  pfVar12 = (float *)&DAT_100f0128;
  if (local_20 != 0) {
    fVar3 = (float)_DAT_10151f70;
    iVar14 = param_2 + -2;
    do {
      pfVar15 = pfVar15 + 1;
      pfVar12 = pfVar12 + 1;
      fVar4 = *pfVar15 * fVar3;
      fVar2 = fVar3 * *pfVar12;
      if (fVar5 < fVar4) {
        fVar4 = _DAT_10151f78;
      }
      else if (fVar4 < fVar6) {
        fVar4 = _DAT_10151f7c;
      }
      if (fVar5 < fVar2) {
        fVar2 = _DAT_10151f78;
      }
      else if (fVar2 < fVar6) {
        fVar2 = _DAT_10151f7c;
      }
      uVar13 = uVar13 + 1;
      *(short *)(iVar14 + 4) = (short)(longlong)ROUND(fVar2);
      *(short *)(iVar14 + 2) = (short)(longlong)ROUND(fVar4);
      iVar14 = iVar14 + 4;
    } while (uVar13 < local_20);
  }
  return;
}



void __fastcall FUN_10013d40(int param_1)

{
  int iVar1;
  
  iVar1 = 0;
  if (*(char *)(param_1 + 0x1c4) != '\0') {
    do {
      (**(code **)(**(int **)(param_1 + 0x18c + iVar1 * 4) + 0x18))();
      iVar1 = (iVar1 + 1) * 0x10000 >> 0x10;
    } while (iVar1 < (int)(uint)*(byte *)(param_1 + 0x1c4));
  }
  return;
}



undefined1 __fastcall FUN_10013d80(int param_1)

{
  return *(undefined1 *)(param_1 + 0x1c4);
}



undefined4 __thiscall FUN_10013d90(int param_1,byte param_2)

{
  return *(undefined4 *)(param_1 + 0x18c + (uint)param_2 * 4);
}



int __fastcall FUN_10013da0(int param_1)

{
  return param_1 + 0x158;
}



void __fastcall FUN_10013db0(int param_1)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined1 local_1c;
  undefined1 local_1b [11];
  
  iVar2 = FUN_1001bd10();
  if ((param_1 != iVar2) && (iVar2 = FUN_1001bd00(), param_1 != iVar2)) {
    return;
  }
  uVar4 = 0;
  if (*(char *)(param_1 + 0x1c4) != '\0') {
    do {
      (**(code **)(**(int **)(param_1 + 0x18c + uVar4 * 4) + 0x34))();
      uVar4 = uVar4 + 1 & 0xff;
    } while (uVar4 < *(byte *)(param_1 + 0x1c4));
  }
  local_1c = 8;
  uVar3 = FUN_1001f870();
  FUN_100040e0(local_1b,uVar3);
  FUN_1001d550(*(undefined1 *)(param_1 + 0x178),0x23,&local_1c,5);
  cVar1 = FUN_10007e80();
  if (cVar1 == '\0') {
    uVar3 = *(undefined4 *)(param_1 + 0x15c);
  }
  else {
    uVar3 = FUN_10007e20();
  }
  local_1c = 4;
  FUN_100040e0(local_1b,uVar3);
  FUN_1001d550(*(undefined1 *)(param_1 + 0x178),0x23,&local_1c,5);
  local_1c = 0xc;
  uVar3 = FUN_1001f8c0();
  FUN_100040e0(local_1b,uVar3);
  FUN_1001d550(*(undefined1 *)(param_1 + 0x178),0x23,&local_1c,5);
  local_1c = 0x10;
  uVar3 = FUN_1001f8e0();
  FUN_100040e0(local_1b,uVar3);
  FUN_1001d550(*(undefined1 *)(param_1 + 0x178),0x23,&local_1c,5);
  local_1c = 3;
  local_1b[0] = FUN_100215d0();
  FUN_1001d550(*(undefined1 *)(param_1 + 0x178),0x23,&local_1c,2);
  return;
}



void __thiscall FUN_10013fb0(int param_1,char param_2)

{
  uint uVar1;
  
  if (*(char *)(param_1 + 0x158) != param_2) {
    uVar1 = 0;
    *(char *)(param_1 + 0x158) = param_2;
    if (*(char *)(param_1 + 0x1c4) != '\0') {
      do {
        (**(code **)(**(int **)(param_1 + 0x18c + uVar1 * 4) + 0x24))(param_2);
        uVar1 = uVar1 + 1 & 0xff;
      } while (uVar1 < *(byte *)(param_1 + 0x1c4));
    }
  }
  FUN_1001ddf0();
  return;
}



void __thiscall FUN_10014034(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x18c + (short)(ushort)*(byte *)(param_1 + 0x1c4) * 4) = param_2;
  *(char *)(param_1 + 0x1c4) = *(char *)(param_1 + 0x1c4) + '\x01';
  return;
}



void __thiscall FUN_10014064(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x1c8 + (short)(ushort)*(byte *)(param_1 + 0x1d8) * 4) = param_2;
  *(char *)(param_1 + 0x1d8) = *(char *)(param_1 + 0x1d8) + '\x01';
  FUN_10014034(param_2);
  return;
}



void __thiscall FUN_100140b4(int param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = (int)*(short *)(param_1 + 0x1e8);
  *(undefined4 *)(param_1 + 0x1dc + iVar1 * 4) = param_2;
  *(int *)(param_1 + 0x1fc + iVar1 * 4) = param_1 + 0x160c + iVar1 * 0x100;
  *(short *)(param_1 + 0x1e8) = *(short *)(param_1 + 0x1e8) + 1;
  FUN_10014034(param_2);
  return;
}



void __thiscall FUN_10014104(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x1ec + *(short *)(param_1 + 0x1f8) * 4) = param_2;
  *(short *)(param_1 + 0x1f8) = *(short *)(param_1 + 0x1f8) + 1;
  FUN_10014034(param_2);
  return;
}



void __fastcall FUN_10014140(undefined4 *param_1)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  
  uVar2 = 0;
  param_1[0x60] = 0;
  param_1[1] = 0;
  *param_1 = 0;
  do {
    puVar1 = param_1 + uVar2 * 0x40;
    do {
      puVar1[0x583] = 0x358637bd;
      puVar1 = puVar1 + 1;
    } while ((int)puVar1 < (int)(param_1 + uVar2 * 0x40 + 0x40));
    uVar2 = uVar2 + 1 & 0xffff;
  } while (uVar2 < 3);
  uVar2 = 0;
  do {
    puVar1 = param_1 + uVar2 * 0x40;
    do {
      puVar1[0x83] = 0;
      puVar1 = puVar1 + 1;
    } while (puVar1 < param_1 + uVar2 * 0x40 + 0x40);
    uVar2 = uVar2 + 1 & 0xffff;
  } while (uVar2 < 0x12);
  iVar3 = 0;
  if (*(char *)(param_1 + 0x71) != '\0') {
    do {
      (**(code **)(*(int *)param_1[iVar3 + 99] + 0x14))();
      iVar3 = (iVar3 + 1) * 0x10000 >> 0x10;
    } while (iVar3 < (int)(uint)*(byte *)(param_1 + 0x71));
  }
  return;
}



void __thiscall FUN_100141f0(undefined4 *param_1,uint param_2)

{
  if ((param_2 & 2) == 0) {
    *param_1 = 0;
    if ((param_2 & 1) != 0) {
      FUN_1002dde0(param_1);
      return;
    }
  }
  else {
    FUN_1002e750(param_1,0xc,param_1[-1],&LAB_100142b0);
    if ((param_2 & 1) != 0) {
      FUN_1002dde0(param_1 + -1);
      return;
    }
  }
  return;
}



int __fastcall FUN_10014270(int param_1)

{
  uint uVar1;
  
  uVar1 = 0;
  do {
    *(undefined1 *)(param_1 + uVar1) = 0xff;
    uVar1 = uVar1 + 1 & 0xffff;
  } while (uVar1 < 0x80);
  return param_1;
}



int __fastcall FUN_10014274(int param_1)

{
  uint uVar1;
  
  uVar1 = 0;
  do {
    *(undefined1 *)(param_1 + uVar1) = 0xff;
    uVar1 = uVar1 + 1 & 0xffff;
  } while (uVar1 < 0x80);
  return param_1;
}



undefined4 * __fastcall FUN_10014294(undefined4 *param_1)

{
  *(undefined1 *)((int)param_1 + 0xb) = 0;
  *(undefined1 *)((int)param_1 + 9) = 0;
  *(undefined1 *)(param_1 + 2) = 0;
  param_1[1] = 0;
  *param_1 = 0;
  return param_1;
}



void __fastcall FUN_100142c0(int *param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int *piVar3;
  uint uVar4;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10014390;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  param_1[1] = 0;
  *param_1 = 0;
  FUN_10014294();
  local_8 = 0;
  puVar1 = operator_new(0x124f84);
  *puVar1 = 100000;
  FUN_1002e8a0(puVar1 + 1,0xc,100000,&DAT_10014290,&LAB_100142b0);
  uVar4 = 0;
  *param_1 = (int)(puVar1 + 1);
  param_1[2] = (int)(param_1 + 2);
  piVar3 = param_1 + 2;
  do {
    *(int *)(*param_1 + uVar4) = *piVar3;
    piVar2 = (int *)(*param_1 + uVar4);
    uVar4 = uVar4 + 0xc;
    *piVar3 = (int)piVar2;
    piVar3 = piVar2;
  } while (uVar4 < 1200000);
  param_1[1] = 100000;
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_100143a0(int *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10014420;
  local_10 = ExceptionList;
  local_8 = 0;
  if (*param_1 != 0) {
    ExceptionList = &local_10;
    FUN_100141f0(3);
  }
  *param_1 = 0;
  param_1[2] = 0;
  ExceptionList = local_10;
  return;
}



undefined4 * __thiscall
FUN_10014434(int param_1,undefined4 param_2,undefined1 param_3,undefined1 param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  
  if (*(int *)(param_1 + 4) < 2) {
    return (undefined4 *)0x0;
  }
  puVar1 = *(undefined4 **)(param_1 + 8);
  uVar2 = *puVar1;
  *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + -1;
  *(undefined4 *)(param_1 + 8) = uVar2;
  puVar1[1] = param_2;
  *(undefined1 *)(puVar1 + 2) = param_3;
  *(undefined1 *)((int)puVar1 + 9) = param_4;
  return puVar1;
}



void __thiscall FUN_10014484(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  
  *(undefined4 *)*param_2 = *(undefined4 *)(param_1 + 8);
  uVar1 = *param_2;
  *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 1;
  *(undefined4 *)(param_1 + 8) = uVar1;
  *param_2 = 0;
  return;
}



void __fastcall FUN_100144b0(int param_1)

{
  uint uVar1;
  uint uVar2;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10014540;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10014294();
  *(undefined1 *)(param_1 + 0xc) = 0;
  uVar1 = 0;
  do {
    uVar2 = uVar1 + 1 & 0xffff;
    *(undefined1 *)(param_1 + 0xd + uVar1) = 1;
    uVar1 = uVar2;
  } while (uVar2 < 0x80);
  *(int *)param_1 = param_1;
  *(undefined4 *)(param_1 + 4) = 0x7fffffff;
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_10014550(int *param_1)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = *(int *)(*param_1 + 4);
  while (iVar1 != 0x7fffffff) {
    piVar2 = (int *)*param_1;
    *param_1 = *piVar2;
    *piVar2 = 0;
    iVar1 = DAT_10100230;
    *piVar2 = *(int *)(DAT_10100230 + 8);
    *(int **)(iVar1 + 8) = piVar2;
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    iVar1 = *(int *)(*param_1 + 4);
  }
  *param_1 = 0;
  *(undefined1 *)(param_1 + 3) = 1;
  return;
}



void __thiscall FUN_10014600(int param_1,byte param_2,undefined1 param_3)

{
  *(undefined1 *)(param_1 + 0xd + (uint)param_2) = param_3;
  return;
}



void __thiscall FUN_10014620(int *param_1,int param_2,int *param_3)

{
  int iVar1;
  
  if (param_3 == (int *)0x0) {
    param_3 = param_1;
  }
  else if (param_2 <= param_3[1]) {
    param_3 = param_1;
  }
  iVar1 = *(int *)(*param_3 + 4);
  while (iVar1 < param_2) {
    param_3 = (int *)*param_3;
    iVar1 = *(int *)(*param_3 + 4);
  }
  return;
}



undefined4 __fastcall FUN_10014650(undefined4 param_1)

{
  return param_1;
}



void __fastcall FUN_10014660(int param_1)

{
  *(undefined1 *)(param_1 + 0xc) = 0;
  return;
}



int __fastcall FUN_10014670(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar2 = 0;
  iVar1 = *(int *)(*param_1 + 4);
  while (iVar1 != 0x7fffffff) {
    param_1 = (int *)*param_1;
    iVar2 = iVar2 + 1;
    iVar1 = *(int *)(*param_1 + 4);
  }
  return iVar2;
}



int __thiscall FUN_10014690(int *param_1,int param_2,int param_3)

{
  int iVar1;
  int iVar2;
  
  iVar1 = *(int *)(*param_1 + 4);
  while (iVar1 < param_2) {
    param_1 = (int *)*param_1;
    iVar1 = *(int *)(*param_1 + 4);
  }
  iVar2 = 0;
  iVar1 = *(int *)(*param_1 + 4);
  while (iVar1 < param_3) {
    param_1 = (int *)*param_1;
    iVar2 = iVar2 + 1;
    iVar1 = *(int *)(*param_1 + 4);
  }
  return iVar2;
}



int __thiscall FUN_100146e0(int param_1,int param_2,byte param_3)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = (uint)*(byte *)(param_1 + 0xd + (uint)param_3);
  iVar1 = uVar2 * 0x18;
  return ((int)(param_2 + -1 + uVar2 * 0x18) / iVar1) * iVar1;
}



int __thiscall FUN_100146e4(int param_1,int param_2,byte param_3)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = (uint)*(byte *)(param_1 + 0xd + (uint)param_3);
  iVar1 = uVar2 * 0x18;
  return ((int)(param_2 + -1 + uVar2 * 0x18) / iVar1) * iVar1;
}



int __thiscall FUN_10014720(int param_1,int param_2,byte param_3)

{
  int iVar1;
  
  iVar1 = (uint)*(byte *)(param_1 + 0xd + (uint)param_3) * 0x18;
  return (param_2 / iVar1) * iVar1;
}



int * __thiscall
FUN_10014750(int *param_1,int *param_2,undefined4 param_3,char param_4,undefined1 param_5)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  iVar1 = FUN_100146e4(param_3,param_4);
  if (0xbb4ff < iVar1) {
    return (int *)0x0;
  }
  if ((param_2 != (int *)0x0) && (param_2[1] < iVar1)) {
    param_1 = param_2;
  }
  iVar3 = *(int *)(*param_1 + 4);
  while (iVar3 < iVar1) {
    param_1 = (int *)*param_1;
    iVar3 = *(int *)(*param_1 + 4);
  }
  if (*(int *)(*param_1 + 4) == iVar1) {
    iVar3 = 0;
    piVar2 = param_1;
    do {
      if (iVar3 != 0) break;
      if (*(char *)(*piVar2 + 8) == param_4) {
        iVar3 = *piVar2;
      }
      piVar2 = (int *)*piVar2;
    } while (iVar1 == *(int *)(*piVar2 + 4));
    if (iVar3 != 0) {
      *(undefined1 *)(iVar3 + 9) = param_5;
      return param_1;
    }
  }
  piVar2 = (int *)FUN_10014434(iVar1,param_4,param_5);
  if (piVar2 != (int *)0x0) {
    *piVar2 = *param_1;
    *param_1 = (int)piVar2;
  }
  return param_1;
}



undefined4 __thiscall FUN_10014840(int *param_1,int *param_2,int param_3,char param_4)

{
  int iVar1;
  
  if (param_2 == (int *)0x0) {
    param_2 = param_1;
  }
  else if (param_3 <= param_2[1]) {
    param_2 = param_1;
  }
  iVar1 = *(int *)(*param_2 + 4);
  while (iVar1 < param_3) {
    param_2 = (int *)*param_2;
    iVar1 = *(int *)(*param_2 + 4);
  }
  iVar1 = *(int *)(*param_2 + 4);
  while( true ) {
    if (param_3 != iVar1) {
      return 0;
    }
    if (param_4 == *(char *)(*param_2 + 8)) break;
    param_2 = (int *)*param_2;
    iVar1 = *(int *)(*param_2 + 4);
  }
  return 1;
}



void __thiscall FUN_100148a0(int *param_1,int param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *local_18 [2];
  
  iVar1 = *(int *)(*param_1 + 4);
  piVar2 = param_1;
  while (iVar1 < param_2) {
    piVar2 = (int *)*piVar2;
    iVar1 = *(int *)(*piVar2 + 4);
  }
  if (*(int *)(*piVar2 + 4) < param_3) {
    local_18[0] = (int *)*piVar2;
    do {
      *piVar2 = *local_18[0];
      *local_18[0] = 0;
      FUN_10014484(local_18);
      *(undefined1 *)(param_1 + 3) = 1;
      local_18[0] = (int *)*piVar2;
    } while (local_18[0][1] < param_3);
  }
  return;
}



void __thiscall FUN_10014910(int *param_1,int param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *local_18 [2];
  
  iVar1 = *(int *)(*param_1 + 4);
  piVar2 = param_1;
  while (iVar1 < param_2) {
    piVar2 = (int *)*piVar2;
    iVar1 = *(int *)(*piVar2 + 4);
  }
  iVar1 = *(int *)(*piVar2 + 4);
  do {
    if (param_3 <= iVar1) {
      return;
    }
    while (local_18[0] = (int *)*piVar2, local_18[0][1] == 0) {
      piVar2 = (int *)*piVar2;
      if (param_3 <= *(int *)(*piVar2 + 4)) {
        return;
      }
    }
    *piVar2 = *local_18[0];
    *local_18[0] = 0;
    FUN_10014484(local_18);
    *(undefined1 *)(param_1 + 3) = 1;
    iVar1 = *(int *)(*piVar2 + 4);
  } while( true );
}



void __fastcall FUN_100149a0(int *param_1)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = *(int *)(*param_1 + 4);
  while (iVar1 != 0x7fffffff) {
    piVar2 = (int *)*param_1;
    *param_1 = *piVar2;
    *piVar2 = 0;
    iVar1 = DAT_10100230;
    *piVar2 = *(int *)(DAT_10100230 + 8);
    *(int **)(iVar1 + 8) = piVar2;
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    iVar1 = *(int *)(*param_1 + 4);
  }
  *(undefined1 *)(param_1 + 3) = 1;
  return;
}



void FUN_100149f0(void)

{
  byte bVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  undefined1 auStackY_138 [128];
  char local_a0 [128];
  int *local_20;
  undefined1 local_1c;
  int *local_18;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10014ae0;
  local_10 = ExceptionList;
  local_14 = auStackY_138 + 0x84;
  ExceptionList = &local_10;
  FUN_10014274();
  local_8 = 0;
  if (*(int *)(*local_18 + 4) != 0x7fffffff) {
    local_1c = 1;
    piVar4 = local_18;
    do {
      while( true ) {
        bVar1 = *(byte *)(*piVar4 + 8);
        cVar2 = *(char *)(*piVar4 + 9);
        if (cVar2 == local_a0[bVar1]) break;
        local_a0[bVar1] = cVar2;
        piVar4 = (int *)*piVar4;
        iVar3 = *(int *)(*piVar4 + 4);
joined_r0x10014a87:
        if (iVar3 == 0x7fffffff) {
          ExceptionList = local_10;
          return;
        }
      }
      local_20 = (int *)*piVar4;
      if (local_20[1] == 0) {
        piVar4 = (int *)*piVar4;
        iVar3 = *(int *)(*piVar4 + 4);
        goto joined_r0x10014a87;
      }
      *piVar4 = *local_20;
      *local_20 = 0;
      FUN_10014484(&local_20);
      *(undefined1 *)(local_18 + 3) = local_1c;
    } while (*(int *)(*piVar4 + 4) != 0x7fffffff);
  }
  ExceptionList = local_10;
  return;
}



int __thiscall FUN_10014af0(int *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = 0;
  iVar1 = *(int *)(*param_1 + 4);
  while( true ) {
    if (iVar1 == 0x7fffffff) {
      return 0;
    }
    if (iVar2 == param_2) break;
    param_1 = (int *)*param_1;
    iVar2 = iVar2 + 1;
    iVar1 = *(int *)(*param_1 + 4);
  }
  return *param_1;
}



void __thiscall FUN_10014b30(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 *local_8;
  
  puVar1 = (undefined4 *)*param_2;
  local_8 = (undefined4 *)*puVar1;
  if (local_8[1] == 0) {
    *param_2 = *puVar1;
    return;
  }
  *puVar1 = *local_8;
  *local_8 = 0;
  FUN_10014484(&local_8);
  *(undefined1 *)(param_1 + 0xc) = 1;
  return;
}



void __thiscall FUN_10014b90(int *param_1,int param_2,int param_3,int *param_4)

{
  char cVar1;
  undefined1 uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  int *piVar7;
  
  piVar7 = (int *)0x0;
  iVar3 = *(int *)(*param_1 + 4);
  while (iVar3 < param_2) {
    param_1 = (int *)*param_1;
    iVar3 = *(int *)(*param_1 + 4);
  }
  iVar3 = *(int *)(*param_1 + 4);
  do {
    if (param_3 <= iVar3) {
      return;
    }
    iVar3 = *param_1;
    cVar1 = *(char *)(iVar3 + 8);
    uVar2 = *(undefined1 *)(iVar3 + 9);
    iVar3 = FUN_100146e4(*(int *)(iVar3 + 4) - param_2,cVar1);
    if (iVar3 < 0xbb500) {
      if (piVar7 == (int *)0x0) {
        piVar7 = param_4;
      }
      else if (piVar7[1] < iVar3) {
      }
      else {
        piVar7 = param_4;
      }
      iVar5 = *piVar7;
      if (*(int *)(iVar5 + 4) < iVar3) {
        do {
          piVar7 = (int *)*piVar7;
        } while (*(int *)(*piVar7 + 4) < iVar3);
        iVar5 = *piVar7;
      }
      iVar6 = 0;
      piVar4 = piVar7;
      if (*(int *)(iVar5 + 4) == iVar3) {
        do {
          if (iVar6 != 0) break;
          if (*(char *)(*piVar4 + 8) == cVar1) {
            iVar6 = *piVar4;
          }
          piVar4 = (int *)*piVar4;
        } while (iVar3 == *(int *)(*piVar4 + 4));
        if (iVar6 != 0) {
          *(undefined1 *)(iVar6 + 9) = uVar2;
          goto LAB_10014c99;
        }
      }
      piVar4 = (int *)FUN_10014434(iVar3,cVar1,uVar2);
      if (piVar4 != (int *)0x0) {
        *piVar4 = *piVar7;
        *piVar7 = (int)piVar4;
      }
    }
    else {
      piVar7 = (int *)0x0;
    }
LAB_10014c99:
    param_1 = (int *)*param_1;
    iVar3 = *(int *)(*param_1 + 4);
  } while( true );
}



void __thiscall FUN_10014cc0(int *param_1,int param_2,int *param_3)

{
  char cVar1;
  undefined1 uVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  int *piVar7;
  int iVar8;
  
  piVar7 = (int *)0x0;
  piVar5 = (int *)*param_3;
  piVar3 = param_3;
  do {
    if (param_3 == piVar5) {
      return;
    }
    iVar4 = *piVar3;
    cVar1 = *(char *)(iVar4 + 8);
    uVar2 = *(undefined1 *)(iVar4 + 9);
    iVar4 = FUN_100146e4(param_2 + *(int *)(iVar4 + 4),cVar1);
    if (iVar4 < 0xbb500) {
      if (piVar7 == (int *)0x0) {
        piVar7 = param_1;
      }
      else if (piVar7[1] < iVar4) {
      }
      else {
        piVar7 = param_1;
      }
      iVar6 = *piVar7;
      if (*(int *)(iVar6 + 4) < iVar4) {
        do {
          piVar7 = (int *)*piVar7;
        } while (*(int *)(*piVar7 + 4) < iVar4);
        iVar6 = *piVar7;
      }
      iVar8 = 0;
      piVar5 = piVar7;
      if (*(int *)(iVar6 + 4) == iVar4) {
        do {
          if (iVar8 != 0) break;
          if (*(char *)(*piVar5 + 8) == cVar1) {
            iVar8 = *piVar5;
          }
          piVar5 = (int *)*piVar5;
        } while (iVar4 == *(int *)(*piVar5 + 4));
        if (iVar8 != 0) {
          *(undefined1 *)(iVar8 + 9) = uVar2;
          goto LAB_10014db3;
        }
      }
      piVar5 = (int *)FUN_10014434(iVar4,cVar1,uVar2);
      if (piVar5 != (int *)0x0) {
        *piVar5 = *piVar7;
        *piVar7 = (int)piVar5;
      }
    }
    else {
      piVar7 = (int *)0x0;
    }
LAB_10014db3:
    piVar3 = (int *)*piVar3;
    piVar5 = (int *)*piVar3;
  } while( true );
}



void FUN_10014dd0(int param_1,int param_2,int param_3)

{
  uint uVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  int iVar7;
  undefined1 auStackY_1a0 [128];
  int *local_e8;
  int *local_cc;
  int *local_c8;
  int local_c4 [36];
  uint local_34;
  int *local_30;
  int *local_2c;
  uint local_28;
  uint local_24;
  int *local_20;
  uint local_1c;
  int *local_18;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_100151e0;
  local_10 = ExceptionList;
  local_14 = auStackY_1a0 + 0x8c;
  local_18 = local_c4;
  ExceptionList = &local_10;
  FUN_100144b0();
  iVar3 = *(int *)(*local_30 + 4);
  local_e8 = local_30;
  while (iVar3 < param_1) {
    local_e8 = (int *)*local_e8;
    iVar3 = *(int *)(*local_e8 + 4);
  }
  local_2c = (int *)0x0;
  if (*(int *)(*local_e8 + 4) < param_2) {
    do {
      iVar3 = *(int *)(*local_e8 + 4);
      uVar1 = *(uint *)(*local_e8 + 8);
      local_8 = 1;
      local_c8 = (int *)*local_e8;
      if (local_c8[1] == 0) {
        local_e8 = (int *)*local_e8;
      }
      else {
        *local_e8 = *local_c8;
        *local_c8 = 0;
        FUN_10014484(&local_c8);
        *(undefined1 *)(local_30 + 3) = 1;
      }
      local_34 = uVar1 & 0xff;
      local_28 = uVar1 >> 8 & 0xff;
      iVar3 = FUN_100146e4(iVar3 + param_3,local_34);
      if (iVar3 < 0xbb500) {
        if (local_2c == (int *)0x0) {
          piVar6 = local_c4;
        }
        else if (local_2c[1] < iVar3) {
          piVar6 = local_2c;
        }
        else {
          piVar6 = local_c4;
        }
        iVar5 = *piVar6;
        if (*(int *)(iVar5 + 4) < iVar3) {
          do {
            piVar6 = (int *)*piVar6;
          } while (*(int *)(*piVar6 + 4) < iVar3);
          iVar5 = *piVar6;
        }
        iVar7 = 0;
        piVar4 = piVar6;
        if (*(int *)(iVar5 + 4) == iVar3) {
          do {
            if (iVar7 != 0) break;
            if (*(byte *)(*piVar4 + 8) == local_34) {
              iVar7 = *piVar4;
            }
            piVar4 = (int *)*piVar4;
          } while (iVar3 == *(int *)(*piVar4 + 4));
          if (iVar7 != 0) {
            *(char *)(iVar7 + 9) = (char)local_28;
            goto LAB_10014fb4;
          }
        }
        piVar4 = (int *)FUN_10014434(iVar3,local_34,local_28);
        if (piVar4 != (int *)0x0) {
          *piVar4 = *piVar6;
          *piVar6 = (int)piVar4;
        }
      }
      else {
        piVar6 = (int *)0x0;
      }
LAB_10014fb4:
      local_2c = piVar6;
    } while (*(int *)(*local_e8 + 4) < param_2);
  }
  local_e8 = local_18;
  local_20 = (int *)0x0;
  if (*(int *)(local_c4[0] + 4) != 0x7fffffff) {
    do {
      uVar2 = *(undefined4 *)(*local_e8 + 4);
      uVar1 = *(uint *)(*local_e8 + 8);
      local_8 = 2;
      local_cc = (int *)*local_e8;
      if (local_cc[1] == 0) {
        local_e8 = (int *)*local_e8;
      }
      else {
        *local_e8 = *local_cc;
        *local_cc = 0;
        FUN_10014484(&local_cc);
        *(undefined1 *)(local_30 + 3) = 1;
      }
      local_24 = uVar1 & 0xff;
      local_1c = uVar1 >> 8 & 0xff;
      iVar3 = FUN_100146e4(uVar2,local_24);
      if (iVar3 < 0xbb500) {
        piVar6 = local_30;
        if ((local_20 != (int *)0x0) && (local_20[1] < iVar3)) {
          piVar6 = local_20;
        }
        iVar5 = *piVar6;
        if (*(int *)(iVar5 + 4) < iVar3) {
          do {
            piVar6 = (int *)*piVar6;
          } while (*(int *)(*piVar6 + 4) < iVar3);
          iVar5 = *piVar6;
        }
        iVar7 = 0;
        piVar4 = piVar6;
        if (*(int *)(iVar5 + 4) == iVar3) {
          do {
            if (iVar7 != 0) break;
            if (*(byte *)(*piVar4 + 8) == local_24) {
              iVar7 = *piVar4;
            }
            piVar4 = (int *)*piVar4;
          } while (iVar3 == *(int *)(*piVar4 + 4));
          if (iVar7 != 0) {
            *(char *)(iVar7 + 9) = (char)local_1c;
            goto LAB_1001515b;
          }
        }
        piVar4 = (int *)FUN_10014434(iVar3,local_24,local_1c);
        if (piVar4 != (int *)0x0) {
          *piVar4 = *piVar6;
          *piVar6 = (int)piVar4;
        }
      }
      else {
        piVar6 = (int *)0x0;
      }
LAB_1001515b:
      local_20 = piVar6;
    } while (*(int *)(*local_e8 + 4) != 0x7fffffff);
  }
  local_8 = 0xffffffff;
  FUN_10014550();
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_100151f0(int *param_1,int param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = 0;
  do {
    *(undefined1 *)(param_2 + uVar2) = 0xff;
    uVar2 = uVar2 + 1 & 0xffff;
  } while (uVar2 < 0x80);
  iVar1 = *(int *)(*param_1 + 4);
  while (iVar1 <= param_3) {
    *(undefined1 *)(param_2 + (uint)*(byte *)(*param_1 + 8)) = *(undefined1 *)(*param_1 + 9);
    param_1 = (int *)*param_1;
    iVar1 = *(int *)(*param_1 + 4);
  }
  return;
}



void __thiscall FUN_10015240(int *param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  uint local_20;
  
  piVar5 = (int *)0x0;
  local_20 = 0;
  do {
    cVar1 = *(char *)(param_3 + local_20);
    if (cVar1 != -1) {
      iVar2 = FUN_100146e4(param_2,local_20);
      if (iVar2 < 0xbb500) {
        if (piVar5 == (int *)0x0) {
          piVar5 = param_1;
        }
        else if (piVar5[1] < iVar2) {
        }
        else {
          piVar5 = param_1;
        }
        iVar4 = *piVar5;
        if (*(int *)(iVar4 + 4) < iVar2) {
          do {
            piVar5 = (int *)*piVar5;
          } while (*(int *)(*piVar5 + 4) < iVar2);
          iVar4 = *piVar5;
        }
        iVar6 = 0;
        piVar3 = piVar5;
        if (*(int *)(iVar4 + 4) == iVar2) {
          do {
            if (iVar6 != 0) break;
            if (*(byte *)(*piVar3 + 8) == local_20) {
              iVar6 = *piVar3;
            }
            piVar3 = (int *)*piVar3;
          } while (iVar2 == *(int *)(*piVar3 + 4));
          if (iVar6 != 0) {
            *(char *)(iVar6 + 9) = cVar1;
            goto LAB_10015338;
          }
        }
        piVar3 = (int *)FUN_10014434(iVar2,local_20,cVar1);
        if (piVar3 != (int *)0x0) {
          *piVar3 = *piVar5;
          *piVar5 = (int)piVar3;
        }
      }
      else {
        piVar5 = (int *)0x0;
      }
    }
LAB_10015338:
    local_20 = local_20 + 1 & 0xff;
    if (0x7f < local_20) {
      return;
    }
  } while( true );
}



void FUN_10015390(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_100153f0;
  local_10 = ExceptionList;
  local_8 = 0xffffffff;
  ExceptionList = &local_10;
  FUN_10010340();
  ExceptionList = local_10;
  return;
}



undefined4 * __thiscall FUN_10015400(undefined4 *param_1,undefined4 param_2,undefined1 param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10015510;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10010300(param_2,param_3);
  local_8 = 0;
  *param_1 = &PTR_LAB_10033214;
  FUN_10019cc0();
  iVar2 = 4;
  do {
    FUN_10019d50();
    iVar2 = iVar2 + -1;
  } while (iVar2 != 0);
  FUN_10019cc0();
  iVar2 = 4;
  do {
    FUN_10019d50();
    iVar2 = iVar2 + -1;
  } while (iVar2 != 0);
  uVar3 = 0;
  do {
    uVar1 = uVar3 + 1 & 0xff;
    *(undefined1 *)((int)param_1 + uVar3 + 0x80) = 0;
    uVar3 = uVar1;
  } while (uVar1 < 5);
  uVar3 = 0;
  do {
    uVar1 = 0;
    do {
      iVar2 = uVar1 + uVar3 * 6;
      uVar1 = uVar1 + 1 & 0xff;
      *(undefined1 *)((int)param_1 + iVar2 + 0x85) = 0;
    } while (uVar1 < 6);
    uVar3 = uVar3 + 1 & 0xff;
  } while (uVar3 < 4);
  ExceptionList = local_10;
  return param_1;
}



int __thiscall FUN_10015d10(int param_1,byte param_2)

{
  return (uint)param_2 * 6 + 0x40 + param_1;
}



int __fastcall FUN_10015d30(int param_1)

{
  return param_1 + 0x30;
}



int __fastcall FUN_10016330(int param_1)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  
  uVar3 = 0;
  do {
    uVar2 = 0;
    do {
      iVar1 = uVar2 + uVar3 * 0x800;
      uVar2 = uVar2 + 1 & 0xffff;
      *(undefined1 *)(param_1 + iVar1) = 0;
    } while (uVar2 < 0x800);
    uVar3 = uVar3 + 1 & 0xffff;
  } while (uVar3 < 2);
  return param_1;
}



uint __thiscall FUN_100163d0(int param_1,int param_2,int param_3,ushort param_4)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  
  iVar5 = 0;
  uVar2 = (uint)param_4 * 0x11;
  uVar3 = uVar2 % 0x785 + 0x7b;
  uVar2 = uVar2 / 0x785;
  if (0 < param_3) {
    uVar4 = 0;
    do {
      iVar1 = uVar4 + (param_4 & 1) * 0x800;
      uVar4 = uVar4 + 1 & 0xffff;
      *(char *)(iVar5 + param_2) = *(char *)(param_1 + iVar1) + *(char *)(iVar5 + param_2);
      iVar5 = iVar5 + 1;
      if (uVar4 == uVar3) {
        uVar4 = 0;
      }
      uVar2 = uVar3;
    } while (iVar5 < param_3);
  }
  return uVar2;
}



undefined4 * __thiscall FUN_10016490(undefined4 *param_1,undefined4 param_2,undefined1 param_3)

{
  uint uVar1;
  uint uVar2;
  undefined1 auStack_4a [14];
  char local_3c [32];
  char *local_1c;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_100165d0;
  local_10 = ExceptionList;
  local_14 = auStack_4a + -0x12;
  local_1c = local_3c;
  ExceptionList = &local_10;
  FUN_10010530(param_2,param_3);
  local_8 = 0;
  *param_1 = &PTR_LAB_10033ad4;
  FUN_10019c10();
  FUN_10019c10();
  uVar1 = FUN_10010350();
  sprintf(local_1c,s_CPCFInsert__d_101524c0,uVar1 & 0xff);
  FUN_10010360(local_1c);
  param_1[0x14] = 0;
  param_1[0x18] = 0;
  param_1[0x1d] = 0;
  param_1[0x22] = 0;
  param_1[0x1f] = 0;
  param_1[0x21] = 0;
  param_1[0x20] = 0;
  param_1[0x1e] = 0;
  param_1[0x1c] = 0;
  param_1[0x1b] = 0;
  param_1[0x1a] = 0;
  param_1[0x19] = 0;
  param_1[0x17] = 0;
  param_1[0x16] = 0;
  param_1[0x15] = 0;
  if (DAT_1010026c == '\0') {
    DAT_1010026c = '\x01';
    FUN_100172c4();
    FUN_10017574();
  }
  FUN_100178d0();
  uVar1 = 0;
  do {
    uVar2 = uVar1 + 1 & 0xff;
    *(undefined1 *)((int)param_1 + uVar1 + 0x48) = 0;
    uVar1 = uVar2;
  } while (uVar2 < 8);
  ExceptionList = local_10;
  return param_1;
}



void __fastcall FUN_100165e0(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10016650;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  *param_1 = &PTR_LAB_10033ad4;
  local_8 = 0xffffffff;
  FUN_1000e920();
  ExceptionList = local_10;
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void __fastcall FUN_10016664(int param_1)

{
  if (*(int *)(param_1 + 0x88) < 0x3f800001) {
    *(char *)(param_1 + 0x3f) = (char)(longlong)ROUND(*(float *)(param_1 + 0x88) * _DAT_10152280);
  }
  else {
    *(undefined1 *)(param_1 + 0x3f) = 0x7f;
  }
  *(float *)(param_1 + 0x88) = *(float *)(param_1 + 0x88) * _DAT_1015227c;
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void FUN_100172c4(void)

{
  double dVar1;
  float10 fVar2;
  float10 fVar3;
  float10 fVar4;
  float10 fVar5;
  double dVar6;
  double dVar7;
  double dVar8;
  uint uVar9;
  uint uVar10;
  int iVar11;
  float10 fVar12;
  float10 fVar13;
  float10 fVar14;
  float10 fVar15;
  float10 fVar16;
  float10 fVar17;
  double local_34;
  uint local_24;
  
  fVar12 = (float10)FUN_1002ddf0(0xe0000000,0x3ff03b93,0,0x407ff000);
  fVar3 = (float10)_DAT_10152340;
  local_24 = 0;
  do {
    dVar6 = (double)local_24;
    fVar13 = (float10)FUN_1002ddf0(0x40000000,0x3ffc7ae1,dVar6);
    fVar4 = (float10)_DAT_10152350;
    dVar8 = dVar6 * _DAT_10152358 + _DAT_10152360;
    dVar6 = dVar6 * (double)_DAT_101523c0 * _DAT_10152340 + _DAT_10152368;
    iVar11 = local_24 * 0x1800;
    uVar9 = 0;
    do {
      dVar7 = (double)uVar9;
      fVar14 = (float10)FUN_1002ddf0(0xe0000000,0x3ff03b93,dVar7);
      dVar1 = (double)(fVar14 * (float10)(double)(fVar3 / fVar12) * (float10)dVar6);
      dVar7 = dVar7 * _DAT_10152370 * _DAT_10152378 * dVar7 * _DAT_10152370 * _DAT_10152378 *
              _DAT_10152380 - _DAT_10152388;
      if ((double)_DAT_101523c4 < dVar7) {
        dVar7 = (double)_DAT_101523c4;
      }
      if (dVar7 < (double)_DAT_101523c8) {
        dVar7 = (double)_DAT_101523c8;
      }
      local_34 = (_DAT_10152390 - dVar7) * dVar8 + dVar7 * (double)(fVar13 * fVar4);
      fVar14 = (float10)fcos((float10)dVar1 * (float10)_DAT_10152398);
      fVar16 = (float10)1.4426950408889634 *
               (float10)dVar1 * (float10)_DAT_101523a0 * (float10)(_DAT_10152328 / local_34);
      fVar15 = ROUND(fVar16);
      fVar16 = (float10)f2xm1(-(fVar15 - fVar16));
      fVar16 = (float10)fscale((float10)1 + fVar16,fVar15);
      fVar16 = (float10)(double)fVar14 * (float10)_DAT_101523a8 * fVar16;
      fVar15 = (float10)_DAT_10152390;
      fVar17 = (float10)1.4426950408889634 *
               (float10)dVar1 * (float10)_DAT_101523b0 * (float10)(_DAT_10152328 / local_34);
      fVar14 = ROUND(fVar17);
      fVar17 = (float10)f2xm1(-(fVar14 - fVar17));
      fVar17 = (float10)fscale((float10)1 + fVar17,fVar14);
      fVar14 = (float10)_DAT_101523cc;
      if ((double)_DAT_101523d0 < local_34) {
        local_34 = (double)_DAT_101523d4;
      }
      fVar2 = (float10)_DAT_101523c4;
      fVar5 = (float10)_DAT_101523b8;
      *(float *)(&DAT_1010c274 + uVar9 * 0xc + iVar11) = (float)fVar17;
      *(float *)(&DAT_1010c270 + uVar9 * 0xc + iVar11) = (float)fVar16;
      uVar10 = uVar9 + 1 & 0xffff;
      *(float *)(&DAT_1010c278 + uVar9 * 0xc + iVar11) =
           (float)(((fVar17 + (float10)(double)(fVar15 - fVar16)) * fVar14) /
                  (((float10)local_34 + fVar2) * fVar5));
      uVar9 = uVar10;
    } while (uVar10 < 0x200);
    local_24 = local_24 + 1 & 0xffff;
  } while (local_24 < 8);
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void FUN_10017574(void)

{
  double dVar1;
  float10 fVar2;
  float10 fVar3;
  float10 fVar4;
  float10 fVar5;
  double dVar6;
  double dVar7;
  double dVar8;
  uint uVar9;
  uint uVar10;
  int iVar11;
  float10 fVar12;
  float10 fVar13;
  float10 fVar14;
  float10 fVar15;
  float10 fVar16;
  float10 fVar17;
  float10 fVar18;
  double local_3c;
  uint local_24;
  
  fVar12 = (float10)FUN_1002ddf0(0xe0000000,0x3ff03b93,0,0x407ff000);
  fVar3 = (float10)_DAT_101523f0;
  local_24 = 0;
  do {
    dVar6 = (double)local_24;
    fVar13 = (float10)FUN_1002ddf0(0x40000000,0x3ffc7ae1,dVar6);
    fVar4 = (float10)_DAT_10152400;
    dVar8 = dVar6 * _DAT_10152408 + _DAT_10152410;
    dVar6 = dVar6 * (double)_DAT_10152478 * _DAT_101523f0 + _DAT_10152418;
    iVar11 = local_24 * 0x1800;
    uVar9 = 0;
    do {
      dVar7 = (double)uVar9;
      fVar14 = (float10)FUN_1002ddf0(0xe0000000,0x3ff03b93,dVar7);
      dVar1 = (double)(fVar14 * (float10)(double)(fVar3 / fVar12) * (float10)dVar6);
      dVar7 = dVar7 * _DAT_10152420 * _DAT_10152428 * dVar7 * _DAT_10152420 * _DAT_10152428 *
              _DAT_10152430 - _DAT_10152438;
      if ((double)_DAT_1015247c < dVar7) {
        dVar7 = (double)_DAT_1015247c;
      }
      if (dVar7 < (double)_DAT_10152480) {
        dVar7 = (double)_DAT_10152480;
      }
      local_3c = (_DAT_10152440 - dVar7) * dVar8 + dVar7 * (double)(fVar13 * fVar4);
      fVar14 = (float10)fcos((float10)dVar1 * (float10)_DAT_10152448);
      fVar18 = (float10)1.4426950408889634 *
               (float10)dVar1 * (float10)_DAT_10152450 * (float10)(_DAT_101523d8 / local_3c);
      fVar15 = ROUND(fVar18);
      fVar18 = (float10)f2xm1(-(fVar15 - fVar18));
      fVar15 = (float10)fscale((float10)1 + fVar18,fVar15);
      fVar15 = (float10)(double)fVar14 * (float10)_DAT_10152458 * fVar15;
      fVar18 = (float10)1.4426950408889634 *
               (float10)dVar1 * (float10)_DAT_10152460 * (float10)(_DAT_101523d8 / local_3c);
      fVar14 = ROUND(fVar18);
      fVar18 = (float10)f2xm1(-(fVar14 - fVar18));
      fVar18 = (float10)fscale((float10)1 + fVar18,fVar14);
      fVar16 = (float10)fcos((float10)dVar1 * (float10)_DAT_10152468);
      fVar17 = (float10)_DAT_1015247c;
      fVar14 = (float10)_DAT_10152484;
      if ((double)_DAT_10152488 < local_3c) {
        local_3c = (double)_DAT_10152484;
      }
      fVar2 = (float10)_DAT_1015247c;
      fVar5 = (float10)_DAT_10152470;
      *(float *)(&DAT_10100270 + uVar9 * 0xc + iVar11) = (float)fVar15;
      *(float *)(&DAT_10100274 + uVar9 * 0xc + iVar11) = (float)fVar18;
      uVar10 = uVar9 + 1 & 0xffff;
      *(float *)(&DAT_10100278 + uVar9 * 0xc + iVar11) =
           (float)((SQRT((fVar17 - (float10)(double)fVar15) + (float10)(double)fVar18) * fVar16 *
                   fVar14) / (((float10)local_3c + fVar2) * fVar5));
      uVar9 = uVar10;
    } while (uVar10 < 0x200);
    local_24 = local_24 + 1 & 0xffff;
  } while (local_24 < 8);
  return;
}



void __fastcall FUN_100178d0(int param_1)

{
  *(undefined4 *)(param_1 + 0x74) = 0xffffffff;
  return;
}



void __thiscall FUN_100178e0(undefined4 param_1,uint param_2)

{
  FUN_10009290();
  if ((param_2 & 1) == 0) {
    return;
  }
  FUN_1002dde0(param_1);
  return;
}



undefined4 FUN_10017940(LPCSTR param_1)

{
  HANDLE hObject;
  DWORD DVar1;
  undefined1 local_14 [12];
  
  hObject = CreateFileMappingA((HANDLE)0xffffffff,(LPSECURITY_ATTRIBUTES)0x0,4,0,0x29a,param_1);
  DVar1 = GetLastError();
  if (hObject == (HANDLE)0x0) {
    FUN_100010f0();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_14,(ThrowInfo *)&DAT_10030570);
  }
  CloseHandle(hObject);
  if (DVar1 == 0xb7) {
    return 1;
  }
  return 0;
}



LPCSTR __thiscall FUN_100179e0(char *param_1,undefined4 param_2,char *param_3)

{
  char cVar1;
  void *pvVar2;
  HANDLE pvVar3;
  LPVOID pvVar4;
  int iVar5;
  char *pcVar6;
  undefined4 *puVar7;
  undefined1 auStack_b2 [22];
  char local_9c [72];
  char *local_54;
  undefined1 local_50 [12];
  undefined1 local_44 [12];
  undefined1 local_38 [12];
  undefined1 *local_2c;
  undefined1 *local_28;
  undefined1 *local_24;
  DWORD local_20;
  char *local_1c;
  void *local_18;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10017bc0;
  local_10 = ExceptionList;
  local_14 = auStack_b2 + -0x12;
  local_1c = local_9c;
  ExceptionList = &local_10;
  param_1[0x50] = '\0';
  param_1[0x51] = '\0';
  param_1[0x52] = '\0';
  param_1[0x53] = '\0';
  param_1[0x4c] = '\0';
  param_1[0x4d] = '\0';
  param_1[0x4e] = '\0';
  param_1[0x4f] = '\0';
  param_1[0x48] = '\0';
  param_1[0x49] = '\0';
  param_1[0x4a] = '\0';
  param_1[0x4b] = '\0';
  param_1[0x44] = '\0';
  param_1[0x45] = '\0';
  param_1[0x46] = '\0';
  param_1[0x47] = '\0';
  pcVar6 = param_1;
  do {
    cVar1 = *param_3;
    param_3 = param_3 + 1;
    *pcVar6 = cVar1;
    pcVar6 = pcVar6 + 1;
  } while (cVar1 != '\0');
  local_8 = 0;
  local_54 = param_1;
  sprintf(local_1c,s__s_SEMA_10152640,param_1,param_3);
  local_18 = operator_new(0x28);
  if (local_18 == (void *)0x0) {
    pvVar2 = (void *)0x0;
  }
  else {
    FUN_100091b0(local_1c);
    pvVar2 = local_18;
  }
  *(void **)(local_54 + 0x4c) = pvVar2;
  sprintf(local_1c,s__s_EVENT_10152650,local_54,param_3);
  pvVar3 = CreateEventA((LPSECURITY_ATTRIBUTES)0x0,0,0,local_1c);
  *(HANDLE *)(local_54 + 0x50) = pvVar3;
  if (pvVar3 == (HANDLE)0x0) {
    local_24 = local_50;
    FUN_100010f0();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_24,(ThrowInfo *)&DAT_10030570);
  }
  pvVar3 = CreateFileMappingA((HANDLE)0xffffffff,(LPSECURITY_ATTRIBUTES)0x0,4,0,0x7d10,local_54);
  *(HANDLE *)(local_54 + 0x48) = pvVar3;
  if (pvVar3 == (HANDLE)0x0) {
    local_28 = local_44;
    FUN_100010f0();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_28,(ThrowInfo *)&DAT_10030570);
  }
  local_20 = GetLastError();
  pvVar4 = MapViewOfFile(*(HANDLE *)(local_54 + 0x48),2,0,0,0);
  *(LPVOID *)(local_54 + 0x44) = pvVar4;
  if (pvVar4 == (LPVOID)0x0) {
    local_2c = local_38;
    FUN_100010f0();
                    // WARNING: Subroutine does not return
    _CxxThrowException(local_2c,(ThrowInfo *)&DAT_10030570);
  }
  if (local_20 != 0xb7) {
    puVar7 = *(undefined4 **)(local_54 + 0x44);
    for (iVar5 = 0x1f44; iVar5 != 0; iVar5 = iVar5 + -1) {
      *puVar7 = 0;
      puVar7 = puVar7 + 1;
    }
    *(undefined4 *)(*(int *)(local_54 + 0x44) + 4) = 32000;
  }
  ExceptionList = local_10;
  return local_54;
}



void __fastcall FUN_10017bd4(int param_1)

{
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_100178e0(1);
  }
  *(undefined4 *)(param_1 + 0x4c) = 0;
  if (*(LPCVOID *)(param_1 + 0x44) != (LPCVOID)0x0) {
    UnmapViewOfFile(*(LPCVOID *)(param_1 + 0x44));
    *(undefined4 *)(param_1 + 0x44) = 0;
  }
  if (*(HANDLE *)(param_1 + 0x48) != (HANDLE)0x0) {
    CloseHandle(*(HANDLE *)(param_1 + 0x48));
    *(undefined4 *)(param_1 + 0x48) = 0;
  }
  if (*(HANDLE *)(param_1 + 0x50) != (HANDLE)0x0) {
    CloseHandle(*(HANDLE *)(param_1 + 0x50));
    *(undefined4 *)(param_1 + 0x50) = 0;
  }
  return;
}



undefined4 __thiscall FUN_10017c50(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10017cc0;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_100179e0(param_2,param_3);
  ExceptionList = local_10;
  return param_1;
}



void FUN_10017cd0(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10017d30;
  local_10 = ExceptionList;
  local_8 = 0xffffffff;
  ExceptionList = &local_10;
  FUN_10017bd4();
  ExceptionList = local_10;
  return;
}



uint __thiscall FUN_10017d40(int param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  uVar5 = 0;
  FUN_100092f0();
  piVar1 = *(int **)(param_1 + 0x44);
  if (0 < *piVar1) {
    iVar3 = 0;
    iVar4 = piVar1[2];
    do {
      iVar2 = (iVar4 + 1) % 32000;
      uVar5 = uVar5 | (uint)*(byte *)((int)piVar1 + iVar4 + 0x10) << ((byte)iVar3 & 0x1f);
      iVar3 = iVar3 + 8;
      iVar4 = iVar2;
    } while (iVar3 < 0x10);
    if (param_3 < (int)uVar5) {
      uVar5 = 0;
    }
    else {
      iVar4 = 0;
      piVar1[2] = iVar2;
      if (0 < (int)uVar5) {
        do {
          iVar3 = *(int *)(*(int *)(param_1 + 0x44) + 8);
          *(int *)(*(int *)(param_1 + 0x44) + 8) = iVar3 + 1;
          *(undefined1 *)(iVar4 + param_2) =
               *(undefined1 *)(*(int *)(param_1 + 0x44) + 0x10 + iVar3);
          iVar4 = iVar4 + 1;
          *(uint *)(*(int *)(param_1 + 0x44) + 8) = *(uint *)(*(int *)(param_1 + 0x44) + 8) % 32000;
        } while (iVar4 < (int)uVar5);
      }
      **(int **)(param_1 + 0x44) = **(int **)(param_1 + 0x44) - (uVar5 + 2);
      *(uint *)(*(int *)(param_1 + 0x44) + 4) = *(int *)(*(int *)(param_1 + 0x44) + 4) + 2 + uVar5;
      SetEvent(*(HANDLE *)(param_1 + 0x50));
    }
  }
  FUN_100092c0();
  return uVar5;
}



undefined4 __thiscall FUN_10017e60(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10017ed0;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_100179e0(param_2,param_3);
  ExceptionList = local_10;
  return param_1;
}



void FUN_10017ee0(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10017f40;
  local_10 = ExceptionList;
  local_8 = 0xffffffff;
  ExceptionList = &local_10;
  FUN_10017bd4();
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_10017f50(int param_1,int param_2,int param_3)

{
  int *piVar1;
  DWORD DVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined1 local_24 [12];
  int local_18;
  int local_14;
  
  FUN_100092f0();
  iVar4 = *(int *)(param_1 + 0x44);
  if (*(int *)(iVar4 + 4) < param_3 + 2) {
    do {
      FUN_100092c0();
      DVar2 = WaitForSingleObject(*(HANDLE *)(param_1 + 0x50),4000);
      if (DVar2 == 0x102) {
        FUN_100010f0();
                    // WARNING: Subroutine does not return
        _CxxThrowException(local_24,(ThrowInfo *)&DAT_10030570);
      }
      FUN_100092f0();
      iVar4 = *(int *)(param_1 + 0x44);
    } while (*(int *)(iVar4 + 4) < param_3 + 2);
  }
  iVar5 = 0;
  iVar3 = param_3;
  while( true ) {
    iVar5 = iVar5 + 1;
    *(char *)(iVar4 + 0x10 + *(int *)(iVar4 + 0xc)) = (char)iVar3;
    iVar3 = iVar3 >> 8;
    piVar1 = (int *)(*(int *)(param_1 + 0x44) + 0xc);
    *piVar1 = *piVar1 + 1;
    local_14 = *(int *)(param_1 + 0x44);
    *(uint *)(local_14 + 0xc) = *(uint *)(local_14 + 0xc) % 32000;
    if (1 < iVar5) break;
    iVar4 = *(int *)(param_1 + 0x44);
  }
  iVar4 = 0;
  if (0 < param_3) {
    local_18 = param_2;
    do {
      *(undefined1 *)(*(int *)(param_1 + 0x44) + 0x10 + *(int *)(*(int *)(param_1 + 0x44) + 0xc)) =
           *(undefined1 *)(iVar4 + param_2);
      iVar4 = iVar4 + 1;
      *(int *)(*(int *)(param_1 + 0x44) + 0xc) = *(int *)(*(int *)(param_1 + 0x44) + 0xc) + 1;
      local_14 = *(int *)(param_1 + 0x44);
      *(uint *)(local_14 + 0xc) = *(uint *)(local_14 + 0xc) % 32000;
    } while (iVar4 < param_3);
  }
  **(int **)(param_1 + 0x44) = **(int **)(param_1 + 0x44) + 2 + param_3;
  *(int *)(*(int *)(param_1 + 0x44) + 4) = *(int *)(*(int *)(param_1 + 0x44) + 4) - (param_3 + 2);
  FUN_100092c0();
  return;
}



undefined4 __thiscall FUN_100180a0(int param_1,int param_2)

{
  int iVar1;
  
  FUN_100092f0();
  iVar1 = *(int *)(*(int *)(param_1 + 0x44) + 4);
  FUN_100092c0();
  if (iVar1 < param_2 + 2) {
    return 0;
  }
  return 1;
}



undefined4 * __fastcall FUN_100180e0(undefined4 *param_1)

{
  *param_1 = &PTR_LAB_10033ba4;
  return param_1;
}



void __fastcall FUN_100180f0(undefined4 *param_1)

{
  *param_1 = &PTR_LAB_10033ba4;
  return;
}



undefined4 FUN_10018100(undefined1 param_1,undefined1 *param_2)

{
  *param_2 = param_1;
  return 1;
}



int FUN_10018110(undefined1 param_1,undefined4 *param_2,uint param_3,undefined1 *param_4)

{
  uint uVar1;
  undefined4 *puVar2;
  
  *param_4 = param_1;
  puVar2 = (undefined4 *)(param_4 + 1);
  for (uVar1 = param_3 >> 2; uVar1 != 0; uVar1 = uVar1 - 1) {
    *puVar2 = *param_2;
    param_2 = param_2 + 1;
    puVar2 = puVar2 + 1;
  }
  for (uVar1 = param_3 & 3; uVar1 != 0; uVar1 = uVar1 - 1) {
    *(undefined1 *)puVar2 = *(undefined1 *)param_2;
    param_2 = (undefined4 *)((int)param_2 + 1);
    puVar2 = (undefined4 *)((int)puVar2 + 1);
  }
  return param_3 + 1;
}



int FUN_10018140(undefined1 param_1,undefined1 param_2,undefined4 *param_3,uint param_4,
                undefined1 *param_5)

{
  uint uVar1;
  undefined4 *puVar2;
  
  *param_5 = 0x4e;
  param_5[1] = param_1;
  param_5[2] = param_2;
  puVar2 = (undefined4 *)(param_5 + 3);
  for (uVar1 = param_4 >> 2; uVar1 != 0; uVar1 = uVar1 - 1) {
    *puVar2 = *param_3;
    param_3 = param_3 + 1;
    puVar2 = puVar2 + 1;
  }
  for (uVar1 = param_4 & 3; uVar1 != 0; uVar1 = uVar1 - 1) {
    *(undefined1 *)puVar2 = *(undefined1 *)param_3;
    param_3 = (undefined4 *)((int)param_3 + 1);
    puVar2 = (undefined4 *)((int)puVar2 + 1);
  }
  return param_4 + 3;
}



int FUN_10018180(undefined1 param_1,undefined1 param_2,undefined1 param_3,undefined4 *param_4,
                uint param_5,undefined1 *param_6)

{
  uint uVar1;
  undefined4 *puVar2;
  
  param_6[4] = param_3;
  *param_6 = 0x4e;
  param_6[1] = param_1;
  param_6[2] = 0x29;
  param_6[3] = param_2;
  puVar2 = (undefined4 *)(param_6 + 5);
  for (uVar1 = param_5 >> 2; uVar1 != 0; uVar1 = uVar1 - 1) {
    *puVar2 = *param_4;
    param_4 = param_4 + 1;
    puVar2 = puVar2 + 1;
  }
  for (uVar1 = param_5 & 3; uVar1 != 0; uVar1 = uVar1 - 1) {
    *(undefined1 *)puVar2 = *(undefined1 *)param_4;
    param_4 = (undefined4 *)((int)param_4 + 1);
    puVar2 = (undefined4 *)((int)puVar2 + 1);
  }
  return param_5 + 5;
}



undefined1 * __fastcall FUN_100181d0(undefined1 *param_1)

{
  *(undefined4 *)(param_1 + 4) = 0x3c;
  param_1[8] = 0;
  param_1[1] = 0;
  *param_1 = 0;
  return param_1;
}



void __thiscall FUN_100181f0(undefined1 *param_1,undefined1 *param_2)

{
  *param_2 = *param_1;
  param_2[1] = param_1[1];
  FUN_100040e0(param_2 + 2,*(undefined4 *)(param_1 + 4));
  param_2[6] = param_1[8];
  return;
}



void __thiscall FUN_10018230(undefined1 *param_1,undefined1 *param_2)

{
  undefined4 uVar1;
  
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uVar1 = FUN_100040b0(param_2 + 2);
  *(undefined4 *)(param_1 + 4) = uVar1;
  param_1[8] = param_2[6];
  return;
}



undefined1 * __fastcall FUN_10018274(undefined1 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0x7f;
  *(undefined4 *)(param_1 + 0xc) = 0x29a;
  *(undefined4 *)(param_1 + 8) = 0x29a;
  *(undefined4 *)(param_1 + 4) = 0x29a;
  return param_1;
}



void __thiscall FUN_10018304(undefined1 *param_1,undefined1 *param_2)

{
  undefined4 uVar1;
  
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uVar1 = FUN_100040b0(param_2 + 2);
  *(undefined4 *)(param_1 + 4) = uVar1;
  uVar1 = FUN_100040b0(param_2 + 6);
  *(undefined4 *)(param_1 + 8) = uVar1;
  uVar1 = FUN_100040b0(param_2 + 10);
  *(undefined4 *)(param_1 + 0xc) = uVar1;
  return;
}



undefined2 * __thiscall FUN_100184e0(undefined2 *param_1,undefined2 param_2)

{
  int iVar1;
  undefined2 *puVar2;
  
  puVar2 = param_1 + 6;
  *param_1 = param_2;
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 2) = 0;
  iVar1 = 0x18;
  do {
    *(undefined1 *)puVar2 = 0;
    *(undefined1 *)((int)puVar2 + 1) = 0x7f;
    *(undefined4 *)(puVar2 + 2) = 0x29a;
    *(undefined4 *)(puVar2 + 4) = 0x29a;
    *(undefined4 *)(puVar2 + 6) = 0x29a;
    puVar2 = puVar2 + 8;
    iVar1 = iVar1 + -1;
  } while (iVar1 != 0);
  puVar2 = param_1 + 0xc6;
  iVar1 = 0x15;
  do {
    *(undefined1 *)puVar2 = 0;
    *(undefined1 *)((int)puVar2 + 1) = 0x7f;
    *(undefined4 *)(puVar2 + 2) = 0x29a;
    *(undefined4 *)(puVar2 + 4) = 0x29a;
    *(undefined4 *)(puVar2 + 6) = 0x29a;
    puVar2 = puVar2 + 8;
    iVar1 = iVar1 + -1;
  } while (iVar1 != 0);
  FUN_10018274();
  return param_1;
}



undefined2 * __thiscall FUN_10018560(undefined2 *param_1,undefined4 param_2)

{
  int iVar1;
  undefined2 *puVar2;
  
  *param_1 = 0x29a;
  *(undefined4 *)(param_1 + 2) = 0;
  *(undefined4 *)(param_1 + 4) = 0;
  puVar2 = param_1 + 6;
  iVar1 = 0x18;
  do {
    *(undefined1 *)puVar2 = 0;
    *(undefined1 *)((int)puVar2 + 1) = 0x7f;
    *(undefined4 *)(puVar2 + 2) = 0x29a;
    *(undefined4 *)(puVar2 + 4) = 0x29a;
    *(undefined4 *)(puVar2 + 6) = 0x29a;
    puVar2 = puVar2 + 8;
    iVar1 = iVar1 + -1;
  } while (iVar1 != 0);
  puVar2 = param_1 + 0xc6;
  iVar1 = 0x15;
  do {
    *(undefined1 *)puVar2 = 0;
    *(undefined1 *)((int)puVar2 + 1) = 0x7f;
    *(undefined4 *)(puVar2 + 2) = 0x29a;
    *(undefined4 *)(puVar2 + 4) = 0x29a;
    *(undefined4 *)(puVar2 + 6) = 0x29a;
    puVar2 = puVar2 + 8;
    iVar1 = iVar1 + -1;
  } while (iVar1 != 0);
  FUN_10018274();
  FUN_10018870(param_2);
  return param_1;
}



void __fastcall FUN_100185f0(int param_1)

{
  if (*(undefined4 **)(param_1 + 4) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 4))(1);
  }
  *(undefined4 *)(param_1 + 4) = 0;
  FUN_1002dde0(*(undefined4 *)(param_1 + 8));
  *(undefined4 *)(param_1 + 8) = 0;
  return;
}



void __thiscall FUN_10018870(undefined2 *param_1,int param_2)

{
  int iVar1;
  undefined2 uVar2;
  void *pvVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 *puVar7;
  uint local_28;
  uint local_24;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10018ab0;
  local_10 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_10;
  uVar2 = FUN_10004060(param_2);
  *param_1 = uVar2;
  pvVar3 = operator_new(0x314);
  if (pvVar3 == (void *)0x0) {
    pvVar3 = (void *)0x0;
  }
  else {
    FUN_1000bfc0(param_2 + 2);
  }
  *(void **)(param_1 + 2) = pvVar3;
  puVar4 = operator_new(0x1000);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    FUN_10016330();
  }
  *(undefined4 **)(param_1 + 4) = puVar4;
  puVar7 = (undefined4 *)(param_2 + 0x12c2);
  for (iVar6 = 0x400; iVar6 != 0; iVar6 = iVar6 + -1) {
    *puVar4 = *puVar7;
    puVar7 = puVar7 + 1;
    puVar4 = puVar4 + 1;
  }
  local_28 = 0;
  do {
    iVar1 = local_28 * 0xe;
    iVar6 = param_2 + 0x22c2 + iVar1;
    *(undefined1 *)(param_1 + local_28 * 8 + 6) = *(undefined1 *)(iVar1 + 0x22c2 + param_2);
    *(undefined1 *)((int)param_1 + local_28 * 0x10 + 0xd) =
         *(undefined1 *)(iVar1 + 0x22c3 + param_2);
    uVar5 = FUN_100040b0(iVar6 + 2,puVar4);
    *(undefined4 *)(param_1 + local_28 * 8 + 8) = uVar5;
    uVar5 = FUN_100040b0(iVar6 + 6);
    *(undefined4 *)(param_1 + local_28 * 8 + 10) = uVar5;
    puVar4 = (undefined4 *)(iVar6 + 10);
    uVar5 = FUN_100040b0(puVar4);
    *(undefined4 *)(param_1 + local_28 * 8 + 0xc) = uVar5;
    local_28 = local_28 + 1 & 0xffff;
  } while (local_28 < 0x18);
  local_24 = 0;
  do {
    iVar1 = local_24 * 0xe;
    iVar6 = param_2 + 0x2412 + iVar1;
    *(undefined1 *)(param_1 + local_24 * 8 + 0xc6) = *(undefined1 *)(iVar1 + 0x2412 + param_2);
    *(undefined1 *)((int)param_1 + local_24 * 0x10 + 0x18d) =
         *(undefined1 *)(iVar1 + 0x2413 + param_2);
    uVar5 = FUN_100040b0(iVar6 + 2,puVar4);
    *(undefined4 *)(param_1 + local_24 * 8 + 200) = uVar5;
    uVar5 = FUN_100040b0(iVar6 + 6);
    *(undefined4 *)(param_1 + local_24 * 8 + 0xca) = uVar5;
    puVar4 = (undefined4 *)(iVar6 + 10);
    uVar5 = FUN_100040b0(puVar4);
    *(undefined4 *)(param_1 + local_24 * 8 + 0xcc) = uVar5;
    local_24 = local_24 + 1 & 0xffff;
  } while (local_24 < 0x15);
  FUN_10018304(param_2 + 0x2538);
  ExceptionList = local_10;
  return;
}



undefined1 * __fastcall FUN_10018ac0(undefined1 *param_1)

{
  param_1[0x15] = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  param_1[3] = 0;
  param_1[2] = 0;
  param_1[1] = 0;
  *param_1 = 0;
  *(undefined4 *)(param_1 + 4) = 120000;
  *(undefined4 *)(param_1 + 0x10) = 0x300;
  param_1[0x16] = 1;
  param_1[0x14] = 0x40;
  return param_1;
}



void __thiscall FUN_10018b00(undefined1 *param_1,undefined1 *param_2)

{
  *param_2 = *param_1;
  param_2[1] = param_1[1];
  param_2[2] = param_1[2];
  param_2[3] = param_1[3];
  FUN_100040e0(param_2 + 4,*(undefined4 *)(param_1 + 4));
  FUN_100040e0(param_2 + 8,*(undefined4 *)(param_1 + 8));
  FUN_100040e0(param_2 + 0xc,*(undefined4 *)(param_1 + 0xc));
  FUN_100040e0(param_2 + 0x10,*(undefined4 *)(param_1 + 0x10));
  param_2[0x14] = param_1[0x14];
  param_2[0x15] = param_1[0x15];
  param_2[0x16] = param_1[0x16];
  return;
}



void __thiscall FUN_10018ba0(undefined1 *param_1,undefined1 *param_2)

{
  undefined4 uVar1;
  
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  uVar1 = FUN_100040b0(param_2 + 4);
  *(undefined4 *)(param_1 + 4) = uVar1;
  uVar1 = FUN_100040b0(param_2 + 8);
  *(undefined4 *)(param_1 + 8) = uVar1;
  uVar1 = FUN_100040b0(param_2 + 0xc);
  *(undefined4 *)(param_1 + 0xc) = uVar1;
  uVar1 = FUN_100040b0(param_2 + 0x10);
  *(undefined4 *)(param_1 + 0x10) = uVar1;
  param_1[0x14] = param_2[0x14];
  param_1[0x15] = param_2[0x15];
  param_1[0x16] = param_2[0x16];
  return;
}



undefined1 * __fastcall FUN_10018c20(undefined1 *param_1)

{
  *param_1 = 1;
  param_1[1] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[7] = 0x40;
  param_1[2] = 0x40;
  param_1[5] = 0x14;
  param_1[3] = 0x14;
  param_1[4] = 0x5a;
  param_1[6] = 100;
  return param_1;
}



void __thiscall FUN_10018c60(undefined1 *param_1,undefined1 *param_2)

{
  *param_2 = *param_1;
  param_2[1] = param_1[1];
  param_2[2] = param_1[2];
  param_2[3] = param_1[3];
  param_2[4] = param_1[4];
  param_2[5] = param_1[5];
  param_2[6] = param_1[6];
  param_2[7] = param_1[7];
  param_2[8] = param_1[8];
  param_2[9] = param_1[9];
  param_2[10] = param_1[10];
  param_2[0xb] = param_1[0xb];
  return;
}



void __thiscall FUN_10018c64(undefined1 *param_1,undefined1 *param_2)

{
  *param_2 = *param_1;
  param_2[1] = param_1[1];
  param_2[2] = param_1[2];
  param_2[3] = param_1[3];
  param_2[4] = param_1[4];
  param_2[5] = param_1[5];
  param_2[6] = param_1[6];
  param_2[7] = param_1[7];
  param_2[8] = param_1[8];
  param_2[9] = param_1[9];
  param_2[10] = param_1[10];
  param_2[0xb] = param_1[0xb];
  return;
}



void __thiscall FUN_10018cc4(undefined1 *param_1,undefined1 *param_2)

{
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  param_1[6] = param_2[6];
  param_1[7] = param_2[7];
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  return;
}



undefined1 * __fastcall FUN_10018d20(undefined1 *param_1)

{
  param_1[1] = 0x10;
  *param_1 = 0;
  return param_1;
}



undefined1 * __fastcall FUN_10018d30(undefined1 *param_1)

{
  param_1[5] = 1;
  param_1[4] = 0;
  param_1[3] = 0;
  param_1[2] = 0;
  param_1[1] = 0;
  *param_1 = 0;
  return param_1;
}



void __thiscall FUN_10018d50(undefined1 *param_1,undefined1 *param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = 0;
  *param_2 = *param_1;
  param_2[1] = param_1[1];
  do {
    iVar1 = uVar2 * 6;
    uVar2 = uVar2 + 1 & 0xff;
    param_2[iVar1 + 2] = param_1[iVar1 + 2];
    param_2[iVar1 + 3] = param_1[iVar1 + 3];
    param_2[iVar1 + 4] = param_1[iVar1 + 4];
    param_2[iVar1 + 5] = param_1[iVar1 + 5];
    param_2[iVar1 + 6] = param_1[iVar1 + 6];
    param_2[iVar1 + 7] = param_1[iVar1 + 7];
  } while (uVar2 < 0x10);
  return;
}



void __thiscall FUN_10018dc0(undefined1 *param_1,undefined1 *param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = 0;
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  do {
    iVar1 = uVar3 * 6;
    iVar2 = uVar3 * 6;
    uVar3 = uVar3 + 1 & 0xff;
    param_1[iVar2 + 2] = param_2[iVar1 + 2];
    param_1[iVar2 + 3] = param_2[iVar1 + 3];
    param_1[iVar2 + 4] = param_2[iVar1 + 4];
    param_1[iVar2 + 5] = param_2[iVar1 + 5];
    param_1[iVar2 + 6] = param_2[iVar1 + 6];
    param_1[iVar2 + 7] = param_2[iVar1 + 7];
  } while (uVar3 < 0x10);
  return;
}



void __thiscall FUN_10018e30(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  
  FUN_10018c64(param_2);
  uVar4 = 0;
  do {
    iVar1 = uVar4 * 0x62;
    uVar5 = 0;
    *(undefined1 *)(iVar1 + 0xc + param_2) = *(undefined1 *)(param_1 + 0xc + uVar4 * 0x62);
    *(undefined1 *)(iVar1 + 0xd + param_2) = *(undefined1 *)(param_1 + 0xd + uVar4 * 0x62);
    iVar1 = param_2 + 0xc + iVar1;
    iVar2 = param_1 + 0xc + uVar4 * 0x62;
    do {
      iVar3 = uVar5 * 6;
      uVar5 = uVar5 + 1 & 0xff;
      *(undefined1 *)(iVar3 + 2 + iVar1) = *(undefined1 *)(iVar2 + 2 + iVar3);
      *(undefined1 *)(iVar3 + 3 + iVar1) = *(undefined1 *)(iVar2 + 3 + iVar3);
      *(undefined1 *)(iVar3 + 4 + iVar1) = *(undefined1 *)(iVar2 + 4 + iVar3);
      *(undefined1 *)(iVar3 + 5 + iVar1) = *(undefined1 *)(iVar2 + 5 + iVar3);
      *(undefined1 *)(iVar3 + 6 + iVar1) = *(undefined1 *)(iVar2 + 6 + iVar3);
      *(undefined1 *)(iVar3 + 7 + iVar1) = *(undefined1 *)(iVar2 + 7 + iVar3);
    } while (uVar5 < 0x10);
    uVar4 = uVar4 + 1 & 0xff;
  } while (uVar4 < 0x20);
  return;
}



void __thiscall FUN_10018ef0(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  
  FUN_10018cc4(param_2);
  uVar5 = 0;
  do {
    iVar2 = uVar5 * 0x62;
    iVar1 = param_2 + 0xc + iVar2;
    *(undefined1 *)(param_1 + 0xc + uVar5 * 0x62) = *(undefined1 *)(iVar2 + 0xc + param_2);
    *(undefined1 *)(param_1 + 0xd + uVar5 * 0x62) = *(undefined1 *)(iVar2 + 0xd + param_2);
    iVar2 = param_1 + 0xc + uVar5 * 0x62;
    uVar6 = 0;
    do {
      iVar3 = uVar6 * 6;
      iVar4 = uVar6 * 6;
      uVar6 = uVar6 + 1 & 0xff;
      *(undefined1 *)(iVar4 + 2 + iVar2) = *(undefined1 *)(iVar3 + 2 + iVar1);
      *(undefined1 *)(iVar4 + 3 + iVar2) = *(undefined1 *)(iVar3 + 3 + iVar1);
      *(undefined1 *)(iVar4 + 4 + iVar2) = *(undefined1 *)(iVar3 + 4 + iVar1);
      *(undefined1 *)(iVar4 + 5 + iVar2) = *(undefined1 *)(iVar3 + 5 + iVar1);
      *(undefined1 *)(iVar4 + 6 + iVar2) = *(undefined1 *)(iVar3 + 6 + iVar1);
      *(undefined1 *)(iVar4 + 7 + iVar2) = *(undefined1 *)(iVar3 + 7 + iVar1);
    } while (uVar6 < 0x10);
    uVar5 = uVar5 + 1 & 0xff;
  } while (uVar5 < 0x20);
  return;
}



undefined1 * __fastcall FUN_10018fb0(undefined1 *param_1)

{
  *param_1 = 1;
  param_1[1] = 0;
  param_1[0xb] = 0;
  param_1[0xe] = 0;
  param_1[0x11] = 0;
  param_1[0x13] = 0;
  param_1[0x15] = 0;
  param_1[0x18] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[2] = 0x28;
  param_1[0x1c] = 100;
  param_1[0x1b] = 100;
  param_1[0x1a] = 100;
  param_1[0x19] = 100;
  param_1[0x17] = 100;
  param_1[0x16] = 100;
  param_1[0x14] = 100;
  param_1[0x12] = 100;
  param_1[0xf] = 100;
  param_1[0xc] = 100;
  param_1[9] = 100;
  param_1[6] = 100;
  param_1[3] = 100;
  param_1[4] = 0x40;
  param_1[5] = 0x40;
  param_1[7] = 0x40;
  param_1[8] = 0x40;
  param_1[10] = 0x40;
  param_1[0xd] = 0x40;
  param_1[0x10] = 0x40;
  return param_1;
}



void __thiscall FUN_10019020(undefined1 *param_1,undefined1 *param_2)

{
  *param_2 = *param_1;
  param_2[1] = param_1[1];
  param_2[2] = param_1[2];
  param_2[3] = param_1[3];
  param_2[4] = param_1[4];
  param_2[5] = param_1[5];
  param_2[6] = param_1[6];
  param_2[7] = param_1[7];
  param_2[8] = param_1[8];
  param_2[9] = param_1[9];
  param_2[10] = param_1[10];
  param_2[0xb] = param_1[0xb];
  param_2[0xc] = param_1[0xc];
  param_2[0xd] = param_1[0xd];
  param_2[0xe] = param_1[0xe];
  param_2[0xf] = param_1[0xf];
  param_2[0x10] = param_1[0x10];
  param_2[0x11] = param_1[0x11];
  param_2[0x12] = param_1[0x12];
  param_2[0x13] = param_1[0x13];
  param_2[0x14] = param_1[0x14];
  param_2[0x15] = param_1[0x15];
  param_2[0x16] = param_1[0x16];
  param_2[0x17] = param_1[0x17];
  param_2[0x18] = param_1[0x18];
  param_2[0x19] = param_1[0x19];
  param_2[0x1a] = param_1[0x1a];
  param_2[0x1b] = param_1[0x1b];
  param_2[0x1c] = param_1[0x1c];
  param_2[0x1d] = param_1[0x1d];
  param_2[0x1e] = param_1[0x1e];
  param_2[0x1f] = param_1[0x1f];
  return;
}



void __thiscall FUN_10019024(undefined1 *param_1,undefined1 *param_2)

{
  *param_2 = *param_1;
  param_2[1] = param_1[1];
  param_2[2] = param_1[2];
  param_2[3] = param_1[3];
  param_2[4] = param_1[4];
  param_2[5] = param_1[5];
  param_2[6] = param_1[6];
  param_2[7] = param_1[7];
  param_2[8] = param_1[8];
  param_2[9] = param_1[9];
  param_2[10] = param_1[10];
  param_2[0xb] = param_1[0xb];
  param_2[0xc] = param_1[0xc];
  param_2[0xd] = param_1[0xd];
  param_2[0xe] = param_1[0xe];
  param_2[0xf] = param_1[0xf];
  param_2[0x10] = param_1[0x10];
  param_2[0x11] = param_1[0x11];
  param_2[0x12] = param_1[0x12];
  param_2[0x13] = param_1[0x13];
  param_2[0x14] = param_1[0x14];
  param_2[0x15] = param_1[0x15];
  param_2[0x16] = param_1[0x16];
  param_2[0x17] = param_1[0x17];
  param_2[0x18] = param_1[0x18];
  param_2[0x19] = param_1[0x19];
  param_2[0x1a] = param_1[0x1a];
  param_2[0x1b] = param_1[0x1b];
  param_2[0x1c] = param_1[0x1c];
  param_2[0x1d] = param_1[0x1d];
  param_2[0x1e] = param_1[0x1e];
  param_2[0x1f] = param_1[0x1f];
  return;
}



void __thiscall FUN_100190f4(undefined1 *param_1,undefined1 *param_2)

{
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  param_1[6] = param_2[6];
  param_1[7] = param_2[7];
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  param_1[0xc] = param_2[0xc];
  param_1[0xd] = param_2[0xd];
  param_1[0xe] = param_2[0xe];
  param_1[0xf] = param_2[0xf];
  param_1[0x10] = param_2[0x10];
  param_1[0x11] = param_2[0x11];
  param_1[0x12] = param_2[0x12];
  param_1[0x13] = param_2[0x13];
  param_1[0x14] = param_2[0x14];
  param_1[0x15] = param_2[0x15];
  param_1[0x16] = param_2[0x16];
  param_1[0x17] = param_2[0x17];
  param_1[0x18] = param_2[0x18];
  param_1[0x19] = param_2[0x19];
  param_1[0x1a] = param_2[0x1a];
  param_1[0x1b] = param_2[0x1b];
  param_1[0x1c] = param_2[0x1c];
  param_1[0x1d] = param_2[0x1d];
  param_1[0x1e] = param_2[0x1e];
  param_1[0x1f] = param_2[0x1f];
  return;
}



void __thiscall FUN_100191c0(undefined1 *param_1,undefined1 *param_2)

{
  *param_2 = *param_1;
  param_2[1] = param_1[1];
  return;
}



void __thiscall FUN_100191e0(undefined1 *param_1,undefined1 *param_2)

{
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  return;
}



void __thiscall FUN_10019200(undefined1 *param_1,undefined1 *param_2)

{
  int iVar1;
  uint uVar2;
  uint local_10;
  
  local_10 = 0;
  *param_2 = *param_1;
  param_2[1] = param_1[1];
  do {
    uVar2 = local_10 + 1 & 0xff;
    iVar1 = local_10 * 0xc;
    param_2[iVar1 + 2] = param_1[local_10 * 0xc + 2];
    param_2[iVar1 + 3] = param_1[local_10 * 0xc + 3];
    param_2[iVar1 + 4] = param_1[local_10 * 0xc + 4];
    param_2[iVar1 + 5] = param_1[local_10 * 0xc + 5];
    param_2[iVar1 + 6] = param_1[local_10 * 0xc + 6];
    param_2[iVar1 + 7] = param_1[local_10 * 0xc + 7];
    param_2[iVar1 + 8] = param_1[local_10 * 0xc + 8];
    param_2[iVar1 + 9] = param_1[local_10 * 0xc + 9];
    param_2[iVar1 + 10] = param_1[local_10 * 0xc + 10];
    param_2[iVar1 + 0xb] = param_1[local_10 * 0xc + 0xb];
    param_2[iVar1 + 0xc] = param_1[local_10 * 0xc + 0xc];
    param_2[iVar1 + 0xd] = param_1[local_10 * 0xc + 0xd];
    local_10 = uVar2;
  } while (uVar2 < 0x10);
  return;
}



void __thiscall FUN_100192c0(undefined1 *param_1,undefined1 *param_2)

{
  int iVar1;
  uint uVar2;
  uint local_10;
  
  local_10 = 0;
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  do {
    uVar2 = local_10 + 1 & 0xff;
    iVar1 = local_10 * 0xc;
    param_1[local_10 * 0xc + 2] = param_2[iVar1 + 2];
    param_1[local_10 * 0xc + 3] = param_2[iVar1 + 3];
    param_1[local_10 * 0xc + 4] = param_2[iVar1 + 4];
    param_1[local_10 * 0xc + 5] = param_2[iVar1 + 5];
    param_1[local_10 * 0xc + 6] = param_2[iVar1 + 6];
    param_1[local_10 * 0xc + 7] = param_2[iVar1 + 7];
    param_1[local_10 * 0xc + 8] = param_2[iVar1 + 8];
    param_1[local_10 * 0xc + 9] = param_2[iVar1 + 9];
    param_1[local_10 * 0xc + 10] = param_2[iVar1 + 10];
    param_1[local_10 * 0xc + 0xb] = param_2[iVar1 + 0xb];
    param_1[local_10 * 0xc + 0xc] = param_2[iVar1 + 0xc];
    param_1[local_10 * 0xc + 0xd] = param_2[iVar1 + 0xd];
    local_10 = uVar2;
  } while (uVar2 < 0x10);
  return;
}



void __thiscall FUN_10019380(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  uint local_18;
  
  FUN_10019024(param_2);
  uVar3 = 0;
  do {
    *(undefined1 *)(uVar3 * 0xc2 + 0x20 + param_2) = *(undefined1 *)(param_1 + 0x20 + uVar3 * 0xc2);
    *(undefined1 *)(uVar3 * 0xc2 + 0x21 + param_2) = *(undefined1 *)(param_1 + 0x21 + uVar3 * 0xc2);
    iVar5 = param_2 + uVar3 * 0xc2 + 0x20;
    iVar1 = param_1 + 0x20 + uVar3 * 0xc2;
    local_18 = 0;
    do {
      uVar4 = local_18 + 1 & 0xff;
      iVar2 = local_18 * 0xc;
      *(undefined1 *)(iVar2 + 2 + iVar5) = *(undefined1 *)(iVar1 + 2 + local_18 * 0xc);
      *(undefined1 *)(iVar2 + 3 + iVar5) = *(undefined1 *)(iVar1 + 3 + local_18 * 0xc);
      *(undefined1 *)(iVar2 + 4 + iVar5) = *(undefined1 *)(iVar1 + 4 + local_18 * 0xc);
      *(undefined1 *)(iVar2 + 5 + iVar5) = *(undefined1 *)(iVar1 + 5 + local_18 * 0xc);
      *(undefined1 *)(iVar2 + 6 + iVar5) = *(undefined1 *)(iVar1 + 6 + local_18 * 0xc);
      *(undefined1 *)(iVar2 + 7 + iVar5) = *(undefined1 *)(iVar1 + 7 + local_18 * 0xc);
      *(undefined1 *)(iVar2 + 8 + iVar5) = *(undefined1 *)(iVar1 + 8 + local_18 * 0xc);
      *(undefined1 *)(iVar2 + 9 + iVar5) = *(undefined1 *)(iVar1 + 9 + local_18 * 0xc);
      *(undefined1 *)(iVar2 + 10 + iVar5) = *(undefined1 *)(iVar1 + 10 + local_18 * 0xc);
      *(undefined1 *)(iVar2 + 0xb + iVar5) = *(undefined1 *)(iVar1 + 0xb + local_18 * 0xc);
      *(undefined1 *)(iVar2 + 0xc + iVar5) = *(undefined1 *)(iVar1 + 0xc + local_18 * 0xc);
      *(undefined1 *)(iVar2 + 0xd + iVar5) = *(undefined1 *)(iVar1 + 0xd + local_18 * 0xc);
      local_18 = uVar4;
    } while (uVar4 < 0x10);
    uVar3 = uVar3 + 1 & 0xff;
  } while (uVar3 < 0x20);
  return;
}



void __thiscall FUN_10019490(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  uint local_18;
  
  FUN_100190f4(param_2);
  uVar3 = 0;
  do {
    *(undefined1 *)(param_1 + 0x20 + uVar3 * 0xc2) = *(undefined1 *)(uVar3 * 0xc2 + 0x20 + param_2);
    *(undefined1 *)(param_1 + 0x21 + uVar3 * 0xc2) = *(undefined1 *)(uVar3 * 0xc2 + 0x21 + param_2);
    iVar5 = param_2 + uVar3 * 0xc2 + 0x20;
    iVar1 = param_1 + 0x20 + uVar3 * 0xc2;
    local_18 = 0;
    do {
      uVar4 = local_18 + 1 & 0xff;
      iVar2 = local_18 * 0xc;
      *(undefined1 *)(iVar1 + 2 + local_18 * 0xc) = *(undefined1 *)(iVar2 + 2 + iVar5);
      *(undefined1 *)(iVar1 + 3 + local_18 * 0xc) = *(undefined1 *)(iVar2 + 3 + iVar5);
      *(undefined1 *)(iVar1 + 4 + local_18 * 0xc) = *(undefined1 *)(iVar2 + 4 + iVar5);
      *(undefined1 *)(iVar1 + 5 + local_18 * 0xc) = *(undefined1 *)(iVar2 + 5 + iVar5);
      *(undefined1 *)(iVar1 + 6 + local_18 * 0xc) = *(undefined1 *)(iVar2 + 6 + iVar5);
      *(undefined1 *)(iVar1 + 7 + local_18 * 0xc) = *(undefined1 *)(iVar2 + 7 + iVar5);
      *(undefined1 *)(iVar1 + 8 + local_18 * 0xc) = *(undefined1 *)(iVar2 + 8 + iVar5);
      *(undefined1 *)(iVar1 + 9 + local_18 * 0xc) = *(undefined1 *)(iVar2 + 9 + iVar5);
      *(undefined1 *)(iVar1 + 10 + local_18 * 0xc) = *(undefined1 *)(iVar2 + 10 + iVar5);
      *(undefined1 *)(iVar1 + 0xb + local_18 * 0xc) = *(undefined1 *)(iVar2 + 0xb + iVar5);
      *(undefined1 *)(iVar1 + 0xc + local_18 * 0xc) = *(undefined1 *)(iVar2 + 0xc + iVar5);
      *(undefined1 *)(iVar1 + 0xd + local_18 * 0xc) = *(undefined1 *)(iVar2 + 0xd + iVar5);
      local_18 = uVar4;
    } while (uVar4 < 0x10);
    uVar3 = uVar3 + 1 & 0xff;
  } while (uVar3 < 0x20);
  return;
}



undefined1 * __fastcall FUN_100195a0(undefined1 *param_1)

{
  *param_1 = 1;
  param_1[1] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x17] = 0x20;
  param_1[2] = 0x20;
  param_1[0x1b] = 100;
  param_1[0x19] = 100;
  param_1[0x16] = 100;
  param_1[0x15] = 100;
  param_1[0x14] = 100;
  param_1[0x11] = 100;
  param_1[0xe] = 100;
  param_1[0xb] = 100;
  param_1[7] = 100;
  param_1[3] = 100;
  param_1[4] = 0x40;
  param_1[5] = 0x40;
  param_1[8] = 0x40;
  param_1[9] = 0x40;
  param_1[10] = 0x40;
  param_1[0xc] = 0x40;
  param_1[0xf] = 0x40;
  param_1[0x12] = 0x40;
  param_1[0x1a] = 0x40;
  param_1[0x1c] = 0x40;
  param_1[0x1d] = 0x40;
  param_1[0x18] = 0x7f;
  param_1[0x13] = 0x7f;
  param_1[0x10] = 0x7f;
  param_1[0xd] = 0x7f;
  param_1[6] = 0x7f;
  return param_1;
}



void __thiscall FUN_10019620(undefined1 *param_1,undefined1 *param_2)

{
  *param_2 = *param_1;
  param_2[1] = param_1[1];
  param_2[2] = param_1[2];
  param_2[3] = param_1[3];
  param_2[4] = param_1[4];
  param_2[5] = param_1[5];
  param_2[6] = param_1[6];
  param_2[7] = param_1[7];
  param_2[8] = param_1[8];
  param_2[9] = param_1[9];
  param_2[10] = param_1[10];
  param_2[0xb] = param_1[0xb];
  param_2[0xc] = param_1[0xc];
  param_2[0xd] = param_1[0xd];
  param_2[0xe] = param_1[0xe];
  param_2[0xf] = param_1[0xf];
  param_2[0x10] = param_1[0x10];
  param_2[0x11] = param_1[0x11];
  param_2[0x12] = param_1[0x12];
  param_2[0x13] = param_1[0x13];
  param_2[0x14] = param_1[0x15];
  param_2[0x15] = param_1[0x16];
  param_2[0x16] = param_1[0x14];
  param_2[0x17] = param_1[0x17];
  param_2[0x18] = param_1[0x18];
  param_2[0x19] = param_1[0x19];
  param_2[0x1a] = param_1[0x1a];
  param_2[0x1b] = param_1[0x1b];
  param_2[0x1c] = param_1[0x1c];
  param_2[0x1d] = param_1[0x1d];
  param_2[0x1e] = param_1[0x1e];
  param_2[0x1f] = param_1[0x1f];
  param_2[0x20] = param_1[0x20];
  return;
}



void __thiscall FUN_10019624(undefined1 *param_1,undefined1 *param_2)

{
  *param_2 = *param_1;
  param_2[1] = param_1[1];
  param_2[2] = param_1[2];
  param_2[3] = param_1[3];
  param_2[4] = param_1[4];
  param_2[5] = param_1[5];
  param_2[6] = param_1[6];
  param_2[7] = param_1[7];
  param_2[8] = param_1[8];
  param_2[9] = param_1[9];
  param_2[10] = param_1[10];
  param_2[0xb] = param_1[0xb];
  param_2[0xc] = param_1[0xc];
  param_2[0xd] = param_1[0xd];
  param_2[0xe] = param_1[0xe];
  param_2[0xf] = param_1[0xf];
  param_2[0x10] = param_1[0x10];
  param_2[0x11] = param_1[0x11];
  param_2[0x12] = param_1[0x12];
  param_2[0x13] = param_1[0x13];
  param_2[0x14] = param_1[0x15];
  param_2[0x15] = param_1[0x16];
  param_2[0x16] = param_1[0x14];
  param_2[0x17] = param_1[0x17];
  param_2[0x18] = param_1[0x18];
  param_2[0x19] = param_1[0x19];
  param_2[0x1a] = param_1[0x1a];
  param_2[0x1b] = param_1[0x1b];
  param_2[0x1c] = param_1[0x1c];
  param_2[0x1d] = param_1[0x1d];
  param_2[0x1e] = param_1[0x1e];
  param_2[0x1f] = param_1[0x1f];
  param_2[0x20] = param_1[0x20];
  return;
}



void __thiscall FUN_100196f4(undefined1 *param_1,undefined1 *param_2)

{
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  param_1[6] = param_2[6];
  param_1[7] = param_2[7];
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  param_1[0xc] = param_2[0xc];
  param_1[0xd] = param_2[0xd];
  param_1[0xe] = param_2[0xe];
  param_1[0xf] = param_2[0xf];
  param_1[0x10] = param_2[0x10];
  param_1[0x11] = param_2[0x11];
  param_1[0x12] = param_2[0x12];
  param_1[0x13] = param_2[0x13];
  param_1[0x15] = param_2[0x14];
  param_1[0x16] = param_2[0x15];
  param_1[0x14] = param_2[0x16];
  param_1[0x17] = param_2[0x17];
  param_1[0x18] = param_2[0x18];
  param_1[0x19] = param_2[0x19];
  param_1[0x1a] = param_2[0x1a];
  param_1[0x1b] = param_2[0x1b];
  param_1[0x1c] = param_2[0x1c];
  param_1[0x1d] = param_2[0x1d];
  param_1[0x1e] = param_2[0x1e];
  param_1[0x1f] = param_2[0x1f];
  param_1[0x20] = param_2[0x20];
  return;
}



undefined1 * __fastcall FUN_100197c0(undefined1 *param_1)

{
  param_1[0xb] = 0;
  param_1[10] = 0;
  param_1[9] = 0;
  param_1[8] = 0;
  param_1[7] = 0;
  param_1[6] = 0;
  param_1[5] = 0;
  param_1[4] = 0;
  param_1[3] = 0;
  param_1[2] = 0;
  param_1[1] = 0;
  *param_1 = 0;
  return param_1;
}



void __thiscall FUN_100197f0(undefined1 *param_1,undefined1 *param_2)

{
  *param_2 = *param_1;
  param_2[1] = param_1[1];
  param_2[2] = param_1[2];
  param_2[3] = param_1[3];
  param_2[4] = param_1[4];
  param_2[5] = param_1[5];
  param_2[6] = param_1[6];
  param_2[7] = param_1[7];
  param_2[8] = param_1[8];
  param_2[9] = param_1[9];
  param_2[10] = param_1[10];
  param_2[0xb] = param_1[0xb];
  return;
}



void __thiscall FUN_10019840(undefined1 *param_1,undefined1 *param_2)

{
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  param_1[6] = param_2[6];
  param_1[7] = param_2[7];
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  return;
}



void __thiscall FUN_10019890(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  uint local_18;
  
  FUN_10019624(param_2);
  uVar3 = 0;
  do {
    *(undefined1 *)(uVar3 * 0xc2 + 0x21 + param_2) = *(undefined1 *)(param_1 + 0x21 + uVar3 * 0xc2);
    *(undefined1 *)(uVar3 * 0xc2 + 0x22 + param_2) = *(undefined1 *)(param_1 + 0x22 + uVar3 * 0xc2);
    iVar5 = param_2 + uVar3 * 0xc2 + 0x21;
    iVar1 = param_1 + 0x21 + uVar3 * 0xc2;
    local_18 = 0;
    do {
      uVar4 = local_18 + 1 & 0xff;
      iVar2 = local_18 * 0xc;
      *(undefined1 *)(iVar2 + 2 + iVar5) = *(undefined1 *)(iVar1 + 2 + local_18 * 0xc);
      *(undefined1 *)(iVar2 + 3 + iVar5) = *(undefined1 *)(iVar1 + 3 + local_18 * 0xc);
      *(undefined1 *)(iVar2 + 4 + iVar5) = *(undefined1 *)(iVar1 + 4 + local_18 * 0xc);
      *(undefined1 *)(iVar2 + 5 + iVar5) = *(undefined1 *)(iVar1 + 5 + local_18 * 0xc);
      *(undefined1 *)(iVar2 + 6 + iVar5) = *(undefined1 *)(iVar1 + 6 + local_18 * 0xc);
      *(undefined1 *)(iVar2 + 7 + iVar5) = *(undefined1 *)(iVar1 + 7 + local_18 * 0xc);
      *(undefined1 *)(iVar2 + 8 + iVar5) = *(undefined1 *)(iVar1 + 8 + local_18 * 0xc);
      *(undefined1 *)(iVar2 + 9 + iVar5) = *(undefined1 *)(iVar1 + 9 + local_18 * 0xc);
      *(undefined1 *)(iVar2 + 10 + iVar5) = *(undefined1 *)(iVar1 + 10 + local_18 * 0xc);
      *(undefined1 *)(iVar2 + 0xb + iVar5) = *(undefined1 *)(iVar1 + 0xb + local_18 * 0xc);
      *(undefined1 *)(iVar2 + 0xc + iVar5) = *(undefined1 *)(iVar1 + 0xc + local_18 * 0xc);
      *(undefined1 *)(iVar2 + 0xd + iVar5) = *(undefined1 *)(iVar1 + 0xd + local_18 * 0xc);
      local_18 = uVar4;
    } while (uVar4 < 0x10);
    uVar3 = uVar3 + 1 & 0xff;
  } while (uVar3 < 0x20);
  return;
}



void __thiscall FUN_100199a0(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  uint local_18;
  
  FUN_100196f4(param_2);
  uVar3 = 0;
  do {
    *(undefined1 *)(param_1 + 0x21 + uVar3 * 0xc2) = *(undefined1 *)(uVar3 * 0xc2 + 0x21 + param_2);
    *(undefined1 *)(param_1 + 0x22 + uVar3 * 0xc2) = *(undefined1 *)(uVar3 * 0xc2 + 0x22 + param_2);
    iVar5 = param_2 + uVar3 * 0xc2 + 0x21;
    iVar1 = param_1 + 0x21 + uVar3 * 0xc2;
    local_18 = 0;
    do {
      uVar4 = local_18 + 1 & 0xff;
      iVar2 = local_18 * 0xc;
      *(undefined1 *)(iVar1 + 2 + local_18 * 0xc) = *(undefined1 *)(iVar2 + 2 + iVar5);
      *(undefined1 *)(iVar1 + 3 + local_18 * 0xc) = *(undefined1 *)(iVar2 + 3 + iVar5);
      *(undefined1 *)(iVar1 + 4 + local_18 * 0xc) = *(undefined1 *)(iVar2 + 4 + iVar5);
      *(undefined1 *)(iVar1 + 5 + local_18 * 0xc) = *(undefined1 *)(iVar2 + 5 + iVar5);
      *(undefined1 *)(iVar1 + 6 + local_18 * 0xc) = *(undefined1 *)(iVar2 + 6 + iVar5);
      *(undefined1 *)(iVar1 + 7 + local_18 * 0xc) = *(undefined1 *)(iVar2 + 7 + iVar5);
      *(undefined1 *)(iVar1 + 8 + local_18 * 0xc) = *(undefined1 *)(iVar2 + 8 + iVar5);
      *(undefined1 *)(iVar1 + 9 + local_18 * 0xc) = *(undefined1 *)(iVar2 + 9 + iVar5);
      *(undefined1 *)(iVar1 + 10 + local_18 * 0xc) = *(undefined1 *)(iVar2 + 10 + iVar5);
      *(undefined1 *)(iVar1 + 0xb + local_18 * 0xc) = *(undefined1 *)(iVar2 + 0xb + iVar5);
      *(undefined1 *)(iVar1 + 0xc + local_18 * 0xc) = *(undefined1 *)(iVar2 + 0xc + iVar5);
      *(undefined1 *)(iVar1 + 0xd + local_18 * 0xc) = *(undefined1 *)(iVar2 + 0xd + iVar5);
      local_18 = uVar4;
    } while (uVar4 < 0x10);
    uVar3 = uVar3 + 1 & 0xff;
  } while (uVar3 < 0x20);
  return;
}



undefined1 * __fastcall FUN_10019ab0(undefined1 *param_1)

{
  param_1[2] = 1;
  *param_1 = 1;
  param_1[1] = 3;
  param_1[5] = 0;
  param_1[3] = 0x50;
  param_1[4] = 0x40;
  return param_1;
}



void __thiscall FUN_10019ad0(undefined1 *param_1,undefined1 *param_2)

{
  *param_2 = *param_1;
  param_2[1] = param_1[1];
  param_2[2] = param_1[2];
  param_2[3] = param_1[3];
  param_2[4] = param_1[4];
  param_2[5] = param_1[5];
  return;
}



void __thiscall FUN_10019b00(undefined1 *param_1,undefined1 *param_2)

{
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  return;
}



undefined1 * __fastcall FUN_10019b30(undefined1 *param_1)

{
  *param_1 = 1;
  param_1[3] = 0;
  param_1[2] = 0;
  param_1[1] = 0x46;
  return param_1;
}



void __thiscall FUN_10019b50(undefined1 *param_1,undefined1 *param_2)

{
  *param_2 = *param_1;
  param_2[1] = param_1[1];
  param_2[2] = param_1[2];
  param_2[3] = param_1[3];
  return;
}



void __thiscall FUN_10019b70(undefined1 *param_1,undefined1 *param_2)

{
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  return;
}



undefined1 * __fastcall FUN_10019b90(undefined1 *param_1)

{
  *param_1 = 1;
  param_1[1] = 0x46;
  param_1[2] = 0x40;
  param_1[4] = 0;
  param_1[3] = 0x7f;
  return param_1;
}



void __thiscall FUN_10019bb0(undefined1 *param_1,undefined1 *param_2)

{
  *param_2 = *param_1;
  param_2[1] = param_1[1];
  param_2[2] = param_1[2];
  param_2[3] = param_1[3];
  param_2[4] = param_1[4];
  return;
}



void __thiscall FUN_10019be0(undefined1 *param_1,undefined1 *param_2)

{
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  return;
}



undefined1 * __fastcall FUN_10019c10(undefined1 *param_1)

{
  param_1[6] = 1;
  *param_1 = 1;
  param_1[1] = 0x46;
  param_1[2] = 0x40;
  param_1[3] = 0x28;
  param_1[4] = 0x18;
  param_1[5] = 0x5a;
  param_1[7] = 0;
  return param_1;
}



void __thiscall FUN_10019c40(undefined1 *param_1,undefined1 *param_2)

{
  *param_2 = *param_1;
  param_2[1] = param_1[1];
  param_2[2] = param_1[2];
  param_2[3] = param_1[3];
  param_2[4] = param_1[4];
  param_2[5] = param_1[5];
  param_2[6] = param_1[6];
  param_2[7] = param_1[7];
  return;
}



void __thiscall FUN_10019c80(undefined1 *param_1,undefined1 *param_2)

{
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  param_1[6] = param_2[6];
  param_1[7] = param_2[7];
  return;
}



undefined1 * __fastcall FUN_10019cc0(undefined1 *param_1)

{
  *param_1 = 100;
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  return param_1;
}



void __thiscall FUN_10019ce0(undefined1 *param_1,undefined1 *param_2)

{
  *param_2 = *param_1;
  param_2[1] = (char)*(undefined4 *)(param_1 + 4);
  param_2[2] = (char)*(undefined4 *)(param_1 + 8);
  param_2[3] = param_1[0xc];
  param_2[4] = param_1[0xd];
  return;
}



void __thiscall FUN_10019ce4(undefined1 *param_1,undefined1 *param_2)

{
  *param_2 = *param_1;
  param_2[1] = (char)*(undefined4 *)(param_1 + 4);
  param_2[2] = (char)*(undefined4 *)(param_1 + 8);
  param_2[3] = param_1[0xc];
  param_2[4] = param_1[0xd];
  return;
}



void __thiscall FUN_10019d10(undefined1 *param_1,undefined1 *param_2)

{
  *param_1 = *param_2;
  *(uint *)(param_1 + 4) = (uint)(byte)param_2[1];
  *(uint *)(param_1 + 8) = (uint)(byte)param_2[2];
  param_1[0xc] = param_2[3];
  param_1[0xd] = param_2[4];
  return;
}



void __thiscall FUN_10019d14(undefined1 *param_1,undefined1 *param_2)

{
  *param_1 = *param_2;
  *(uint *)(param_1 + 4) = (uint)(byte)param_2[1];
  *(uint *)(param_1 + 8) = (uint)(byte)param_2[2];
  param_1[0xc] = param_2[3];
  param_1[0xd] = param_2[4];
  return;
}



undefined1 * __fastcall FUN_10019d50(undefined1 *param_1)

{
  *param_1 = 1;
  param_1[1] = 100;
  param_1[2] = 0x40;
  param_1[5] = 0;
  param_1[4] = 0;
  param_1[3] = 0;
  return param_1;
}



void __thiscall FUN_10019d70(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  FUN_10019ce4(param_2);
  uVar2 = 0;
  do {
    iVar1 = uVar2 * 6;
    uVar2 = uVar2 + 1 & 0xff;
    *(undefined1 *)(iVar1 + 5 + param_2) = *(undefined1 *)(param_1 + 0x10 + iVar1);
    *(undefined1 *)(iVar1 + 6 + param_2) = *(undefined1 *)(param_1 + 0x11 + iVar1);
    *(undefined1 *)(iVar1 + 7 + param_2) = *(undefined1 *)(param_1 + 0x12 + iVar1);
    *(undefined1 *)(iVar1 + 8 + param_2) = *(undefined1 *)(param_1 + 0x13 + iVar1);
    *(undefined1 *)(iVar1 + 9 + param_2) = *(undefined1 *)(param_1 + 0x14 + iVar1);
    *(undefined1 *)(iVar1 + 10 + param_2) = *(undefined1 *)(param_1 + 0x15 + iVar1);
  } while (uVar2 < 4);
  return;
}



void __thiscall FUN_10019de0(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  FUN_10019d14(param_2);
  uVar2 = 0;
  do {
    iVar1 = uVar2 * 6;
    uVar2 = uVar2 + 1 & 0xff;
    *(undefined1 *)(iVar1 + 0x10 + param_1) = *(undefined1 *)(iVar1 + 5 + param_2);
    *(undefined1 *)(iVar1 + 0x11 + param_1) = *(undefined1 *)(iVar1 + 6 + param_2);
    *(undefined1 *)(iVar1 + 0x12 + param_1) = *(undefined1 *)(iVar1 + 7 + param_2);
    *(undefined1 *)(iVar1 + 0x13 + param_1) = *(undefined1 *)(iVar1 + 8 + param_2);
    *(undefined1 *)(iVar1 + 0x14 + param_1) = *(undefined1 *)(iVar1 + 9 + param_2);
    *(undefined1 *)(iVar1 + 0x15 + param_1) = *(undefined1 *)(iVar1 + 10 + param_2);
  } while (uVar2 < 4);
  return;
}



undefined1 * __fastcall FUN_10019e50(undefined1 *param_1)

{
  *(undefined4 *)(param_1 + 8) = 0x29a;
  *param_1 = 0x4d;
  *(undefined4 *)(param_1 + 4) = 0x309;
  return param_1;
}



void __thiscall FUN_10019e70(undefined1 *param_1,undefined1 *param_2)

{
  *param_2 = *param_1;
  FUN_100040e0(param_2 + 1,*(undefined4 *)(param_1 + 4));
  FUN_100040e0(param_2 + 5,*(undefined4 *)(param_1 + 8));
  return;
}



void __thiscall FUN_10019eb0(undefined1 *param_1,undefined1 *param_2)

{
  undefined4 uVar1;
  
  *param_1 = *param_2;
  uVar1 = FUN_100040b0(param_2 + 1);
  *(undefined4 *)(param_1 + 4) = uVar1;
  uVar1 = FUN_100040b0(param_2 + 5);
  *(undefined4 *)(param_1 + 8) = uVar1;
  return;
}



undefined4 * __fastcall FUN_10019ef0(undefined4 *param_1)

{
  *(undefined1 *)(param_1 + 1) = 0x4d;
  *(undefined1 *)((int)param_1 + 5) = 0x4d;
  *param_1 = 0x29a;
  return param_1;
}



void __thiscall FUN_10019f10(undefined4 *param_1,int param_2)

{
  FUN_100040e0(param_2,*param_1);
  *(undefined1 *)(param_2 + 4) = *(undefined1 *)(param_1 + 1);
  *(undefined1 *)(param_2 + 5) = *(undefined1 *)((int)param_1 + 5);
  return;
}



void __thiscall FUN_10019f40(undefined4 *param_1,int param_2)

{
  undefined4 uVar1;
  
  uVar1 = FUN_100040b0(param_2);
  *param_1 = uVar1;
  *(undefined1 *)(param_1 + 1) = *(undefined1 *)(param_2 + 4);
  *(undefined1 *)((int)param_1 + 5) = *(undefined1 *)(param_2 + 5);
  return;
}



void __thiscall FUN_10019f70(int param_1,uint param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  
  uVar2 = 0;
  do {
    puVar1 = *(undefined4 **)(param_1 + 4 + uVar2 * 4);
    if (puVar1 != (undefined4 *)0x0) {
      (**(code **)*puVar1)(1);
    }
    *(undefined4 *)(param_1 + 4 + uVar2 * 4) = 0;
    uVar2 = uVar2 + 1 & 0xffff;
  } while (uVar2 < 0x18);
  uVar2 = 0;
  do {
    puVar1 = *(undefined4 **)(param_1 + 100 + uVar2 * 4);
    if (puVar1 != (undefined4 *)0x0) {
      (**(code **)*puVar1)(1);
    }
    *(undefined4 *)(param_1 + 100 + uVar2 * 4) = 0;
    uVar2 = uVar2 + 1 & 0xffff;
  } while (uVar2 < 0x15);
  if (*(undefined4 **)(param_1 + 0xb8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0xb8))(1);
  }
  *(undefined4 *)(param_1 + 0xb8) = 0;
  if ((param_2 & 1) == 0) {
    return;
  }
  FUN_1002dde0(param_1);
  return;
}



void FUN_1001a030(short *param_1)

{
  short *psVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined1 auStack_5a [14];
  undefined1 local_4c [12];
  undefined4 local_40;
  undefined1 *local_3c;
  short *local_38;
  int local_34;
  short *local_30;
  int local_2c;
  undefined4 local_28;
  uint local_24;
  uint local_20;
  uint local_1c;
  uint local_18;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1001a3d0;
  local_10 = ExceptionList;
  local_14 = auStack_5a + -0x12;
  local_8 = 0;
  ExceptionList = &local_10;
  psVar1 = operator_new(0xbc);
  if (psVar1 == (short *)0x0) {
    psVar1 = (short *)0x0;
  }
  else {
    *psVar1 = 0;
    uVar4 = 0;
    do {
      (psVar1 + uVar4 * 2 + 2)[0] = 0;
      (psVar1 + uVar4 * 2 + 2)[1] = 0;
      uVar4 = uVar4 + 1 & 0xffff;
    } while (uVar4 < 0x18);
    uVar4 = 0;
    do {
      (psVar1 + uVar4 * 2 + 0x32)[0] = 0;
      (psVar1 + uVar4 * 2 + 0x32)[1] = 0;
      uVar4 = uVar4 + 1 & 0xffff;
    } while (uVar4 < 0x15);
    psVar1[0x5c] = 0;
    psVar1[0x5d] = 0;
  }
  *psVar1 = *param_1;
  if (*param_1 == 0x19b) {
    FUN_10008fb0();
    local_28 = FUN_1000dee0();
    local_24 = 0;
    do {
      uVar2 = FUN_1001a3e0(local_28,local_24 + 1000 & 0xffff);
      uVar4 = local_24 + 1 & 0xffff;
      *(undefined4 *)(psVar1 + local_24 * 2 + 2) = uVar2;
      local_24 = uVar4;
    } while (uVar4 < 0x18);
    local_20 = 0;
    do {
      uVar2 = FUN_1001a3e0(local_28,local_20 + 0x401 & 0xffff);
      uVar4 = local_20 + 1 & 0xffff;
      *(undefined4 *)(psVar1 + local_20 * 2 + 0x32) = uVar2;
      local_20 = uVar4;
    } while (uVar4 < 0x15);
    uVar2 = FUN_1001a3e0(local_28,0x400);
    *(undefined4 *)(psVar1 + 0x5c) = uVar2;
  }
  else {
    local_3c = local_4c;
    FUN_1000c700(*(undefined4 *)(param_1 + 2));
    local_8 = 1;
    FUN_10008fb0();
    local_40 = FUN_1000dee0();
    uVar4 = 0;
    local_38 = param_1 + 6;
    do {
      local_34 = uVar4 * 2;
      local_1c = uVar4;
      if ((char)local_38[uVar4 * 8] == '\0') {
        uVar2 = FUN_1001a3e0(local_40,uVar4 + 1000 & 0xffff);
        *(undefined4 *)(psVar1 + local_1c * 2 + 2) = uVar2;
      }
      else {
        uVar2 = FUN_1001a500(param_1,local_3c,local_38 + uVar4 * 8);
        *(undefined4 *)(psVar1 + local_1c * 2 + 2) = uVar2;
      }
      uVar4 = local_1c + 1 & 0xffff;
    } while (uVar4 < 0x18);
    uVar4 = 0;
    local_30 = param_1 + 0xc6;
    do {
      local_2c = uVar4 * 2;
      local_18 = uVar4;
      if ((char)local_30[uVar4 * 8] == '\0') {
        uVar2 = FUN_1001a3e0(local_40,uVar4 + 0x401 & 0xffff);
        *(undefined4 *)(psVar1 + local_18 * 2 + 0x32) = uVar2;
      }
      else {
        uVar2 = FUN_1001a500(param_1,local_3c,local_30 + uVar4 * 8);
        *(undefined4 *)(psVar1 + local_18 * 2 + 0x32) = uVar2;
      }
      uVar4 = local_18 + 1 & 0xffff;
    } while (uVar4 < 0x15);
    if ((char)param_1[0x16e] == '\0') {
      uVar2 = FUN_1001a3e0(local_40,0x400);
      *(undefined4 *)(psVar1 + 0x5c) = uVar2;
    }
    else {
      uVar2 = FUN_1001a500(param_1,local_3c,param_1 + 0x16e);
      *(undefined4 *)(psVar1 + 0x5c) = uVar2;
    }
    local_8 = 0;
    FUN_1000c810();
  }
  puVar3 = operator_new(8);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = 0;
    puVar3[1] = 0;
  }
  puVar3[1] = 0;
  *puVar3 = psVar1;
  if (DAT_10118284 == (undefined4 *)0x0) {
    DAT_10118280 = puVar3;
  }
  else {
    *(undefined4 **)((int)DAT_10118284 + 4) = puVar3;
  }
  DAT_10118284 = puVar3;
  ExceptionList = local_10;
  return;
}



undefined4 FUN_1001a3e0(undefined4 param_1,short param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1001a4f0;
  local_10 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_10;
  puVar1 = (undefined4 *)FUN_1000d630(&DAT_1014f570,(int)param_2);
  uVar2 = FUN_10003300(puVar1,&DAT_1014fc50);
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  ExceptionList = local_10;
  return uVar2;
}



undefined4 FUN_1001a500(undefined4 param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1001a6a0;
  local_10 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_10;
  puVar1 = operator_new(0x14);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    FUN_10006fd0(*(int *)(param_3 + 0xc) - *(int *)(param_3 + 8));
  }
  iVar2 = FUN_10007210();
  (**(code **)(*param_2 + 0x30))
            (*(int *)(param_3 + 4) + *(int *)(param_3 + 8),
             *(int *)(param_3 + 0xc) - *(int *)(param_3 + 8),iVar2);
  if (0x400 < *(int *)(param_3 + 0xc)) {
    FUN_100163d0((iVar2 + 0x400) - *(int *)(param_3 + 8),*(int *)(param_3 + 0xc) + -0x400,
                 *(undefined1 *)(param_3 + 1));
  }
  uVar3 = FUN_10003300(puVar1,&DAT_1014fc50);
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  ExceptionList = local_10;
  return uVar3;
}



void FUN_1001a6b0(short param_1)

{
  short *psVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  
  uVar2 = 0;
  puVar7 = DAT_10118280;
  if (DAT_10118280 != (undefined4 *)0x0) {
    uVar2 = 0;
    puVar8 = DAT_10118280;
    do {
      puVar7 = puVar8;
      uVar2 = uVar2 + 1;
      puVar8 = (undefined4 *)puVar7[1];
    } while ((undefined4 *)puVar7[1] != (undefined4 *)0x0);
  }
  uVar4 = 0;
  if ((uVar2 & 0xffff) != 0) {
    do {
      uVar3 = 0;
      puVar8 = DAT_10118280;
      puVar9 = DAT_10118280;
      if (uVar4 != 0) {
        do {
          puVar9 = puVar8;
          uVar3 = uVar3 + 1;
          puVar8 = (undefined4 *)puVar9[1];
        } while (uVar4 != uVar3);
      }
      psVar1 = (short *)*puVar8;
      if (*psVar1 == param_1) {
        uVar2 = 0;
        puVar5 = DAT_10118280;
        if (uVar4 == 0) {
          puVar6 = DAT_10118280;
        }
        else {
          do {
            puVar6 = puVar5;
            uVar2 = uVar2 + 1;
            puVar5 = (undefined4 *)puVar6[1];
          } while (uVar4 != uVar2);
        }
        if (puVar5 == DAT_10118280) {
          DAT_10118280 = (undefined4 *)DAT_10118280[1];
          FUN_1002dde0(puVar5,puVar5,puVar6,&DAT_10118280,0,puVar7,&DAT_10118280,puVar8,puVar9,
                       &DAT_10118280);
          if (DAT_10118280 == (undefined4 *)0x0) {
            DAT_10118284 = (undefined4 *)0x0;
          }
        }
        else if (puVar5 != (undefined4 *)0x0) {
          puVar6[1] = puVar5[1];
          if (puVar5 == DAT_10118284) {
            DAT_10118284 = puVar6;
          }
          FUN_1002dde0(puVar5,puVar5,puVar6,&DAT_10118280,0,puVar7,&DAT_10118280,puVar8,puVar9,
                       &DAT_10118280);
        }
        if (psVar1 != (short *)0x0) {
          FUN_10019f70(1);
        }
        return;
      }
      uVar4 = uVar4 + 1 & 0xffff;
    } while (uVar4 < (uVar2 & 0xffff));
  }
  return;
}



short * FUN_1001a860(short param_1)

{
  uint uVar1;
  uint uVar2;
  undefined4 *puVar3;
  uint uVar4;
  
  uVar4 = 0;
  for (puVar3 = DAT_10118280; puVar3 != (undefined4 *)0x0; puVar3 = (undefined4 *)puVar3[1]) {
    uVar4 = uVar4 + 1;
  }
  uVar2 = 0;
  if ((uVar4 & 0xffff) != 0) {
    do {
      uVar1 = 0;
      puVar3 = DAT_10118280;
      if (uVar2 != 0) {
        do {
          uVar1 = uVar1 + 1;
          puVar3 = (undefined4 *)puVar3[1];
        } while (uVar2 != uVar1);
      }
      if (*(short *)*puVar3 == param_1) {
        return (short *)*puVar3;
      }
      uVar2 = uVar2 + 1 & 0xffff;
    } while (uVar2 < (uVar4 & 0xffff));
  }
  return (short *)0x0;
}



void __thiscall FUN_1001a990(undefined4 param_1,uint param_2)

{
  FUN_10009500();
  if ((param_2 & 1) == 0) {
    return;
  }
  FUN_1002dde0(param_1);
  return;
}



void __thiscall FUN_1001a9c0(undefined4 param_1,uint param_2)

{
  FUN_10026e10();
  if ((param_2 & 1) == 0) {
    return;
  }
  FUN_1002dde0(param_1);
  return;
}



void __thiscall FUN_1001a9f0(undefined4 param_1,uint param_2)

{
  FUN_10009870();
  if ((param_2 & 1) == 0) {
    return;
  }
  FUN_1002dde0(param_1);
  return;
}



void __thiscall FUN_1001aa50(undefined4 param_1,uint param_2)

{
  FUN_1001bc50();
  if ((param_2 & 1) == 0) {
    return;
  }
  FUN_1002dde0(param_1);
  return;
}



void __thiscall FUN_1001aa80(undefined4 param_1,uint param_2)

{
  FUN_10011ba0();
  if ((param_2 & 1) == 0) {
    return;
  }
  FUN_1002dde0(param_1);
  return;
}



void __thiscall FUN_1001aab0(undefined4 param_1,uint param_2)

{
  FUN_1001ca80();
  if ((param_2 & 1) == 0) {
    return;
  }
  FUN_1002dde0(param_1);
  return;
}



void FUN_1001ab10(void)

{
  if (DAT_1011d0b0 != (undefined4 *)0x0) {
    (**(code **)*DAT_1011d0b0)(1);
  }
  DAT_1011d0b0 = (undefined4 *)0x0;
  return;
}



void GetMIDIClockInSyncTrim(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
                    // 0x1ab40  5  GetMIDIClockInSyncTrim
  puStack_c = &LAB_1001abb0;
  local_10 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_10;
  FUN_10007e50();
  ExceptionList = local_10;
  return;
}



void SetMIDIClockInSyncTrim(undefined4 param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
                    // 0x1abc0  9  SetMIDIClockInSyncTrim
  puStack_c = &LAB_1001ac20;
  local_10 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_10;
  FUN_10007e60(param_1);
  ExceptionList = local_10;
  return;
}



undefined1 IsMIDISyncRunning(void)

{
  undefined1 uVar1;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
                    // 0x1ac30  7  IsMIDISyncRunning
  puStack_c = &LAB_1001acb0;
  local_10 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_10;
  uVar1 = FUN_1001c4f4();
  ExceptionList = local_10;
  return uVar1;
}



undefined1 IsMIDISyncActive(void)

{
                    // 0x1acc0  6  IsMIDISyncActive
  return *(undefined1 *)(DAT_1011d0b4 + 0x160);
}



void SetMIDISyncActive(undefined1 param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
                    // 0x1ad40  10  SetMIDISyncActive
  puStack_c = &LAB_1001ada0;
  local_10 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_10;
  FUN_1001c4c4(param_1);
  ExceptionList = local_10;
  return;
}



void SyncSoundCallback(void)

{
  char cVar1;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
                    // 0x1adb0  11  SyncSoundCallback
  puStack_c = &LAB_1001ae30;
  local_10 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_10;
  cVar1 = FUN_10009450();
  if (cVar1 != '\0') {
    FUN_1001c474();
    FUN_100094a0();
  }
  ExceptionList = local_10;
  return;
}



void SafeSoundCallback(undefined2 *param_1,int param_2)

{
  char cVar1;
  undefined2 *puVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  bool bVar8;
  int local_30;
  int local_28;
  int local_24;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
                    // 0x1ae40  8  SafeSoundCallback
  puStack_c = &LAB_1001b060;
  local_10 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_10;
  cVar1 = FUN_10009450();
  if (cVar1 != '\0') {
    FUN_1001cc40(param_2);
    bVar8 = *(int *)(DAT_1011d0b4 + 0x16c) != 0;
    if (bVar8) {
      FUN_100139e0(param_1,param_2);
    }
    FUN_100094a0();
    if (bVar8) goto LAB_1001af01;
  }
  if (0 < param_2 << 1) {
    puVar2 = param_1;
    do {
      *puVar2 = 0;
      puVar2[1] = 0;
      puVar2 = puVar2 + 2;
    } while ((int)puVar2 < (int)(param_1 + param_2 * 2));
  }
LAB_1001af01:
  local_30 = *(int *)(*(int *)(DAT_1011d0b0 + 0x370) + 0x42c);
  if (*(int *)(*(int *)(DAT_1011d0b0 + 0x370) + 0x428) != 0) {
    iVar3 = FUN_1000aa60();
    iVar4 = FUN_1000aa80();
    iVar5 = FUN_10004630(iVar4 - local_30,param_2);
    iVar6 = 0;
    if (0 < iVar5) {
      do {
        uVar7 = (uint)*(short *)(iVar3 + local_30 * 2);
        local_28 = (int)(short)((int)(uVar7 + (0x7fffffff < uVar7)) >> 1);
        local_24 = (short)param_1[iVar6 * 2 + 1] + local_28;
        local_28 = local_28 + (short)param_1[iVar6 * 2];
        if (local_28 < 0x8000) {
          if (local_28 < -0x8000) {
            local_28 = -0x8000;
          }
        }
        else {
          local_28 = 0x7fff;
        }
        if (local_24 < 0x8000) {
          if (local_24 < -0x8000) {
            local_24 = -0x8000;
          }
        }
        else {
          local_24 = 0x7fff;
        }
        param_1[iVar6 * 2 + 1] = (short)local_24;
        param_1[iVar6 * 2] = (short)local_28;
        iVar6 = iVar6 + 1;
        local_30 = local_30 + 1;
      } while (iVar6 < iVar5);
    }
    if (local_30 == iVar4) {
      *(undefined4 *)(*(int *)(DAT_1011d0b0 + 0x370) + 0x428) = 0;
    }
    *(int *)(*(int *)(DAT_1011d0b0 + 0x370) + 0x42c) = local_30;
  }
  ExceptionList = local_10;
  return;
}



void EngineIdle(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
                    // 0x1b070  3  EngineIdle
  puStack_c = &LAB_1001b0d0;
  local_10 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_10;
  FUN_1001cb00();
  ExceptionList = local_10;
  return;
}



undefined4 EngineOpen(void)

{
  void *pvVar1;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
                    // 0x1b0e0  4  EngineOpen
  puStack_c = &LAB_1001b190;
  local_10 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_10;
  pvVar1 = operator_new(0x430);
  if (pvVar1 == (void *)0x0) {
    pvVar1 = (void *)0x0;
  }
  else {
    FUN_1001c7b0(0x2d);
  }
  *(void **)(DAT_1011d0b0 + 0x370) = pvVar1;
  ExceptionList = local_10;
  return 1;
}



void EngineClose(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
                    // 0x1b1a0  1  EngineClose
  puStack_c = &LAB_1001b220;
  local_10 = ExceptionList;
  local_8 = 0;
  if (*(int *)(DAT_1011d0b0 + 0x370) != 0) {
    ExceptionList = &local_10;
    FUN_1001aab0(1);
  }
  *(undefined4 *)(DAT_1011d0b0 + 0x370) = 0;
  ExceptionList = local_10;
  return;
}



void EngineHandleMIDI(undefined4 param_1,undefined1 param_2,byte param_3,byte param_4)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
                    // 0x1b230  2  EngineHandleMIDI
  puStack_c = &LAB_1001b310;
  local_10 = ExceptionList;
  local_8 = 0;
  switch(param_2) {
  case 0xf2:
    ExceptionList = &local_10;
    FUN_1001c5c4(((uint)param_4 * 0x80 + (uint)param_3) * 0x30);
    break;
  case 0xf3:
  case 0xf4:
  case 0xf5:
  case 0xf6:
  case 0xf7:
  case 0xf9:
    break;
  case 0xf8:
    ExceptionList = &local_10;
    FUN_1001c614(param_1);
    break;
  case 0xfa:
    ExceptionList = &local_10;
    FUN_1001c524();
    break;
  case 0xfb:
    ExceptionList = &local_10;
    FUN_1001c574();
    break;
  case 0xfc:
    ExceptionList = &local_10;
    FUN_1001e0b0();
  }
  ExceptionList = local_10;
  return;
}



void TopHatGetDeviceNameAndVersionProc(undefined4 *param_1,char *param_2)

{
                    // 0x1b320  15  TopHatGetDeviceNameAndVersionProc
  *param_1 = 8;
  sprintf(param_2,s_ReBirth_Audio_101534d0);
  return;
}



void TopHatGetDeviceInfoProc(char *param_1)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  char *pcVar4;
  char *pcVar5;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
                    // 0x1b350  14  TopHatGetDeviceInfoProc
  puStack_c = &LAB_1001b5b0;
  local_10 = ExceptionList;
  local_8 = 0;
  pcVar4 = param_1;
  ExceptionList = &local_10;
  for (iVar2 = 0x236; iVar2 != 0; iVar2 = iVar2 + -1) {
    pcVar4[0] = '\0';
    pcVar4[1] = '\0';
    pcVar4[2] = '\0';
    pcVar4[3] = '\0';
    pcVar4 = pcVar4 + 4;
  }
  param_1[0x8c4] = '\b';
  param_1[0x8c5] = '\0';
  param_1[0x8c6] = '\0';
  param_1[0x8c7] = '\0';
  sprintf(param_1,s_ReBirth_Audio_101534d0);
  pcVar4 = param_1 + 0x24;
  pcVar5 = &DAT_101534e0;
  param_1[0x20] = '\x12';
  param_1[0x21] = '\0';
  param_1[0x22] = '\0';
  param_1[0x23] = '\0';
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
    *pcVar4 = cVar1;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  pcVar5 = &DAT_101534f0;
  pcVar4 = param_1 + 0x44;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
    *pcVar4 = cVar1;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  pcVar5 = &DAT_10153500;
  pcVar4 = param_1 + 100;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
    *pcVar4 = cVar1;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  pcVar5 = &DAT_10153510;
  pcVar4 = param_1 + 0x84;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
    *pcVar4 = cVar1;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  pcVar5 = &DAT_10153520;
  pcVar4 = param_1 + 0xa4;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
    *pcVar4 = cVar1;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  pcVar5 = &DAT_10153530;
  pcVar4 = param_1 + 0xc4;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
    *pcVar4 = cVar1;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  pcVar5 = &DAT_10153540;
  pcVar4 = param_1 + 0xe4;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
    *pcVar4 = cVar1;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  pcVar5 = &DAT_10153550;
  pcVar4 = param_1 + 0x104;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
    *pcVar4 = cVar1;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  pcVar5 = &DAT_10153560;
  pcVar4 = param_1 + 0x124;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
    *pcVar4 = cVar1;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  pcVar5 = &DAT_10153570;
  pcVar4 = param_1 + 0x144;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
    *pcVar4 = cVar1;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  pcVar5 = &DAT_10153580;
  pcVar4 = param_1 + 0x164;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
    *pcVar4 = cVar1;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  pcVar5 = &DAT_10153590;
  pcVar4 = param_1 + 0x184;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
    *pcVar4 = cVar1;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  pcVar5 = &DAT_101535a0;
  pcVar4 = param_1 + 0x1a4;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
    *pcVar4 = cVar1;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  pcVar5 = &DAT_101535b0;
  pcVar4 = param_1 + 0x1c4;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
    *pcVar4 = cVar1;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  pcVar5 = &DAT_101535c0;
  pcVar4 = param_1 + 0x1e4;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
    *pcVar4 = cVar1;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  pcVar5 = &DAT_101535d0;
  pcVar4 = param_1 + 0x204;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
    *pcVar4 = cVar1;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  pcVar5 = &DAT_101535e0;
  pcVar4 = param_1 + 0x224;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
    *pcVar4 = cVar1;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  pcVar5 = &DAT_101535f0;
  pcVar4 = param_1 + 0x244;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
    *pcVar4 = cVar1;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  uVar3 = 0;
  do {
    param_1[uVar3 + 0x824] = '\x01';
    uVar3 = uVar3 + 1 & 0xffff;
  } while (uVar3 < 0x12);
  param_1[0x864] = '\x01';
  param_1[0x8a4] = '\x01';
  param_1[0x865] = '\x01';
  ExceptionList = local_10;
  return;
}



undefined4 TopHatOpenDeviceProc(void)

{
  char cVar1;
  void *pvVar2;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
                    // 0x1b5c0  18  TopHatOpenDeviceProc
  puStack_c = &LAB_1001b6b0;
  local_10 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_10;
  cVar1 = FUN_10017940(s_ReBirth_DLL_>Panel_10152d18);
  if (cVar1 != '\0') {
    ExceptionList = local_10;
    return 4;
  }
  pvVar2 = operator_new(0x430);
  if (pvVar2 == (void *)0x0) {
    pvVar2 = (void *)0x0;
  }
  else {
    FUN_1001c7b0(0x2e);
  }
  *(void **)(DAT_1011d0b0 + 0x370) = pvVar2;
  ExceptionList = local_10;
  return 1;
}



undefined4 TopHatIsCloseOKProc(void)

{
  char cVar1;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
                    // 0x1b6c0  17  TopHatIsCloseOKProc
  puStack_c = &LAB_1001b760;
  local_10 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_10;
  cVar1 = FUN_10009370(s_ReBirth_panel_loaded_10153620);
  if (cVar1 == '\0') {
    ExceptionList = local_10;
    return 1;
  }
  ExceptionList = local_10;
  return 0;
}



void TopHatCloseDeviceProc(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
                    // 0x1b770  12  TopHatCloseDeviceProc
  puStack_c = &LAB_1001b7f0;
  local_10 = ExceptionList;
  local_8 = 0;
  if (*(int *)(DAT_1011d0b0 + 0x370) != 0) {
    ExceptionList = &local_10;
    FUN_1001aab0(1);
  }
  *(undefined4 *)(DAT_1011d0b0 + 0x370) = 0;
  ExceptionList = local_10;
  return;
}



void TopHatDriveAudioProc(int param_1)

{
  char cVar1;
  undefined1 *puVar2;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
                    // 0x1b800  13  TopHatDriveAudioProc
  puStack_c = &LAB_1001b900;
  local_10 = ExceptionList;
  local_8 = 0;
  DAT_10121ed8 = *(int *)(param_1 + 0x95c) == 0;
  puVar2 = (undefined1 *)(param_1 + 0x1188);
  ExceptionList = &local_10;
  do {
    *puVar2 = 0;
    puVar2 = puVar2 + 1;
  } while ((int)puVar2 < param_1 + 0x11c8);
  *(undefined4 *)(param_1 + 0x1184) = 0;
  cVar1 = FUN_10009450();
  if (cVar1 != '\0') {
    FUN_1001c0f4(param_1);
    FUN_1001cc40(*(undefined4 *)(param_1 + 0x944));
    FUN_1001c204(param_1);
    FUN_100094a0();
  }
  ExceptionList = local_10;
  return;
}



void TopHatIdleProc(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
                    // 0x1b910  16  TopHatIdleProc
  puStack_c = &LAB_1001b970;
  local_10 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_10;
  FUN_1001cb00();
  ExceptionList = local_10;
  return;
}



undefined4 * __fastcall FUN_1001b980(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1001ba40;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_100180e0();
  local_8 = 0;
  *param_1 = &PTR_LAB_10033c44;
  FUN_10017e60(s_DLL_Writer_10153600,s_ReBirth_DLL_>Panel_10152d18);
  local_8 = 1;
  FUN_10017c50(s_DLL_Reader_10153610,s_ReBirth_Panel_>DLL_10152ee8);
  ExceptionList = local_10;
  return param_1;
}



void __fastcall FUN_1001ba50(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1001bb00;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  *param_1 = &PTR_LAB_10033c44;
  local_8 = 1;
  FUN_10017cd0();
  local_8 = 0;
  FUN_10017ee0();
  local_8 = 0xffffffff;
  FUN_100180f0();
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_1001bb80(int param_1,undefined4 param_2)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1001bc40;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_10007b20();
  *(undefined4 *)(param_1 + 0x144) = 140000;
  *(undefined4 *)(param_1 + 0x170) = 0;
  *(undefined4 *)(param_1 + 0x16c) = 0;
  *(undefined4 *)(param_1 + 0x164) = 0;
  *(undefined1 *)(param_1 + 0x160) = 0;
  *(undefined2 *)(param_1 + 0x158) = 0;
  *(undefined4 *)(param_1 + 0x154) = 0;
  *(undefined1 *)(param_1 + 0x152) = 0;
  *(undefined1 *)(param_1 + 0x151) = 0;
  *(undefined1 *)(param_1 + 0x150) = 0;
  *(undefined4 *)(param_1 + 0x148) = 0;
  *(undefined4 *)(param_1 + 0x14c) = 0x300;
  *(undefined4 *)(param_1 + 0x15c) = param_2;
  ExceptionList = local_10;
  return;
}



void FUN_1001bc50(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1001bcb0;
  local_10 = ExceptionList;
  local_8 = 0xffffffff;
  ExceptionList = &local_10;
  FUN_10012c00();
  ExceptionList = local_10;
  return;
}



undefined4 __fastcall FUN_1001bcc0(int param_1)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  
  cVar1 = FUN_10007e80();
  if (cVar1 != '\0') {
    uVar3 = FUN_10007e10();
    return uVar3;
  }
  if (*(int *)(param_1 + 0x16c) == 0) {
    return 0;
  }
  iVar2 = FUN_10013da0();
  return *(undefined4 *)(iVar2 + 4);
}



undefined4 __fastcall FUN_1001bd00(int param_1)

{
  return *(undefined4 *)(param_1 + 0x16c);
}



undefined4 __fastcall FUN_1001bd10(int param_1)

{
  return *(undefined4 *)(param_1 + 0x170);
}



void __thiscall FUN_1001bd24(int param_1,int param_2)

{
  char cVar1;
  
  if (((*(int *)(param_1 + 0x16c) != 0) && (param_2 == 0)) &&
     (cVar1 = FUN_1001fd50(), cVar1 != '\0')) {
    if ((*(int *)(param_1 + 0x15c) == 0x2e) && (cVar1 = FUN_1001fd50(), cVar1 != '\0')) {
      *(undefined1 *)(param_1 + 0x151) = 2;
    }
    FUN_100218a0();
  }
  *(int *)(param_1 + 0x16c) = param_2;
  return;
}



void __thiscall FUN_1001bda4(int param_1,int param_2)

{
  int iVar1;
  
  *(int *)(param_1 + 0x170) = param_2;
  if (*(int *)(param_1 + 0x16c) == 0) {
    if (param_2 != 0) {
      FUN_10013d40();
    }
    FUN_1001bd24(param_2);
  }
  else {
    iVar1 = FUN_10013da0();
    if (*(char *)(iVar1 + 1) == '\0') {
      FUN_10013d40();
      FUN_1001bd24(param_2);
      return;
    }
  }
  return;
}



void FUN_1001be10(undefined4 param_1,undefined1 param_2)

{
  undefined1 uVar1;
  undefined1 uStack_c;
  undefined1 uStack_b;
  
  uStack_b = param_2;
  uStack_c = 1;
  uVar1 = FUN_10011d70();
  FUN_1001d554(uVar1,0x23,&uStack_c,2);
  return;
}



void FUN_1001be14(undefined4 param_1,undefined1 param_2)

{
  undefined1 uVar1;
  undefined1 local_c;
  undefined1 local_b;
  
  local_b = param_2;
  local_c = 1;
  uVar1 = FUN_10011d70();
  FUN_1001d554(uVar1,0x23,&local_c,2);
  return;
}



void __thiscall FUN_1001be74(int param_1,int param_2)

{
  int iVar1;
  bool bVar2;
  char cVar3;
  
  iVar1 = *(int *)(param_1 + 0x16c);
  if (iVar1 == 0) {
    bVar2 = false;
  }
  else if (param_2 == iVar1) {
    bVar2 = false;
  }
  else {
    cVar3 = FUN_1001fd50();
    if (cVar3 == '\0') {
      bVar2 = false;
    }
    else {
      bVar2 = true;
      FUN_100218a0();
      FUN_1001be14(iVar1,0);
      FUN_10013d40();
    }
  }
  if (*(int *)(param_1 + 0x15c) == 0x2e) {
    if (bVar2) {
      FUN_1001f7e0();
      FUN_1001be14(param_2,1);
    }
    else {
      *(undefined1 *)(param_1 + 0x151) = 1;
    }
  }
  else {
    FUN_1001f7e0();
    FUN_1001be14(param_2,1);
  }
  *(int *)(param_1 + 0x16c) = param_2;
  return;
}



void FUN_1001bf40(void)

{
  return;
}



void FUN_1001bf50(undefined4 param_1)

{
  FUN_1001be74(param_1);
  return;
}



void __thiscall FUN_1001bf70(int param_1,int param_2,undefined4 param_3)

{
  if (*(int *)(param_1 + 0x15c) != 0x2e) {
    FUN_1001f980(param_3);
    return;
  }
  if (param_2 == *(int *)(param_1 + 0x16c)) {
    *(undefined4 *)(param_1 + 0x154) = param_3;
    *(undefined1 *)(param_1 + 0x152) = 1;
  }
  return;
}



void __thiscall FUN_1001bfc0(int param_1,undefined4 param_2,undefined4 param_3)

{
  if (*(int *)(param_1 + 0x15c) == 0x2e) {
    *(undefined4 *)(param_1 + 0x144) = param_3;
    return;
  }
  FUN_1001fcd0(param_3);
  return;
}



void __thiscall FUN_1001c000(int param_1,undefined4 param_2,undefined4 param_3)

{
  if ((*(int *)(param_1 + 0x15c) == 0x2e) && (DAT_10121ed8 == '\0')) {
    *(undefined4 *)(param_1 + 0x148) = param_3;
    return;
  }
  FUN_10021130(param_3);
  return;
}



void __thiscall FUN_1001c050(int param_1,undefined4 param_2,undefined4 param_3)

{
  if ((*(int *)(param_1 + 0x15c) == 0x2e) && (DAT_10121ed8 == '\0')) {
    *(undefined4 *)(param_1 + 0x14c) = param_3;
    return;
  }
  FUN_10021150(param_3);
  return;
}



void __thiscall FUN_1001c0a0(int param_1,undefined4 param_2,undefined1 param_3)

{
  if ((*(int *)(param_1 + 0x15c) == 0x2e) && (DAT_10121ed8 == '\0')) {
    *(undefined1 *)(param_1 + 0x150) = param_3;
    return;
  }
  FUN_10021110(param_3);
  return;
}



void __thiscall FUN_1001c0f4(int param_1,int param_2)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0x16c) != 0) {
    iVar1 = FUN_10013da0();
    *(undefined4 *)(iVar1 + 4) = *(undefined4 *)(param_2 + 0x950);
    *(undefined4 *)(param_1 + 0x144) = *(undefined4 *)(param_2 + 0x950);
    if (DAT_10121ed8 == '\0') {
      *(undefined4 *)(iVar1 + 0xc) = *(undefined4 *)(param_2 + 0x960);
      *(undefined4 *)(iVar1 + 0x10) = *(undefined4 *)(param_2 + 0x964);
      *(undefined1 *)(iVar1 + 3) = *(undefined1 *)(param_2 + 0x968);
      *(undefined4 *)(param_1 + 0x148) = *(undefined4 *)(param_2 + 0x960);
      *(undefined4 *)(param_1 + 0x14c) = *(undefined4 *)(param_2 + 0x964);
      *(undefined1 *)(param_1 + 0x150) = *(undefined1 *)(param_2 + 0x968);
    }
    if (*(int *)(param_1 + 0x164) != *(int *)(param_2 + 0x954)) {
      *(int *)(param_1 + 0x164) = *(int *)(param_2 + 0x954);
      FUN_1001f7c0(*(undefined1 *)(param_2 + 0x954));
      FUN_1001be14(*(undefined4 *)(param_1 + 0x16c),*(undefined1 *)(param_2 + 0x954));
    }
    if (*(int *)(param_2 + 0x958) == 0) {
      FUN_1001c2f4(*(undefined4 *)(param_2 + 0x94c));
      return;
    }
    FUN_1001c3c4(*(undefined4 *)(param_2 + 0x94c));
  }
  return;
}



void __thiscall FUN_1001c204(int param_1,int param_2)

{
  char cVar1;
  
  if (*(int *)(param_1 + 0x16c) != 0) {
    FUN_10013da0();
    FUN_10013240(param_2);
    *(undefined4 *)(param_2 + 0x974) = *(undefined4 *)(param_1 + 0x144);
    *(undefined4 *)(param_2 + 0x978) = *(undefined4 *)(param_1 + 0x148);
    *(undefined4 *)(param_2 + 0x97c) = *(undefined4 *)(param_1 + 0x14c);
    *(undefined1 *)(param_2 + 0x980) = *(undefined1 *)(param_1 + 0x150);
    *(undefined1 *)(param_2 + 0x983) = *(undefined1 *)(param_2 + 0x96b);
    *(undefined1 *)(param_2 + 0x982) = *(undefined1 *)(param_2 + 0x96a);
    cVar1 = *(char *)(param_1 + 0x151);
    if ((cVar1 != '\0') &&
       (((cVar1 == '\x01' && (*(int *)(param_1 + 0x164) != 0)) ||
        ((cVar1 == '\x02' && (*(int *)(param_1 + 0x164) == 0)))))) {
      *(undefined1 *)(param_1 + 0x151) = 0;
    }
    *(undefined1 *)(param_2 + 0x96c) = *(undefined1 *)(param_1 + 0x151);
    *(undefined1 *)(param_1 + 0x151) = 0;
    *(undefined1 *)(param_2 + 0x96d) = *(undefined1 *)(param_1 + 0x152);
    *(undefined4 *)(param_2 + 0x970) = *(undefined4 *)(param_1 + 0x154);
    *(undefined1 *)(param_1 + 0x152) = 0;
  }
  return;
}



void __thiscall FUN_1001c2f4(int param_1,int param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0x16c);
  if (iVar1 == 0) {
    return;
  }
  FUN_1001f870();
  if (*(int *)(param_1 + 0x164) == 0) {
    *(undefined2 *)(param_1 + 0x158) = 0;
  }
  else {
    cVar2 = FUN_100215d0();
    if (cVar2 != '\0') {
      iVar3 = FUN_1001f8c0();
      iVar3 = FUN_10004650(param_2 - iVar3);
      if (0xbf < iVar3) {
        iVar3 = FUN_1001f8e0();
        iVar3 = FUN_10004650(param_2 - iVar3);
        if (0xbf < iVar3) goto LAB_1001c381;
      }
      *(undefined2 *)(param_1 + 0x158) = 10;
    }
  }
LAB_1001c381:
  if (*(short *)(param_1 + 0x158) == 0) {
    *(double *)(iVar1 + 8) = (double)param_2;
    return;
  }
  *(short *)(param_1 + 0x158) = *(short *)(param_1 + 0x158) + -1;
  return;
}



void __thiscall FUN_1001c3c4(int param_1,int param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  
  if ((*(int *)(param_1 + 0x16c) != 0) && (*(short *)(param_1 + 0x158) == 0)) {
    iVar2 = FUN_1001f870();
    iVar3 = (param_2 / 0x300) * 0x300;
    if ((DAT_10121ed8 != '\0') && (cVar1 = FUN_10004680(param_2,iVar2,0x30), cVar1 != '\0')) {
      return;
    }
    if (iVar2 + 0x300 != iVar3) {
      FUN_1001fd10(iVar3);
    }
    FUN_1001f980(param_2);
  }
  return;
}



void __fastcall FUN_1001c474(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  if (*(int *)(param_1 + 0x16c) != 0) {
    uVar1 = FUN_1000e080();
    uVar2 = FUN_1001f870();
    FUN_10007e30(uVar1,uVar2);
  }
  return;
}



void __thiscall FUN_1001c4c4(int param_1,undefined1 param_2)

{
  char cVar1;
  
  cVar1 = FUN_1001c4f4();
  if (cVar1 != '\0') {
    FUN_10007ef0();
  }
  *(undefined1 *)(param_1 + 0x160) = param_2;
  return;
}



undefined1 __fastcall FUN_1001c4f4(int param_1)

{
  undefined1 uVar1;
  
  if (*(char *)(param_1 + 0x160) == '\0') {
    return 0;
  }
  uVar1 = FUN_10007e80();
  return uVar1;
}



void __fastcall FUN_1001c524(int param_1)

{
  if (*(char *)(param_1 + 0x160) != '\0') {
    if (*(int *)(param_1 + 0x170) != 0) {
      FUN_1001f980(0);
      FUN_1001be74(*(undefined4 *)(param_1 + 0x170));
    }
    FUN_10007db0();
  }
  return;
}



void __fastcall FUN_1001c574(int param_1)

{
  if (*(char *)(param_1 + 0x160) != '\0') {
    if (*(int *)(param_1 + 0x16c) != 0) {
      FUN_1001f7e0();
      FUN_1001be14(*(undefined4 *)(param_1 + 0x16c),1);
    }
    FUN_10007dd0();
  }
  return;
}



void __thiscall FUN_1001c5c4(int param_1,undefined4 param_2)

{
  if (*(char *)(param_1 + 0x160) != '\0') {
    if (*(int *)(param_1 + 0x16c) != 0) {
      FUN_1001f980(param_2);
    }
    FUN_10007df0(param_2);
  }
  return;
}



void __thiscall FUN_1001c614(int param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  
  if (*(char *)(param_1 + 0x160) != '\0') {
    cVar1 = FUN_10007e70();
    if (cVar1 != '\0') {
      cVar1 = FUN_10007e80();
      if (cVar1 != '\0') {
        iVar2 = FUN_10007e00();
        if (iVar2 % 0x300 == 0) {
          if (*(int *)(param_1 + 0x170) != 0) {
            iVar2 = FUN_1001f870();
            iVar2 = (iVar2 / 0x300) * 0x300;
            FUN_1001f8b0(iVar2);
            FUN_1001f7e0();
            FUN_10007df0(iVar2);
            FUN_10007dd0();
            FUN_1001be14(*(undefined4 *)(param_1 + 0x170),1);
          }
          FUN_10007e90(0);
        }
      }
    }
    FUN_10007b80(param_2);
  }
  return;
}



void __fastcall FUN_1001c710(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1001c7a0;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  *param_1 = &PTR_LAB_10033c34;
  local_8 = 0;
  if (param_1[0xdc] != 0) {
    FUN_1001aab0(1);
  }
  param_1[0xdc] = 0;
  local_8 = 0xffffffff;
  FUN_1000e170();
  ExceptionList = local_10;
  return;
}



int __thiscall FUN_1001c7b0(int param_1,undefined4 param_2)

{
  uint uVar1;
  void *pvVar2;
  uint uVar3;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1001ca70;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_100093c0();
  local_8 = 0;
  *(undefined4 *)(param_1 + 4) = 0;
  FUN_100181d0();
  *(undefined4 *)(param_1 + 0x42c) = 0;
  *(undefined4 *)(param_1 + 0x428) = 0;
  *(undefined1 *)(param_1 + 0x424) = 0;
  *(undefined4 *)(param_1 + 0x420) = 0;
  *(undefined4 *)(param_1 + 0x41c) = 0;
  *(undefined4 *)(param_1 + 0x418) = 0;
  *(undefined4 *)(param_1 + 0x414) = 0;
  *(undefined4 *)(param_1 + 0x410) = 0;
  uVar1 = 0;
  do {
    uVar3 = uVar1 + 1 & 0xff;
    *(undefined4 *)(param_1 + 0x14 + uVar1 * 4) = 0;
    uVar1 = uVar3;
  } while (uVar3 < 0xff);
  local_8 = 1;
  pvVar2 = operator_new(0x174);
  if (pvVar2 == (void *)0x0) {
    pvVar2 = (void *)0x0;
  }
  else {
    FUN_1001bb80(param_2);
  }
  DAT_1011d0b4 = pvVar2;
  FUN_10021a10();
  pvVar2 = operator_new(0xac);
  if (pvVar2 == (void *)0x0) {
    pvVar2 = (void *)0x0;
  }
  else {
    FUN_1001b980();
  }
  *(void **)(param_1 + 4) = pvVar2;
  pvVar2 = operator_new(0x18);
  if (pvVar2 == (void *)0x0) {
    pvVar2 = (void *)0x0;
  }
  else {
    FUN_100097c0(0x270c);
  }
  *(void **)(param_1 + 0x410) = pvVar2;
  pvVar2 = operator_new(0x20);
  if (pvVar2 == (void *)0x0) {
    pvVar2 = (void *)0x0;
  }
  else {
    FUN_10026d80(0x270c,*(undefined4 *)(param_1 + 0x410),10000);
  }
  *(void **)(param_1 + 0x414) = pvVar2;
  pvVar2 = operator_new(0x18);
  if (pvVar2 == (void *)0x0) {
    pvVar2 = (void *)0x0;
  }
  else {
    FUN_100097c0(0x270c);
  }
  *(void **)(param_1 + 0x41c) = pvVar2;
  pvVar2 = operator_new(0x20);
  if (pvVar2 == (void *)0x0) {
    pvVar2 = (void *)0x0;
  }
  else {
    FUN_10026d80(0x270c,*(undefined4 *)(param_1 + 0x41c),10000);
  }
  *(void **)(param_1 + 0x418) = pvVar2;
  pvVar2 = operator_new(0x14);
  if (pvVar2 == (void *)0x0) {
    pvVar2 = (void *)0x0;
  }
  else {
    FUN_100094c0(0x270c);
  }
  *(void **)(param_1 + 0x420) = pvVar2;
  FUN_10007e60(0);
  ExceptionList = local_10;
  return param_1;
}



void FUN_1001ca80(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1001caf0;
  local_10 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_10;
  FUN_1001dce4();
  local_8 = 0xffffffff;
  FUN_10009420();
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_1001cb00(int param_1)

{
  char cVar1;
  undefined1 auStackY_d0 [128];
  undefined4 local_24;
  int local_20;
  uint local_1c;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1001cc30;
  local_10 = ExceptionList;
  local_14 = auStackY_d0 + 0x8c;
  local_8 = 0;
  local_1c = 0;
  ExceptionList = &local_10;
  do {
    if (*(int *)(param_1 + 0x14 + local_1c * 4) != 0) {
      FUN_10012c00();
    }
    local_1c = local_1c + 1 & 0xff;
  } while (local_1c < 0xff);
  local_8 = 0xffffffff;
  cVar1 = FUN_10009950();
  if (cVar1 != '\0') {
    local_8 = 2;
    local_20 = FUN_100095e0(&DAT_10118290,10000,&local_24);
    if (local_20 == 0xc) {
      FUN_1001d6d4(&DAT_10118290,local_24);
    }
    FUN_10009970();
    local_8 = 0xffffffff;
  }
  FUN_10026ea0();
  ExceptionList = local_10;
  return;
}



void FUN_1001cc40(int param_1)

{
  char cVar1;
  int iVar2;
  undefined1 auStackY_d8 [128];
  undefined4 local_30;
  undefined4 local_2c;
  undefined4 *local_28;
  int local_24;
  int local_20;
  undefined4 *local_1c;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1001cde0;
  local_10 = ExceptionList;
  local_14 = auStackY_d8 + 0x8c;
  ExceptionList = &local_10;
  local_20 = FUN_1000e070();
  local_20 = (uint)(param_1 * 1000) / 0x204cc + local_20;
  local_8 = 0;
  FUN_10026ea0();
  cVar1 = FUN_10009950();
  if (cVar1 != '\0') {
    local_28 = &local_30;
    iVar2 = FUN_100096d0(local_28);
    while (iVar2 == 0xc) {
      FUN_100095e0(&DAT_1011a9a0,10000,local_28);
      (**(code **)(**(int **)(local_24 + 4) + 8))(&DAT_1011a9a0,local_30);
      iVar2 = FUN_100096d0(local_28);
    }
    FUN_10009970();
  }
  local_1c = &local_2c;
  do {
    iVar2 = (**(code **)(**(int **)(local_24 + 4) + 4))(&DAT_1011a9a0,10000,local_1c);
    if (iVar2 != 0xc) {
      ExceptionList = local_10;
      return;
    }
    FUN_1001cdf0(&DAT_1011a9a0,local_2c);
    iVar2 = FUN_1000e070();
  } while (iVar2 <= local_20);
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_1001cdf0(int param_1,byte *param_2,int param_3)

{
  byte bVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined1 auStackY_100 [128];
  undefined1 local_58 [8];
  undefined1 local_50;
  undefined1 local_4f [7];
  undefined1 local_48;
  undefined1 local_47;
  undefined1 local_44;
  undefined1 local_43;
  undefined1 local_40 [8];
  undefined1 local_38 [12];
  undefined1 local_2c;
  undefined1 local_2b;
  undefined1 *local_28;
  undefined1 *local_24;
  int local_20;
  undefined1 *local_1c;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1001d310;
  local_10 = ExceptionList;
  local_14 = auStackY_100 + 0x8c;
  local_24 = local_40;
  bVar1 = *param_2;
  local_1c = &local_48;
  local_28 = &local_50;
  if (bVar1 - 5 < 0x4a) {
    local_20 = param_1;
    switch(bVar1) {
    case 5:
      ExceptionList = &local_10;
      local_14 = auStackY_100 + 0x8c;
      FUN_1001de00(0x12);
      break;
    default:
      break;
    case 0x32:
      if (*(char *)(DAT_1011d0b0 + 0x374) == '\0') {
        ExceptionList = &local_10;
        *(undefined1 *)(DAT_1011d0b0 + 0x374) = 1;
        local_14 = auStackY_100 + 0x8c;
        FUN_1000e030(local_38);
        local_8 = 0;
        FUN_1000a530(local_24);
        FUN_1001df30(0x40,local_24,5);
        local_8 = 0xffffffff;
        FUN_1000a300();
      }
      else {
        ExceptionList = &local_10;
        local_14 = auStackY_100 + 0x8c;
        FUN_1001de00(0x17);
      }
      break;
    case 0x33:
      *(undefined1 *)(DAT_1011d0b0 + 0x374) = 0;
      break;
    case 0x34:
      ExceptionList = &local_10;
      local_14 = auStackY_100 + 0x8c;
      FUN_1001d694(param_2,param_3);
      break;
    case 0x35:
      ExceptionList = &local_10;
      local_14 = auStackY_100 + 0x8c;
      FUN_1001d7f4(param_2[1]);
      break;
    case 0x36:
      ExceptionList = &local_10;
      local_14 = auStackY_100 + 0x8c;
      FUN_1001d694(param_2,param_3);
      break;
    case 0x37:
      ExceptionList = &local_10;
      local_14 = auStackY_100 + 0x8c;
      FUN_1001d694(param_2,param_3);
      break;
    case 0x38:
      if (*(char *)(DAT_1011d0b0 + 0x374) == '\0') {
        ExceptionList = &local_10;
        local_14 = auStackY_100 + 0x8c;
        FUN_1001de00(0x12);
      }
      else {
        ExceptionList = &local_10;
        local_14 = auStackY_100 + 0x8c;
        FUN_1001d694(param_2,param_3);
      }
      break;
    case 0x39:
      ExceptionList = &local_10;
      local_14 = auStackY_100 + 0x8c;
      FUN_1001d694(param_2,param_3);
      break;
    case 0x3a:
      ExceptionList = &local_10;
      local_14 = auStackY_100 + 0x8c;
      FUN_1001d694(param_2,param_3);
      break;
    case 0x3b:
      ExceptionList = &local_10;
      local_14 = auStackY_100 + 0x8c;
      cVar2 = FUN_1001c4f4();
      if (cVar2 == '\0') {
        local_2b = 0;
      }
      else {
        iVar3 = FUN_10007e00();
        if (iVar3 % 0x300 < 0x60) {
          local_2b = 2;
        }
        else {
          iVar3 = FUN_10007e00();
          if (iVar3 % 0xc0 < 0x60) {
            local_2b = 1;
          }
          else {
            local_2b = 0;
          }
        }
      }
      local_2c = 1;
      FUN_1001d4c4(0x4c,&local_2c,2);
      iVar3 = local_20;
      uVar5 = 0;
      do {
        if (*(int *)(iVar3 + 0x14 + uVar5 * 4) != 0) {
          FUN_10013db0();
        }
        uVar5 = uVar5 + 1 & 0xff;
      } while (uVar5 < 0xff);
      local_20 = iVar3;
      if (*(char *)(iVar3 + 0x424) == '\0') {
        iVar3 = FUN_10007210();
        cVar2 = FUN_100180a0(iVar3);
        if (cVar2 == '\0') {
          FUN_1001df80(0x46);
          FUN_100097b0();
          *(undefined1 *)(local_20 + 0x424) = 0;
        }
        else {
          DAT_1011d0b8 = 0x45;
          FUN_10009770(&DAT_1011d0b9);
          (**(code **)(**(int **)(local_20 + 4) + 8))(&DAT_1011d0b8,iVar3 + 1);
        }
      }
      else {
        FUN_1001df80(0x46);
        FUN_100097b0();
        *(undefined1 *)(local_20 + 0x424) = 0;
      }
      break;
    case 0x3c:
      switch(param_2[1]) {
      case 0:
        local_44 = 0;
        local_43 = *(undefined1 *)(param_1 + 8);
        ExceptionList = &local_10;
        local_14 = auStackY_100 + 0x8c;
        FUN_1001df30(0x4c,&local_44,2);
        break;
      case 1:
        local_48 = 0;
        local_47 = *(undefined1 *)(param_1 + 9);
        ExceptionList = &local_10;
        local_14 = auStackY_100 + 0x8c;
        FUN_1001df30(0x4c,local_1c,2);
        break;
      case 2:
        local_50 = 2;
        ExceptionList = &local_10;
        local_14 = auStackY_100 + 0x8c;
        FUN_100040e0(local_4f,*(undefined4 *)(param_1 + 0xc));
        FUN_1001df30(0x4c,local_28,5);
      }
      break;
    case 0x3d:
      ExceptionList = &local_10;
      local_14 = auStackY_100 + 0x8c;
      FUN_100181f0(local_58);
      FUN_1001df30(0x4d,local_58,7);
      break;
    case 0x3e:
      ExceptionList = &local_10;
      local_14 = auStackY_100 + 0x8c;
      FUN_1001df80(0x47);
      break;
    case 0x3f:
      ExceptionList = &local_10;
      local_14 = auStackY_100 + 0x8c;
      FUN_1001d694(param_2,param_3);
      break;
    case 0x4c:
      switch(param_2[1]) {
      case 0:
        *(byte *)(param_1 + 8) = param_2[2];
        break;
      case 1:
        *(byte *)(param_1 + 9) = param_2[2];
        break;
      case 2:
        ExceptionList = &local_10;
        local_14 = auStackY_100 + 0x8c;
        uVar4 = FUN_100040b0(param_2 + 2,*(undefined4 *)(&DAT_10153164 + (uint)bVar1 * 4));
        *(undefined4 *)(local_20 + 0xc) = uVar4;
        break;
      case 3:
      case 4:
      case 5:
        break;
      case 6:
        *(byte *)(param_1 + 0x10) = param_2[2];
      }
      break;
    case 0x4d:
      ExceptionList = &local_10;
      local_14 = auStackY_100 + 0x8c;
      FUN_10018230(param_2 + 1);
      break;
    case 0x4e:
      ExceptionList = &local_10;
      FUN_10011ed0(param_2 + 2,param_3 + -2);
    }
  }
  ExceptionList = local_10;
  return;
}



void FUN_1001d320(undefined4 param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_10018100(param_1,&DAT_1011f7c8);
  FUN_10009520(&DAT_1011f7c8,uVar1);
  FUN_10026ea0();
  return;
}



void FUN_1001d324(undefined4 param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_10018100(param_1,&DAT_1011f7c8);
  FUN_10009520(&DAT_1011f7c8,uVar1);
  FUN_10026ea0();
  return;
}



void FUN_1001d374(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  
  uVar1 = FUN_10018110(param_1,param_2,param_3,&DAT_1011f7c8);
  FUN_10009520(&DAT_1011f7c8,uVar1);
  FUN_10026ea0();
  return;
}



void FUN_1001d3d0(undefined1 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  
  uVar1 = FUN_10018140(param_1,param_2,param_3,param_4,&DAT_1011f7c8);
  FUN_10009520(&DAT_1011f7c8,uVar1);
  FUN_10026ea0();
  return;
}



void __thiscall FUN_1001d440(int param_1,undefined4 param_2)

{
  char cVar1;
  undefined4 uVar2;
  
  if (*(char *)(param_1 + 0x424) == '\0') {
    uVar2 = FUN_10018100(param_2,&DAT_1011d0b8);
    cVar1 = FUN_10009740(uVar2);
    if (cVar1 == '\0') {
      *(undefined1 *)(param_1 + 0x424) = 1;
      return;
    }
    FUN_10009520(&DAT_1011d0b8,uVar2);
  }
  return;
}



void __thiscall FUN_1001d4c4(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  char cVar1;
  undefined4 uVar2;
  
  if (*(char *)(param_1 + 0x424) == '\0') {
    uVar2 = FUN_10018110(param_2,param_3,param_4,&DAT_1011d0b8);
    cVar1 = FUN_10009740(uVar2);
    if (cVar1 == '\0') {
      *(undefined1 *)(param_1 + 0x424) = 1;
      return;
    }
    FUN_10009520(&DAT_1011d0b8,uVar2);
  }
  return;
}



void __thiscall
FUN_1001d550(int param_1,undefined1 param_2,undefined4 param_3,undefined4 param_4,int param_5)

{
  char cVar1;
  undefined4 uVar2;
  
  if (*(char *)(param_1 + 0x424) == '\0') {
    uVar2 = FUN_10018140(param_2,param_3,param_4,param_5,&DAT_1011d0b8);
    cVar1 = FUN_10009740(param_5 + 3);
    if (cVar1 == '\0') {
      *(undefined1 *)(param_1 + 0x424) = 1;
      return;
    }
    FUN_10009520(&DAT_1011d0b8,uVar2);
  }
  return;
}



void __thiscall
FUN_1001d554(int param_1,undefined1 param_2,undefined4 param_3,undefined4 param_4,int param_5)

{
  char cVar1;
  undefined4 uVar2;
  
  if (*(char *)(param_1 + 0x424) == '\0') {
    uVar2 = FUN_10018140(param_2,param_3,param_4,param_5,&DAT_1011d0b8);
    cVar1 = FUN_10009740(param_5 + 3);
    if (cVar1 == '\0') {
      *(undefined1 *)(param_1 + 0x424) = 1;
      return;
    }
    FUN_10009520(&DAT_1011d0b8,uVar2);
  }
  return;
}



void __thiscall
FUN_1001d5f0(int param_1,undefined1 param_2,undefined1 param_3,undefined1 param_4,undefined4 param_5
            ,undefined4 param_6)

{
  char cVar1;
  undefined4 uVar2;
  
  if (*(char *)(param_1 + 0x424) == '\0') {
    uVar2 = FUN_10018180(param_2,param_3,param_4,param_5,param_6,&DAT_1011d0b8);
    cVar1 = FUN_10009740(uVar2);
    if (cVar1 == '\0') {
      *(undefined1 *)(param_1 + 0x424) = 1;
      return;
    }
    FUN_10009520(&DAT_1011d0b8,uVar2);
  }
  return;
}



void FUN_1001d690(undefined4 param_1,undefined4 param_2)

{
  FUN_10009520(param_1,param_2);
  FUN_10026ea0();
  return;
}



void FUN_1001d694(undefined4 param_1,undefined4 param_2)

{
  FUN_10009520(param_1,param_2);
  FUN_10026ea0();
  return;
}



void FUN_1001d6d4(undefined1 *param_1,int param_2)

{
  switch(*param_1) {
  case 0x34:
    FUN_1001d840(param_1 + 1);
    return;
  case 0x35:
  case 0x3b:
  case 0x3c:
  case 0x3d:
  case 0x3e:
  case 0x40:
  case 0x41:
  case 0x42:
  case 0x43:
  case 0x44:
  case 0x45:
  case 0x46:
  case 0x47:
  case 0x48:
  case 0x49:
  case 0x4a:
  case 0x4b:
  case 0x4c:
  case 0x4d:
    break;
  case 0x36:
    FUN_1001dc64(param_1[1]);
    FUN_1001d324(0x42);
    return;
  case 0x37:
    FUN_1001d990(param_1 + 1);
    return;
  case 0x38:
    FUN_1001da70(param_1 + 1);
    return;
  case 0x39:
    FUN_1001db60(param_1 + 1);
    return;
  case 0x3a:
    FUN_1001dc14(param_1 + 1);
    return;
  case 0x3f:
    FUN_1001d324(0x48);
    return;
  case 0x4e:
    FUN_10012940(param_1 + 2,param_2 + -2);
  }
  return;
}



void __thiscall FUN_1001d7f4(int param_1,byte param_2)

{
  if (param_2 == 0xff) {
    FUN_1001bda4(0);
    return;
  }
  FUN_1001bda4(*(undefined4 *)(param_1 + 0x14 + (uint)param_2 * 4));
  return;
}



void __thiscall FUN_1001d840(int param_1,undefined4 param_2)

{
  undefined2 uVar1;
  void *pvVar2;
  undefined1 auStackY_d8 [128];
  undefined1 local_2c [4];
  undefined4 local_28;
  undefined1 *local_24;
  void *local_20;
  uint local_1c;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1001d980;
  local_10 = ExceptionList;
  local_14 = auStackY_d8 + 0x8c;
  local_24 = local_2c;
  ExceptionList = &local_10;
  uVar1 = FUN_10004060(param_2);
  local_28 = FUN_1001a860(uVar1);
  local_8 = 0;
  local_1c = 0;
  do {
    if (*(int *)(param_1 + 0x14 + local_1c * 4) == 0) goto LAB_1001d8b6;
    local_1c = local_1c + 1 & 0xff;
  } while (local_1c < 0xff);
  local_1c = 0xff;
LAB_1001d8b6:
  if (local_1c == 0xff) {
    FUN_1001dfc0(0x11);
  }
  else {
    local_20 = operator_new(0x1910);
    if (local_20 == (void *)0x0) {
      pvVar2 = (void *)0x0;
    }
    else {
      FUN_10011350(local_1c,local_28);
      pvVar2 = local_20;
    }
    *(void **)(param_1 + 0x14 + local_1c * 4) = pvVar2;
    local_2c[0] = (undefined1)local_1c;
    FUN_1001d374(0x41,local_24,1);
  }
  ExceptionList = local_10;
  return;
}



void FUN_1001d990(undefined4 param_1)

{
  undefined1 auStackY_3a4 [128];
  undefined1 local_304 [748];
  undefined1 *local_18;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1001da60;
  local_10 = ExceptionList;
  local_14 = auStackY_3a4 + 0x88;
  local_8 = 0;
  local_18 = local_304;
  ExceptionList = &local_10;
  FUN_10018560(param_1);
  local_8 = 1;
  FUN_1001a030(local_18);
  FUN_1001d324(0x43);
  local_8 = 0;
  FUN_100185f0();
  ExceptionList = local_10;
  return;
}



void FUN_1001da70(undefined4 param_1)

{
  undefined2 uVar1;
  undefined1 auStackY_3a4 [128];
  undefined1 local_304 [748];
  undefined1 *local_18;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1001db50;
  local_10 = ExceptionList;
  local_14 = auStackY_3a4 + 0x88;
  ExceptionList = &local_10;
  uVar1 = FUN_10004060(param_1);
  local_8 = 0;
  local_18 = local_304;
  FUN_100184e0(uVar1);
  local_8 = 1;
  FUN_1001a030(local_18);
  FUN_1001d324(0x43);
  local_8 = 0;
  FUN_100185f0();
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_1001db60(int param_1,undefined4 param_2)

{
  undefined2 uVar1;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1001dc00;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  uVar1 = FUN_10004060(param_2);
  local_8 = 0;
  *(undefined4 *)(param_1 + 0x428) = 0;
  FUN_1001a6b0(uVar1);
  FUN_1001d324(0x44);
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_1001dc14(int param_1,undefined4 param_2)

{
  undefined2 uVar1;
  int iVar2;
  
  uVar1 = FUN_10004060(param_2);
  iVar2 = FUN_1001a860(uVar1);
  if (iVar2 != 0) {
    *(undefined4 *)(param_1 + 0x42c) = 0;
    *(undefined4 *)(param_1 + 0x428) = *(undefined4 *)(iVar2 + 0xb8);
  }
  return;
}



void __thiscall FUN_1001dc64(int param_1,byte param_2)

{
  int iVar1;
  
  FUN_10009480();
  iVar1 = *(int *)(param_1 + 0x14 + (uint)param_2 * 4);
  if (iVar1 == *(int *)(DAT_1011d0b4 + 0x170)) {
    FUN_1001bda4(0);
  }
  if (iVar1 == *(int *)(DAT_1011d0b4 + 0x16c)) {
    FUN_1001bd24(0);
  }
  *(undefined4 *)(param_1 + 0x14 + (uint)param_2 * 4) = 0;
  FUN_100094a0();
  if (iVar1 != 0) {
    FUN_1001aa80(1);
  }
  return;
}



void __fastcall FUN_1001dce4(int param_1)

{
  FUN_1001ec00();
  if (*(int *)(param_1 + 0x420) != 0) {
    FUN_1001a990(1);
  }
  *(undefined4 *)(param_1 + 0x420) = 0;
  if (*(int *)(param_1 + 0x418) != 0) {
    FUN_1001a9c0(1);
  }
  *(undefined4 *)(param_1 + 0x418) = 0;
  if (*(int *)(param_1 + 0x414) != 0) {
    FUN_1001a9c0(1);
  }
  *(undefined4 *)(param_1 + 0x414) = 0;
  if (*(int *)(param_1 + 0x410) != 0) {
    FUN_1001a9f0(1);
  }
  *(undefined4 *)(param_1 + 0x410) = 0;
  if (*(int *)(param_1 + 0x41c) != 0) {
    FUN_1001a9f0(1);
  }
  *(undefined4 *)(param_1 + 0x41c) = 0;
  if (*(int *)(param_1 + 0x418) != 0) {
    FUN_1001a9c0(1);
  }
  *(undefined4 *)(param_1 + 0x418) = 0;
  if (*(undefined4 **)(param_1 + 4) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 4))(1);
  }
  *(undefined4 *)(param_1 + 4) = 0;
  if (DAT_1011d0b4 != 0) {
    FUN_1001aa50(1);
  }
  DAT_1011d0b4 = 0;
  return;
}



void __fastcall FUN_1001ddf0(int param_1)

{
  *(undefined1 *)(param_1 + 0x424) = 1;
  return;
}



void __thiscall FUN_1001de00(int param_1,undefined1 param_2)

{
  undefined4 uVar1;
  undefined1 local_c [8];
  
  local_c[0] = param_2;
  uVar1 = FUN_10018110(0x4b,local_c,1,&DAT_1011d0b8);
  (**(code **)(**(int **)(param_1 + 4) + 8))(&DAT_1011d0b8,uVar1);
  return;
}



void __thiscall
FUN_1001de60(int param_1,undefined1 param_2,undefined1 param_3,undefined1 param_4,undefined4 param_5
            ,undefined4 param_6)

{
  undefined4 uVar1;
  
  uVar1 = FUN_10018180(param_2,param_3,param_4,param_5,param_6,&DAT_1011d0b8);
  (**(code **)(**(int **)(param_1 + 4) + 8))(&DAT_1011d0b8,uVar1);
  return;
}



void __thiscall
FUN_1001ded0(int param_1,undefined1 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  undefined4 uVar1;
  
  uVar1 = FUN_10018140(param_2,param_3,param_4,param_5,&DAT_1011d0b8);
  (**(code **)(**(int **)(param_1 + 4) + 8))(&DAT_1011d0b8,uVar1);
  return;
}



void __thiscall FUN_1001df30(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  
  uVar1 = FUN_10018110(param_2,param_3,param_4,&DAT_1011d0b8);
  (**(code **)(**(int **)(param_1 + 4) + 8))(&DAT_1011d0b8,uVar1);
  return;
}



void __thiscall FUN_1001df80(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  uVar1 = FUN_10018100(param_2,&DAT_1011d0b8);
  (**(code **)(**(int **)(param_1 + 4) + 8))(&DAT_1011d0b8,uVar1);
  return;
}



void FUN_1001dfc0(undefined1 param_1)

{
  undefined4 uVar1;
  undefined1 local_c [8];
  
  local_c[0] = param_1;
  uVar1 = FUN_10018110(0x4b,local_c,1,&DAT_1011f7c8);
  FUN_10009520(&DAT_1011f7c8,uVar1);
  FUN_10026ea0();
  return;
}



void __thiscall FUN_1001e030(undefined4 *param_1,undefined4 param_2)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1001e0a0;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_1000e1f0(param_2);
  *param_1 = &PTR_LAB_10033c34;
  *(undefined1 *)(param_1 + 0xdd) = 0;
  param_1[0xdc] = 0;
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_1001e0b0(int param_1)

{
  if (*(char *)(param_1 + 0x160) != '\0') {
    if (*(int *)(param_1 + 0x16c) != 0) {
      FUN_100218a0();
      FUN_1001be14(*(undefined4 *)(param_1 + 0x16c),0);
    }
    FUN_10007ef0();
  }
  return;
}



void __thiscall FUN_1001e100(int param_1,int param_2)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0x15c) == 0x2e) {
    if (param_2 == *(int *)(param_1 + 0x16c)) {
      *(undefined1 *)(param_1 + 0x151) = 2;
    }
  }
  else {
    FUN_100218a0();
    FUN_1001be14(param_2,0);
    if (*(char *)(param_1 + 0x160) == '\0') {
      iVar1 = FUN_1001f870();
      FUN_1001f980((iVar1 / 0x300) * 0x300);
      return;
    }
  }
  return;
}



void FUN_1001e190(undefined4 param_1)

{
  void *pvVar1;
  
  pvVar1 = operator_new(0x378);
  if (pvVar1 == (void *)0x0) {
    pvVar1 = (void *)0x0;
  }
  else {
    FUN_1001e030(param_1);
  }
  DAT_1011d0b0 = pvVar1;
  return;
}



undefined4 * __fastcall FUN_1001e290(undefined4 *param_1)

{
  *param_1 = &PTR_LAB_10033d54;
  param_1[1] = 0;
  (*(code *)PTR_FUN_10033d58)();
  return param_1;
}



undefined4 * __fastcall FUN_1001e294(undefined4 *param_1)

{
  *param_1 = &PTR_LAB_10033d54;
  param_1[1] = 0;
  (*(code *)PTR_FUN_10033d58)();
  return param_1;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void __thiscall
FUN_1001e2b0(int param_1,int param_2,float param_3,undefined4 param_4,undefined4 param_5)

{
  float fVar1;
  undefined4 uVar2;
  
  if (param_2 != 0) {
    *(int *)(param_1 + 4) = param_2;
  }
  if (*(int *)(param_1 + 4) != 0) {
    fVar1 = (float)_DAT_10153640;
    *(undefined4 *)(param_1 + 0x14) = param_5;
    *(undefined4 *)(param_1 + 0x1c) = param_4;
    *(float *)(param_1 + 0x18) = param_3 * fVar1;
    uVar2 = FUN_1000aa60();
    *(undefined4 *)(param_1 + 0xc) = uVar2;
    uVar2 = FUN_1000aa80();
    *(undefined4 *)(param_1 + 0x10) = uVar2;
    *(undefined1 *)(param_1 + 8) = 1;
  }
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void __thiscall
FUN_1001e2b4(int param_1,int param_2,float param_3,undefined4 param_4,undefined4 param_5)

{
  float fVar1;
  undefined4 uVar2;
  
  if (param_2 != 0) {
    *(int *)(param_1 + 4) = param_2;
  }
  if (*(int *)(param_1 + 4) != 0) {
    fVar1 = (float)_DAT_10153640;
    *(undefined4 *)(param_1 + 0x14) = param_5;
    *(undefined4 *)(param_1 + 0x1c) = param_4;
    *(float *)(param_1 + 0x18) = param_3 * fVar1;
    uVar2 = FUN_1000aa60();
    *(undefined4 *)(param_1 + 0xc) = uVar2;
    uVar2 = FUN_1000aa80();
    *(undefined4 *)(param_1 + 0x10) = uVar2;
    *(undefined1 *)(param_1 + 8) = 1;
  }
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void __thiscall FUN_1001e300(int param_1,int param_2)

{
  float fVar1;
  short sVar2;
  bool bVar3;
  float fVar4;
  float fVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  
  if (*(char *)(param_1 + 8) != '\0') {
    if (*(int *)(param_1 + 0x14) == 0) {
      fVar1 = *(float *)(param_1 + 0x1c);
    }
    else {
      *(int *)(param_1 + 0x14) = *(int *)(param_1 + 0x14) + -1;
      fVar1 = _DAT_10153648;
    }
    iVar9 = 0x1f;
    iVar7 = param_2 + -4;
    iVar6 = *(int *)(param_1 + 0xc) + -2;
    fVar4 = *(float *)(param_1 + 0x18);
    do {
      iVar8 = iVar6;
      iVar9 = iVar9 + -1;
      fVar5 = fVar4 * fVar1;
      sVar2 = *(short *)(iVar8 + 2);
      *(float *)(iVar7 + 8) = (float)(int)*(short *)(iVar8 + 4) * fVar4 + *(float *)(iVar7 + 8);
      *(float *)(iVar7 + 4) = (float)(int)sVar2 * fVar4 + *(float *)(iVar7 + 4);
      iVar7 = iVar7 + 8;
      iVar6 = iVar8 + 4;
      fVar4 = fVar5;
    } while (iVar9 != -1);
    bVar3 = fVar5 < _DAT_1015364c;
    *(float *)(param_1 + 0x18) = fVar5;
    if (bVar3) {
      *(undefined1 *)(param_1 + 8) = 0;
    }
    *(int *)(param_1 + 0xc) = iVar8 + 6;
    iVar7 = *(int *)(param_1 + 0x10) + -0x40;
    *(int *)(param_1 + 0x10) = iVar7;
    if (iVar7 < 1) {
      *(undefined1 *)(param_1 + 8) = 0;
    }
  }
  return;
}



void __thiscall FUN_1001e3c0(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x14) = param_2;
  return;
}



void __thiscall FUN_1001e3d0(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x1c) = param_2;
  return;
}



undefined4 * __fastcall FUN_1001e3e0(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1001e450;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_1001e294();
  param_1[8] = 0;
  param_1[9] = 0;
  *param_1 = &PTR_LAB_10033d64;
  ExceptionList = local_10;
  return param_1;
}



void __fastcall FUN_1001e460(undefined4 *param_1)

{
  *param_1 = &PTR_LAB_10033d54;
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void __thiscall FUN_1001e4d0(int param_1,int param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  bool bVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  
  if (*(char *)(param_1 + 8) != '\0') {
    if (*(int *)(param_1 + 0x14) == 0) {
      fVar1 = *(float *)(param_1 + 0x1c);
    }
    else {
      *(int *)(param_1 + 0x14) = *(int *)(param_1 + 0x14) + -1;
      fVar1 = _DAT_101536a8;
    }
    iVar11 = 0x1f;
    fVar2 = *(float *)(param_1 + 0x24);
    fVar3 = *(float *)(param_1 + 0x20);
    iVar9 = param_2 + -4;
    iVar8 = *(int *)(param_1 + 0xc) + -2;
    fVar5 = *(float *)(param_1 + 0x18);
    do {
      iVar10 = iVar8;
      iVar11 = iVar11 + -1;
      fVar7 = fVar5 * fVar1;
      fVar6 = (float)(int)*(short *)(iVar10 + 2) * fVar5 + fVar2 * fVar3;
      fVar2 = (float)(int)*(short *)(iVar10 + 4) * fVar5 + fVar3 * fVar6;
      *(float *)(iVar9 + 4) = fVar6 + *(float *)(iVar9 + 4);
      *(float *)(iVar9 + 8) = *(float *)(iVar9 + 8) + fVar2;
      iVar9 = iVar9 + 8;
      iVar8 = iVar10 + 4;
      fVar5 = fVar7;
    } while (iVar11 != -1);
    *(float *)(param_1 + 0x24) = fVar2;
    bVar4 = fVar7 < _DAT_101536ac;
    *(float *)(param_1 + 0x18) = fVar7;
    if (bVar4) {
      *(undefined1 *)(param_1 + 8) = 0;
    }
    *(int *)(param_1 + 0xc) = iVar10 + 6;
    iVar9 = *(int *)(param_1 + 0x10) + -0x40;
    *(int *)(param_1 + 0x10) = iVar9;
    if (iVar9 < 1) {
      *(undefined1 *)(param_1 + 8) = 0;
    }
  }
  return;
}



void __thiscall
FUN_1001e5c0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6)

{
  FUN_1001e2b4(param_2,param_3,param_4,param_5);
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 0x20) = param_6;
  return;
}



undefined4 * __fastcall FUN_1001e610(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1001e680;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_1001e294();
  param_1[9] = 0;
  *param_1 = &PTR_LAB_10033d74;
  param_1[8] = 0;
  param_1[10] = 0;
  ExceptionList = local_10;
  return param_1;
}



void __fastcall FUN_1001e690(undefined4 *param_1)

{
  *param_1 = &PTR_LAB_10033d54;
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void __thiscall FUN_1001e700(int param_1,int param_2)

{
  float fVar1;
  float fVar2;
  undefined4 uVar3;
  float fVar4;
  float fVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  
  if (*(char *)(param_1 + 8) != '\0') {
    iVar10 = *(int *)(param_1 + 0x18);
    uVar3 = *(undefined4 *)(param_1 + 0x18);
    fVar1 = *(float *)(param_1 + 0x18);
    if (*(int *)(param_1 + 0x14) == 0) {
      fVar2 = *(float *)(param_1 + 0x1c);
    }
    else {
      *(int *)(param_1 + 0x14) = *(int *)(param_1 + 0x14) + -1;
      fVar2 = _DAT_10153710;
    }
    iVar12 = 0x1f;
    iVar6 = *(int *)(param_1 + 0x20) + -2;
    iVar9 = param_2 + -4;
    iVar7 = *(int *)(param_1 + 0xc) + -2;
    fVar4 = *(float *)(param_1 + 0x24);
    do {
      iVar11 = iVar7;
      iVar8 = iVar6;
      iVar12 = iVar12 + -1;
      fVar5 = fVar4 * fVar2;
      *(float *)(iVar9 + 4) =
           ((float)(int)*(short *)(iVar8 + 2) * fVar4 + (float)(int)*(short *)(iVar11 + 2)) * fVar1
           + *(float *)(iVar9 + 4);
      *(float *)(iVar9 + 8) =
           ((float)(int)*(short *)(iVar11 + 4) + (float)(int)*(short *)(iVar8 + 4) * fVar4) * fVar1
           + *(float *)(iVar9 + 8);
      iVar6 = iVar8 + 4;
      iVar9 = iVar9 + 8;
      iVar7 = iVar11 + 4;
      fVar4 = fVar5;
    } while (iVar12 != -1);
    *(float *)(param_1 + 0x24) = fVar5;
    *(undefined4 *)(param_1 + 0x18) = uVar3;
    if (iVar10 < 0x3300d959) {
      *(undefined1 *)(param_1 + 8) = 0;
    }
    iVar10 = *(int *)(param_1 + 0x10) + -0x40;
    *(int *)(param_1 + 0x10) = iVar10;
    *(int *)(param_1 + 0x20) = iVar8 + 6;
    *(int *)(param_1 + 0xc) = iVar11 + 6;
    if (iVar10 < 1) {
      *(undefined1 *)(param_1 + 8) = 0;
    }
  }
  return;
}



void __thiscall
FUN_1001e820(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,int param_6,undefined4 param_7)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  
  FUN_1001e2b4(param_2,param_3,param_4,param_5);
  if (param_6 != 0) {
    *(int *)(param_1 + 0x28) = param_6;
  }
  if (*(int *)(param_1 + 0x28) != 0) {
    *(undefined4 *)(param_1 + 0x24) = param_7;
    uVar1 = FUN_1000aa60();
    *(undefined4 *)(param_1 + 0x20) = uVar1;
    iVar2 = FUN_1000aa80();
    iVar3 = FUN_1000aa80();
    if (iVar2 < iVar3) {
      uVar1 = FUN_1000aa80();
      *(undefined4 *)(param_1 + 0x10) = uVar1;
    }
    else {
      uVar1 = FUN_1000aa80();
      *(undefined4 *)(param_1 + 0x10) = uVar1;
    }
    *(undefined1 *)(param_1 + 8) = 1;
  }
  return;
}



void __fastcall FUN_1001e8b0(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1001e920;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_1001e294();
  *param_1 = &PTR_LAB_10033d84;
  param_1[0xb] = 0;
  param_1[10] = 0;
  param_1[9] = 0;
  param_1[8] = 0;
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_1001e930(undefined4 *param_1)

{
  *param_1 = &PTR_LAB_10033d54;
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void __thiscall FUN_1001e9a0(int param_1,int param_2)

{
  float fVar1;
  int iVar2;
  int iVar3;
  float fVar4;
  float fVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  int iVar10;
  
  if (*(char *)(param_1 + 8) != '\0') {
    param_2 = param_2 + -4;
    iVar2 = *(int *)(param_1 + 0x24);
    uVar9 = *(uint *)(param_1 + 0x28);
    iVar3 = *(int *)(param_1 + 0x20);
    if (*(int *)(param_1 + 0x14) == 0) {
      fVar1 = *(float *)(param_1 + 0x1c);
    }
    else {
      *(int *)(param_1 + 0x14) = *(int *)(param_1 + 0x14) + -1;
      fVar1 = _DAT_10153768;
    }
    iVar10 = 0x1f;
    fVar4 = *(float *)(param_1 + 0x18);
    do {
      iVar7 = (int)*(short *)(iVar3 + (uVar9 >> 8) * 2);
      iVar10 = iVar10 + -1;
      uVar6 = uVar9 + iVar2;
      uVar8 = uVar6 >> 8;
      *(float *)(param_2 + 4) =
           (float)((iVar7 + ((int)((uVar9 & 0xff) *
                                  (*(short *)(iVar3 + 2 + (uVar9 >> 8) * 2) - iVar7)) >> 8)) *
                   0x10000 >> 0x10) * fVar4 + *(float *)(param_2 + 4);
      fVar5 = fVar4 * fVar1;
      iVar7 = (int)*(short *)(iVar3 + uVar8 * 2);
      *(float *)(param_2 + 8) =
           (float)((iVar7 + ((int)((uVar6 & 0xff) * (*(short *)(iVar3 + 2 + uVar8 * 2) - iVar7)) >>
                            8)) * 0x10000 >> 0x10) * fVar4 + *(float *)(param_2 + 8);
      uVar9 = uVar6 + iVar2;
      param_2 = param_2 + 8;
      fVar4 = fVar5;
    } while (iVar10 != -1);
    *(float *)(param_1 + 0x18) = fVar5;
    *(uint *)(param_1 + 0x28) = uVar9;
    *(uint *)(param_1 + 0xc) = iVar3 + 2 + uVar8 * 2;
    if (*(uint *)(param_1 + 0x2c) < uVar9) {
      *(undefined1 *)(param_1 + 8) = 0;
    }
  }
  return;
}



void __thiscall
FUN_1001ead0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6)

{
  undefined4 uVar1;
  int iVar2;
  
  FUN_1001e2b4(param_2,param_3,param_4,param_5);
  *(undefined4 *)(param_1 + 0x24) = param_6;
  uVar1 = FUN_1000aa60();
  *(undefined4 *)(param_1 + 0x20) = uVar1;
  *(undefined4 *)(param_1 + 0x28) = 0;
  iVar2 = FUN_1000aa80();
  *(int *)(param_1 + 0x2c) = iVar2 << 8;
  return;
}



void __fastcall FUN_1001eb30(int param_1)

{
  *(undefined1 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0;
  return;
}



void __thiscall FUN_1001eb40(undefined4 param_1,uint param_2)

{
  FUN_10014550();
  if ((param_2 & 1) == 0) {
    return;
  }
  FUN_1002dde0(param_1);
  return;
}



void __thiscall FUN_1001eb70(undefined4 param_1,uint param_2)

{
  FUN_10021770();
  if ((param_2 & 1) == 0) {
    return;
  }
  FUN_1002dde0(param_1);
  return;
}



void __thiscall FUN_1001eba0(undefined4 param_1,uint param_2)

{
  FUN_10021724();
  if ((param_2 & 1) == 0) {
    return;
  }
  FUN_1002dde0(param_1);
  return;
}



void __thiscall FUN_1001ebd0(undefined4 param_1,uint param_2)

{
  FUN_100143a0();
  if ((param_2 & 1) == 0) {
    return;
  }
  FUN_1002dde0(param_1);
  return;
}



void FUN_1001ec00(void)

{
  if (DAT_101245f0 != 0) {
    FUN_1001eba0(1);
  }
  DAT_101245f0 = 0;
  if (DAT_10100230 != 0) {
    FUN_1001ebd0(1);
  }
  DAT_10100230 = 0;
  return;
}



undefined4 * __thiscall FUN_1001ec50(undefined4 *param_1,undefined4 param_2)

{
  int iVar1;
  void *pvVar2;
  int iVar3;
  int local_18;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1001ed90;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  param_1[0x25] = param_2;
  param_1[1] = 0;
  param_1[4] = 0;
  *(undefined2 *)(param_1 + 3) = 0;
  param_1[2] = 0;
  *param_1 = 0;
  iVar3 = 0;
  do {
    iVar1 = (iVar3 + 1) * 0x10000 >> 0x10;
    param_1[iVar3 + 5] = 0;
    iVar3 = iVar1;
  } while (iVar1 < 0x20);
  local_8 = 0;
  local_18 = 0;
  do {
    pvVar2 = operator_new(0x22c);
    if (pvVar2 == (void *)0x0) {
      pvVar2 = (void *)0x0;
    }
    else {
      FUN_1001eda0(param_1,0xff);
    }
    param_1[local_18 + 5] = pvVar2;
    local_18 = (local_18 + 1) * 0x10000 >> 0x10;
  } while (local_18 < 0x20);
  ExceptionList = local_10;
  return param_1;
}



undefined4 * __thiscall FUN_1001eda0(undefined4 *param_1,undefined4 param_2,undefined1 param_3)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1001eea0;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  *param_1 = param_2;
  FUN_10014270();
  local_8 = 0;
  *(undefined1 *)(param_1 + 0x41) = param_3;
  FUN_100144b0();
  local_8 = 1;
  FUN_100144b0();
  local_8 = 2;
  param_1[0x8a] = 0;
  uVar1 = FUN_10014650();
  param_1[0x8a] = uVar1;
  uVar2 = 0;
  do {
    uVar3 = uVar2 + 1 & 0xffff;
    *(undefined1 *)((int)param_1 + uVar2 + 4) = 0;
    uVar2 = uVar3;
  } while (uVar3 < 0x80);
  ExceptionList = local_10;
  return param_1;
}



void __fastcall FUN_1001eeb0(int param_1)

{
  int iVar1;
  
  iVar1 = 0;
  do {
    if (*(int *)(param_1 + 0x14 + iVar1 * 4) != 0) {
      FUN_1001eb70(1);
    }
    *(undefined4 *)(param_1 + 0x14 + iVar1 * 4) = 0;
    iVar1 = (iVar1 + 1) * 0x10000 >> 0x10;
  } while (iVar1 < 0x20);
  return;
}



void __thiscall FUN_1001eef0(int param_1,short param_2,undefined1 param_3)

{
  if ((int)*(short *)(param_1 + 0xc) <= (int)param_2) {
    *(short *)(param_1 + 0xc) = param_2 + 1;
  }
  *(undefined1 *)(*(int *)(param_1 + 0x14 + param_2 * 4) + 0x104) = param_3;
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void __fastcall FUN_1001ef20(double *param_1)

{
  double dVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined1 uVar5;
  int iVar6;
  char *pcVar7;
  int *piVar8;
  undefined4 uVar9;
  int *piVar10;
  int iVar11;
  uint uVar12;
  undefined2 in_FPUControlWord;
  undefined1 uStack_44;
  undefined1 uStack_43;
  longlong local_3c;
  uint local_34;
  uint local_30;
  uint local_2c;
  uint local_28;
  uint uStack_24;
  undefined4 uStack_20;
  double local_1c;
  int local_14;
  
  iVar6 = FUN_10013da0();
  if (*(char *)(iVar6 + 1) != '\0') {
    iVar6 = FUN_1001bcc0();
    local_30 = *(uint *)(param_1 + 1);
    local_1c = (double)iVar6 * _DAT_10153808;
    dVar1 = *param_1;
    *param_1 = dVar1 + local_1c;
    local_2c = CONCAT22(local_2c._2_2_,in_FPUControlWord);
    local_34 = local_2c | 0xc00;
    local_3c = (longlong)ROUND(dVar1 + local_1c);
    local_14 = (int)local_3c;
    if ((int)local_30 < (int)local_3c) {
      pcVar7 = (char *)FUN_10013da0();
      uVar12 = CONCAT31((int3)((uint)pcVar7 >> 8),*pcVar7);
      if (*pcVar7 != '\0') {
        iVar6 = FUN_10013da0();
        if (((*(char *)(iVar6 + 3) != '\0') &&
            (iVar6 = FUN_10013da0(), (double)*(int *)(iVar6 + 0x10) <= *param_1)) &&
           (iVar6 = FUN_10013da0(), *param_1 - local_1c < (double)*(int *)(iVar6 + 0x10))) {
          iVar6 = FUN_10013da0();
          iVar6 = *(int *)(iVar6 + 0x10);
          local_28 = 0;
          if (0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)) {
            do {
              iVar3 = *(int *)((int)param_1 + local_28 * 4 + 0x14);
              iVar11 = *(int *)(**(int **)(iVar3 + 0x228) + 4);
              while (iVar11 <= iVar6 + -1) {
                piVar10 = (int *)**(int **)(iVar3 + 0x228);
                if (*(char *)(iVar3 + 4 + (uint)*(byte *)(piVar10 + 2)) == '\0') {
                  piVar8 = (int *)FUN_10011e60(*(undefined1 *)(iVar3 + 0x104));
                  (**(code **)(*piVar8 + 0x2c))((char)piVar10[2],*(undefined1 *)((int)piVar10 + 9));
                  piVar10 = (int *)**(int **)(iVar3 + 0x228);
                }
                *(int **)(iVar3 + 0x228) = piVar10;
                iVar11 = *(int *)(*piVar10 + 4);
              }
              local_28 = (int)((local_28 + 1) * 0x10000) >> 0x10;
            } while ((int)local_28 < (int)*(short *)((int)param_1 + 0xc));
          }
          iVar6 = FUN_10013da0();
          if (*(char *)(iVar6 + 2) != '\0') {
            iVar6 = FUN_10013da0();
            iVar6 = *(int *)(iVar6 + 0x10);
            iVar11 = 0;
            if (0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)) {
              do {
                FUN_1001f520(iVar6 + -1);
                iVar11 = (iVar11 + 1) * 0x10000 >> 0x10;
              } while (iVar11 < *(short *)((int)param_1 + 0xc));
            }
          }
          iVar6 = FUN_10013da0();
          iVar6 = *(int *)(iVar6 + 0xc);
          iVar11 = FUN_10013da0();
          local_30 = *(int *)(iVar11 + 0x10);
          dVar1 = (double)(int)(iVar6 - local_30) + *param_1;
          *param_1 = dVar1;
          local_2c = CONCAT22(local_2c._2_2_,in_FPUControlWord);
          local_34 = local_2c | 0xc00;
          local_3c = (longlong)ROUND(dVar1);
          local_14 = (int)local_3c;
          iVar6 = FUN_10013da0();
          uVar4 = *(undefined4 *)(iVar6 + 0xc);
          pcVar7 = (char *)FUN_10013da0();
          if ((*pcVar7 != '\0') &&
             (local_28 = 0, 0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10))) {
            do {
              iVar6 = *(int *)((int)param_1 + local_28 * 4 + 0x14);
              uVar9 = FUN_100151f0(iVar6 + 0x84,uVar4);
              *(undefined4 *)(iVar6 + 0x228) = uVar9;
              FUN_10014660();
              uVar12 = 0;
              do {
                cVar2 = *(char *)(iVar6 + 0x84 + uVar12);
                if (cVar2 != -1) {
                  FUN_10012b40(*(undefined1 *)(iVar6 + 0x104),uVar12,cVar2);
                }
                uVar12 = uVar12 + 1 & 0xff;
              } while (uVar12 < 0x80);
              local_28 = (int)((local_28 + 1) * 0x10000) >> 0x10;
            } while ((int)local_28 < (int)*(short *)((int)param_1 + 0xc));
          }
          iVar6 = FUN_10013da0();
          uVar4 = *(undefined4 *)(iVar6 + 0xc);
          local_28 = FUN_10013d80();
          local_28 = local_28 & 0xff;
          uVar12 = 0;
          if (local_28 != 0) {
            do {
              piVar10 = (int *)FUN_10013d90(uVar12 & 0xff);
              (**(code **)(*piVar10 + 8))(uVar4);
              uVar12 = uVar12 + 1 & 0xffff;
            } while (uVar12 < local_28);
          }
        }
        iVar6 = local_14;
        local_28 = 0;
        if (0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)) {
          do {
            iVar3 = *(int *)((int)param_1 + local_28 * 4 + 0x14);
            iVar11 = *(int *)(**(int **)(iVar3 + 0x228) + 4);
            while (iVar11 <= iVar6) {
              piVar10 = (int *)**(int **)(iVar3 + 0x228);
              if (*(char *)(iVar3 + 4 + (uint)*(byte *)(piVar10 + 2)) == '\0') {
                piVar8 = (int *)FUN_10011e60(*(undefined1 *)(iVar3 + 0x104));
                (**(code **)(*piVar8 + 0x2c))((char)piVar10[2],*(undefined1 *)((int)piVar10 + 9));
                piVar10 = (int *)**(int **)(iVar3 + 0x228);
              }
              *(int **)(iVar3 + 0x228) = piVar10;
              iVar11 = *(int *)(*piVar10 + 4);
            }
            local_28 = (int)((local_28 + 1) * 0x10000) >> 0x10;
          } while ((int)local_28 < (int)*(short *)((int)param_1 + 0xc));
        }
        dVar1 = *param_1;
        uVar12 = (uint)(ushort)((ushort)(dVar1 < _DAT_10153810) << 8 |
                               (ushort)(dVar1 == _DAT_10153810) << 0xe);
        local_14 = iVar6;
        if (dVar1 >= _DAT_10153810 && (dVar1 == _DAT_10153810) == 0) {
          FUN_10021194(0);
          uStack_44 = 2;
          uStack_43 = 0;
          uVar5 = FUN_10011d70();
          FUN_1001d550(uVar5,0x23,&uStack_44,2);
          FUN_100218a0();
          FUN_1001be10(*(undefined4 *)((int)param_1 + 0x94),0);
          FUN_1001f984(0);
          return;
        }
      }
      local_2c = CONCAT22(local_2c._2_2_,in_FPUControlWord);
      local_34 = local_2c | 0xc00;
      local_3c = (longlong)ROUND(*param_1);
      iVar6 = (int)local_3c;
      local_30 = uVar12;
      iVar11 = FUN_10013da0();
      uStack_20 = *(undefined4 *)(iVar11 + 4);
      uStack_24 = FUN_10013d80();
      uStack_24 = uStack_24 & 0xff;
      iVar11 = FUN_10013da0();
      uVar4 = uStack_20;
      iVar11 = iVar6 % 0x60 - *(byte *)(iVar11 + 0x14) / 6;
      if (iVar11 < 0) {
        iVar11 = 0;
      }
      uVar12 = 0;
      local_28 = (iVar6 / 0x60) * 0x60 + iVar11;
      if (0 < (int)uStack_24) {
        do {
          piVar10 = (int *)FUN_10013d90(uVar12 & 0xff);
          (**(code **)(*piVar10 + 4))(iVar6,local_28,uVar4);
          uVar12 = uVar12 + 1 & 0xffff;
        } while (uVar12 < uStack_24);
      }
    }
    *(int *)(param_1 + 1) = local_14;
  }
  return;
}



void FUN_1001f520(int param_1)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  undefined4 uVar4;
  int *piVar5;
  uint uVar6;
  int *piVar7;
  int iVar8;
  undefined1 auStack_142 [14];
  undefined1 local_134 [128];
  char acStack_b4 [128];
  int *local_34;
  int local_30;
  int *local_2c;
  undefined4 local_28;
  uint local_24;
  int local_20;
  int local_1c;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1001f7b0;
  local_10 = ExceptionList;
  local_14 = auStack_142 + -0x12;
  uVar6 = 0;
  do {
    acStack_b4[uVar6] = '\0';
    uVar6 = uVar6 + 1 & 0xffff;
  } while (uVar6 < 0x80);
  ExceptionList = &local_10;
  FUN_10014270();
  local_8 = 0;
  local_30 = local_20 + 0x108;
  local_34 = (int *)FUN_10014650();
  iVar8 = local_20 + 0x198;
  piVar3 = (int *)FUN_10014650();
  if (*(int *)(*local_34 + 4) <= param_1) {
    local_1c = iVar8;
    do {
      while( true ) {
        piVar7 = (int *)*piVar3;
        iVar8 = *local_34;
        piVar5 = local_34;
        if (piVar7[1] <= *(int *)(iVar8 + 4)) {
          local_2c = local_34;
          iVar8 = *(int *)(*local_34 + 4);
          for (; iVar1 = *piVar7, acStack_b4[*(byte *)(piVar7 + 2)] = '\x01',
              *(int *)(iVar1 + 4) <= iVar8; piVar7 = (int *)*piVar7) {
          }
          iVar8 = *local_2c;
          piVar5 = local_2c;
          piVar3 = piVar7;
        }
        local_134[*(byte *)(iVar8 + 8)] = *(undefined1 *)(iVar8 + 9);
        if (acStack_b4[*(byte *)(*piVar5 + 8)] != '\0') break;
        local_34 = (int *)*piVar5;
        if (param_1 < *(int *)(*(int *)*piVar5 + 4)) {
          iVar8 = local_1c;
          goto LAB_1001f649;
        }
      }
      FUN_10014b30(&local_34);
    } while (*(int *)(*local_34 + 4) <= param_1);
    iVar8 = local_1c;
  }
LAB_1001f649:
  piVar3 = (int *)*piVar3;
  if (piVar3[1] <= param_1) {
    for (; iVar1 = *(int *)(*piVar3 + 4), acStack_b4[*(byte *)(piVar3 + 2)] = '\x01',
        iVar1 <= param_1; piVar3 = (int *)*piVar3) {
    }
  }
  uVar6 = 0;
  local_28 = 0;
  local_1c = iVar8;
  do {
    if (acStack_b4[uVar6] != '\0') {
      local_24 = uVar6 & 0xff;
      uVar4 = FUN_100146e0(param_1 + 1,local_24);
      cVar2 = FUN_10014840(local_28,uVar4,local_24);
      if (cVar2 == '\0') {
        local_28 = FUN_10014750(local_28,uVar4,local_24,local_134[uVar6]);
      }
    }
    iVar8 = local_1c;
    uVar6 = uVar6 + 1 & 0xffff;
  } while (uVar6 < 0x80);
  piVar3 = (int *)FUN_10014650();
  uVar4 = 0;
  if (*(int *)(*piVar3 + 4) <= param_1) {
    local_1c = iVar8;
    do {
      iVar8 = *piVar3;
      uVar4 = FUN_10014750(uVar4,*(undefined4 *)(iVar8 + 4),*(undefined1 *)(iVar8 + 8),
                           *(undefined1 *)(iVar8 + 9));
      piVar3 = (int *)*piVar3;
    } while (*(int *)(*piVar3 + 4) <= param_1);
  }
  FUN_100149a0();
  uVar6 = 0;
  do {
    *(undefined1 *)(local_20 + 4 + uVar6) = 0;
    uVar6 = uVar6 + 1 & 0xffff;
  } while (uVar6 < 0x80);
  local_8 = 0xffffffff;
  FUN_10012c00();
  ExceptionList = local_10;
  return;
}



void FUN_1001f7c0(char param_1)

{
  if (param_1 == '\0') {
    FUN_100218a0();
    return;
  }
  FUN_1001f7e4();
  return;
}



void FUN_1001f7e0(void)

{
  ushort uVar1;
  int iVar2;
  int *piVar3;
  ushort uVar4;
  
  iVar2 = FUN_10013da0();
  if (*(char *)(iVar2 + 1) == '\0') {
    iVar2 = FUN_10013da0();
    *(undefined1 *)(iVar2 + 1) = 1;
    uVar1 = FUN_10013d80();
    uVar4 = 0;
    if ((uVar1 & 0xff) != 0) {
      do {
        piVar3 = (int *)FUN_10013d90(uVar4 & 0xff);
        (**(code **)(*piVar3 + 0xc))();
        uVar4 = uVar4 + 1;
      } while (uVar4 < (uVar1 & 0xff));
    }
  }
  return;
}



void FUN_1001f7e4(void)

{
  ushort uVar1;
  int iVar2;
  int *piVar3;
  ushort uVar4;
  
  iVar2 = FUN_10013da0();
  if (*(char *)(iVar2 + 1) == '\0') {
    iVar2 = FUN_10013da0();
    *(undefined1 *)(iVar2 + 1) = 1;
    uVar1 = FUN_10013d80();
    uVar4 = 0;
    if ((uVar1 & 0xff) != 0) {
      do {
        piVar3 = (int *)FUN_10013d90(uVar4 & 0xff);
        (**(code **)(*piVar3 + 0xc))();
        uVar4 = uVar4 + 1;
      } while (uVar4 < (uVar1 & 0xff));
    }
  }
  return;
}



undefined4 __fastcall FUN_1001f870(double *param_1)

{
  undefined4 local_14;
  
  local_14 = (undefined4)(longlong)ROUND(*param_1);
  return local_14;
}



void __thiscall FUN_1001f8b0(double *param_1,int param_2)

{
  *param_1 = (double)param_2;
  return;
}



undefined4 FUN_1001f8c0(void)

{
  int iVar1;
  
  iVar1 = FUN_10013da0();
  return *(undefined4 *)(iVar1 + 0xc);
}



undefined4 FUN_1001f8e0(void)

{
  int iVar1;
  
  iVar1 = FUN_10013da0();
  return *(undefined4 *)(iVar1 + 0x10);
}



void __thiscall
FUN_1001f900(int param_1,undefined4 param_2,char param_3,undefined1 param_4,undefined1 param_5)

{
  int iVar1;
  
  iVar1 = 0;
  if (0 < (int)((uint)*(ushort *)(param_1 + 0xc) << 0x10)) {
    do {
      if (param_3 == *(char *)(*(int *)(param_1 + 0x14 + iVar1 * 4) + 0x104)) {
        if (*(int *)(param_1 + 0x14 + iVar1 * 4) == 0) {
          return;
        }
        FUN_10014750(0,param_2,param_4,param_5);
        return;
      }
      iVar1 = (iVar1 + 1) * 0x10000 >> 0x10;
    } while (iVar1 < *(short *)(param_1 + 0xc));
  }
  return;
}



void __thiscall FUN_1001f980(double *param_1,int param_2)

{
  char cVar1;
  int iVar2;
  ushort uVar3;
  int iVar4;
  char *pcVar5;
  undefined4 uVar6;
  int *piVar7;
  int *piVar8;
  ushort uVar9;
  uint uVar10;
  int iStack_2c;
  int iStack_18;
  
  if (param_2 < 0) {
    param_2 = 0;
  }
  iVar4 = FUN_10013da0();
  if (((*(char *)(iVar4 + 2) == '\0') || (iVar4 = FUN_10013da0(), *(char *)(iVar4 + 1) != '\0')) ||
     (iStack_2c = (int)(longlong)ROUND(*param_1), param_2 <= iStack_2c)) {
    pcVar5 = (char *)FUN_10013da0();
    if ((*pcVar5 != '\0') &&
       (iStack_18 = 0, 0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10))) {
      do {
        iVar4 = *(int *)((int)param_1 + iStack_18 * 4 + 0x14);
        uVar6 = FUN_100151f0(iVar4 + 0x84,param_2);
        *(undefined4 *)(iVar4 + 0x228) = uVar6;
        FUN_10014660();
        uVar10 = 0;
        do {
          cVar1 = *(char *)(iVar4 + 0x84 + uVar10);
          if (cVar1 != -1) {
            FUN_10012b40(*(undefined1 *)(iVar4 + 0x104),uVar10,cVar1);
          }
          uVar10 = uVar10 + 1 & 0xff;
        } while (uVar10 < 0x80);
        iStack_18 = (iStack_18 + 1) * 0x10000 >> 0x10;
      } while (iStack_18 < *(short *)((int)param_1 + 0xc));
    }
  }
  else {
    iStack_18 = 0;
    if (0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)) {
      do {
        iVar2 = *(int *)((int)param_1 + iStack_18 * 4 + 0x14);
        iVar4 = *(int *)(**(int **)(iVar2 + 0x228) + 4);
        while (iVar4 <= param_2) {
          piVar8 = (int *)**(int **)(iVar2 + 0x228);
          if (*(char *)(iVar2 + 4 + (uint)*(byte *)(piVar8 + 2)) == '\0') {
            piVar7 = (int *)FUN_10011e60(*(undefined1 *)(iVar2 + 0x104));
            (**(code **)(*piVar7 + 0x2c))((char)piVar8[2],*(undefined1 *)((int)piVar8 + 9));
            piVar8 = (int *)**(int **)(iVar2 + 0x228);
          }
          *(int **)(iVar2 + 0x228) = piVar8;
          iVar4 = *(int *)(*piVar8 + 4);
        }
        iStack_18 = (iStack_18 + 1) * 0x10000 >> 0x10;
      } while (iStack_18 < *(short *)((int)param_1 + 0xc));
    }
  }
  *param_1 = (double)param_2;
  uVar3 = FUN_10013d80();
  uVar9 = 0;
  if ((uVar3 & 0xff) != 0) {
    do {
      piVar8 = (int *)FUN_10013d90(uVar9 & 0xff);
      (**(code **)(*piVar8 + 8))(param_2);
      uVar9 = uVar9 + 1;
    } while (uVar9 < (uVar3 & 0xff));
  }
  *(int *)(param_1 + 1) = param_2;
  return;
}



void __thiscall FUN_1001f984(double *param_1,int param_2)

{
  char cVar1;
  int iVar2;
  ushort uVar3;
  int iVar4;
  char *pcVar5;
  undefined4 uVar6;
  int *piVar7;
  int *piVar8;
  ushort uVar9;
  uint uVar10;
  int local_2c;
  int local_18;
  
  if (param_2 < 0) {
    param_2 = 0;
  }
  iVar4 = FUN_10013da0();
  if (((*(char *)(iVar4 + 2) == '\0') || (iVar4 = FUN_10013da0(), *(char *)(iVar4 + 1) != '\0')) ||
     (local_2c = (int)(longlong)ROUND(*param_1), param_2 <= local_2c)) {
    pcVar5 = (char *)FUN_10013da0();
    if ((*pcVar5 != '\0') &&
       (local_18 = 0, 0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10))) {
      do {
        iVar4 = *(int *)((int)param_1 + local_18 * 4 + 0x14);
        uVar6 = FUN_100151f0(iVar4 + 0x84,param_2);
        *(undefined4 *)(iVar4 + 0x228) = uVar6;
        FUN_10014660();
        uVar10 = 0;
        do {
          cVar1 = *(char *)(iVar4 + 0x84 + uVar10);
          if (cVar1 != -1) {
            FUN_10012b40(*(undefined1 *)(iVar4 + 0x104),uVar10,cVar1);
          }
          uVar10 = uVar10 + 1 & 0xff;
        } while (uVar10 < 0x80);
        local_18 = (local_18 + 1) * 0x10000 >> 0x10;
      } while (local_18 < *(short *)((int)param_1 + 0xc));
    }
  }
  else {
    local_18 = 0;
    if (0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)) {
      do {
        iVar2 = *(int *)((int)param_1 + local_18 * 4 + 0x14);
        iVar4 = *(int *)(**(int **)(iVar2 + 0x228) + 4);
        while (iVar4 <= param_2) {
          piVar8 = (int *)**(int **)(iVar2 + 0x228);
          if (*(char *)(iVar2 + 4 + (uint)*(byte *)(piVar8 + 2)) == '\0') {
            piVar7 = (int *)FUN_10011e60(*(undefined1 *)(iVar2 + 0x104));
            (**(code **)(*piVar7 + 0x2c))((char)piVar8[2],*(undefined1 *)((int)piVar8 + 9));
            piVar8 = (int *)**(int **)(iVar2 + 0x228);
          }
          *(int **)(iVar2 + 0x228) = piVar8;
          iVar4 = *(int *)(*piVar8 + 4);
        }
        local_18 = (local_18 + 1) * 0x10000 >> 0x10;
      } while (local_18 < *(short *)((int)param_1 + 0xc));
    }
  }
  *param_1 = (double)param_2;
  uVar3 = FUN_10013d80();
  uVar9 = 0;
  if ((uVar3 & 0xff) != 0) {
    do {
      piVar8 = (int *)FUN_10013d90(uVar9 & 0xff);
      (**(code **)(*piVar8 + 8))(param_2);
      uVar9 = uVar9 + 1;
    } while (uVar9 < (uVar3 & 0xff));
  }
  *(int *)(param_1 + 1) = param_2;
  return;
}



void __thiscall FUN_1001fbe0(double *param_1,char param_2)

{
  ushort uVar1;
  int *piVar2;
  ushort uVar3;
  undefined4 local_24;
  
  FUN_10013fb0(param_2);
  if (param_2 != '\0') {
    FUN_1001f984(*(undefined4 *)(param_1 + 2));
    return;
  }
  uVar1 = FUN_10013d80();
  uVar3 = 0;
  if ((uVar1 & 0xff) != 0) {
    do {
      piVar2 = (int *)FUN_10013d90(uVar3 & 0xff);
      (**(code **)(*piVar2 + 8))(0);
      uVar3 = uVar3 + 1;
    } while (uVar3 < (uVar1 & 0xff));
  }
  local_24 = (undefined4)(longlong)ROUND(*param_1);
  *(undefined4 *)(param_1 + 2) = local_24;
  return;
}



undefined1 FUN_1001fcb0(void)

{
  undefined1 *puVar1;
  
  puVar1 = (undefined1 *)FUN_10013da0();
  return *puVar1;
}



void FUN_1001fcd0(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_10013da0();
  *(undefined4 *)(iVar1 + 4) = param_1;
  return;
}



undefined4 FUN_1001fcf0(void)

{
  int iVar1;
  
  iVar1 = FUN_10013da0();
  return *(undefined4 *)(iVar1 + 4);
}



void __thiscall FUN_1001fd10(int param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = 0;
  if (0 < (int)((uint)*(ushort *)(param_1 + 0xc) << 0x10)) {
    do {
      FUN_1001f520(param_2);
      iVar1 = (iVar1 + 1) * 0x10000 >> 0x10;
    } while (iVar1 < *(short *)(param_1 + 0xc));
  }
  return;
}



undefined1 FUN_1001fd50(void)

{
  int iVar1;
  
  iVar1 = FUN_10013da0();
  return *(undefined1 *)(iVar1 + 1);
}



void __fastcall FUN_1001fd70(int param_1)

{
  int iVar1;
  
  iVar1 = 0;
  if (0 < (int)((uint)*(ushort *)(param_1 + 0xc) << 0x10)) {
    do {
      FUN_10014910(0,0x7fffffff);
      iVar1 = (iVar1 + 1) * 0x10000 >> 0x10;
    } while (iVar1 < *(short *)(param_1 + 0xc));
  }
  return;
}



void __thiscall FUN_1001fdc0(int param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  undefined4 uVar4;
  uint uVar5;
  int local_18;
  
  pcVar3 = (char *)FUN_10013da0();
  if ((*pcVar3 != '\0') && (local_18 = 0, 0 < (int)((uint)*(ushort *)(param_1 + 0xc) << 0x10))) {
    do {
      iVar2 = *(int *)(param_1 + 0x14 + local_18 * 4);
      uVar4 = FUN_100151f0(iVar2 + 0x84,param_2);
      *(undefined4 *)(iVar2 + 0x228) = uVar4;
      FUN_10014660();
      uVar5 = 0;
      do {
        cVar1 = *(char *)(iVar2 + 0x84 + uVar5);
        if (cVar1 != -1) {
          FUN_10012b40(*(undefined1 *)(iVar2 + 0x104),uVar5,cVar1);
        }
        uVar5 = uVar5 + 1 & 0xff;
      } while (uVar5 < 0x80);
      local_18 = (local_18 + 1) * 0x10000 >> 0x10;
    } while (local_18 < *(short *)(param_1 + 0xc));
  }
  return;
}



void __fastcall FUN_1001feb0(double *param_1)

{
  int iVar1;
  double dVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 local_34;
  
  iVar4 = 0;
  if (0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)) {
    do {
      FUN_1001ffe0(0,0x7fffffff);
      iVar4 = (iVar4 + 1) * 0x10000 >> 0x10;
    } while (iVar4 < *(short *)((int)param_1 + 0xc));
  }
  iVar4 = 0;
  dVar2 = *param_1;
  if (0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)) {
    do {
      local_34 = (undefined4)(longlong)ROUND(dVar2);
      FUN_1001f520(local_34);
      iVar4 = (iVar4 + 1) * 0x10000 >> 0x10;
    } while (iVar4 < *(short *)((int)param_1 + 0xc));
  }
  iVar4 = 0;
  if (0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)) {
    do {
      iVar1 = *(int *)((int)param_1 + iVar4 * 4 + 0x14);
      local_34 = (undefined4)(longlong)ROUND(*param_1);
      uVar3 = FUN_10014620(local_34,0);
      *(undefined4 *)(iVar1 + 0x228) = uVar3;
      FUN_10014660();
      iVar4 = (iVar4 + 1) * 0x10000 >> 0x10;
    } while (iVar4 < *(short *)((int)param_1 + 0xc));
  }
  return;
}



void FUN_1001ffe0(undefined4 param_1,int param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined2 in_FPUControlWord;
  undefined1 auStack_d2 [14];
  char local_c4 [128];
  int *local_44 [2];
  longlong local_3c;
  double *local_34;
  undefined2 local_30;
  undefined2 uStack_2e;
  undefined4 *local_28;
  undefined4 *local_24;
  undefined4 local_20;
  uint local_1c;
  undefined4 *local_18;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_100201d0;
  local_10 = ExceptionList;
  local_14 = auStack_d2 + -0x12;
  ExceptionList = &local_10;
  FUN_10014270();
  local_8 = 0;
  local_34 = (double *)*local_18;
  local_24 = local_18 + 0x66;
  _local_30 = CONCAT22(uStack_2e,in_FPUControlWord);
  local_3c = (longlong)ROUND(*local_34);
  FUN_100151f0(local_c4,(undefined4)local_3c);
  puVar2 = local_18 + 0x42;
  local_44[0] = (int *)FUN_10014620(param_1,0);
  if (*(int *)(*local_44[0] + 4) < param_2) {
    do {
      while (piVar1 = (int *)*local_44[0],
            *(char *)((int)local_18 + *(byte *)(piVar1 + 2) + 4) == '\0') {
        local_44[0] = piVar1;
        if (param_2 <= *(int *)(*piVar1 + 4)) goto LAB_100200d0;
      }
      FUN_10014b30(local_44);
    } while (*(int *)(*local_44[0] + 4) < param_2);
  }
LAB_100200d0:
  FUN_100148a0(param_1,param_2);
  uVar4 = 0;
  uVar3 = 0;
  local_20 = 0;
  local_28 = puVar2;
  do {
    if ((*(char *)((int)local_18 + uVar3 + 4) != '\0') && (local_c4[uVar3] != -1)) {
      local_1c = uVar3 & 0xff;
      uVar4 = FUN_10014750(uVar4,param_1,local_1c,local_c4[uVar3]);
      local_20 = FUN_10014750(local_20,param_1,local_1c,local_c4[uVar3]);
      *(char *)((int)local_18 + uVar3 + 0x84) = local_c4[uVar3];
    }
    uVar3 = uVar3 + 1 & 0xffff;
  } while (uVar3 < 0x80);
  local_8 = 0xffffffff;
  FUN_10012c00();
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_100201e0(double *param_1)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 local_24;
  
  iVar3 = FUN_10013da0();
  uVar4 = *(undefined4 *)(iVar3 + 0x10);
  iVar3 = 0;
  if (0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)) {
    do {
      FUN_10020350(uVar4);
      iVar3 = (iVar3 + 1) * 0x10000 >> 0x10;
    } while (iVar3 < *(short *)((int)param_1 + 0xc));
  }
  iVar3 = FUN_10013da0();
  uVar4 = *(undefined4 *)(iVar3 + 0xc);
  iVar3 = FUN_10013da0();
  uVar1 = *(undefined4 *)(iVar3 + 0x10);
  iVar3 = 0;
  if (0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)) {
    do {
      FUN_1001ffe0(uVar4,uVar1);
      iVar3 = (iVar3 + 1) * 0x10000 >> 0x10;
    } while (iVar3 < *(short *)((int)param_1 + 0xc));
  }
  iVar3 = 0;
  local_24 = (undefined4)(longlong)ROUND(*param_1);
  if (0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)) {
    do {
      FUN_1001f520(local_24);
      iVar3 = (iVar3 + 1) * 0x10000 >> 0x10;
    } while (iVar3 < *(short *)((int)param_1 + 0xc));
  }
  iVar3 = 0;
  if (0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)) {
    do {
      iVar2 = *(int *)((int)param_1 + iVar3 * 4 + 0x14);
      local_24 = (undefined4)(longlong)ROUND(*param_1);
      uVar4 = FUN_10014620(local_24,0);
      *(undefined4 *)(iVar2 + 0x228) = uVar4;
      FUN_10014660();
      iVar3 = (iVar3 + 1) * 0x10000 >> 0x10;
    } while (iVar3 < *(short *)((int)param_1 + 0xc));
  }
  return;
}



void FUN_10020350(undefined4 param_1)

{
  int iVar1;
  undefined1 auStackY_13c [128];
  undefined1 local_9c [128];
  undefined1 *local_1c;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10020430;
  local_10 = ExceptionList;
  local_14 = auStackY_13c + 0x88;
  local_1c = local_9c;
  ExceptionList = &local_10;
  FUN_10014270();
  local_8 = 0;
  FUN_100151f0(local_1c,param_1);
  FUN_10015240(param_1,local_1c);
  iVar1 = FUN_10013da0();
  if (*(char *)(iVar1 + 2) != '\0') {
    FUN_10015240(param_1,local_1c);
  }
  local_8 = 0xffffffff;
  FUN_10012c00();
  ExceptionList = local_10;
  return;
}



undefined4 FUN_10020440(void)

{
  undefined4 uVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined1 auStackY_150 [128];
  undefined1 local_a8 [128];
  undefined4 local_28;
  undefined4 local_24;
  undefined1 *local_20;
  uint local_18;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10020660;
  local_10 = ExceptionList;
  local_14 = auStackY_150 + 0x8c;
  local_20 = local_a8;
  ExceptionList = &local_10;
  FUN_10014270();
  local_8 = 0;
  uVar2 = FUN_1000dee0();
  iVar3 = FUN_10013da0();
  local_24 = *(undefined4 *)(iVar3 + 0xc);
  iVar3 = FUN_10013da0();
  local_28 = *(undefined4 *)(iVar3 + 0x10);
  uVar6 = 0;
  iVar3 = 0;
  local_18 = uVar2;
  do {
    iVar4 = FUN_10014690(local_24,local_28);
    iVar5 = DAT_101245f0;
    iVar3 = (iVar3 + 1) * 0x10000 >> 0x10;
    uVar6 = iVar4 + uVar6;
  } while (iVar3 < 0x20);
  if (local_18 < uVar6) {
    local_8 = 0xffffffff;
    FUN_10012c00();
    ExceptionList = local_10;
    return 0;
  }
  iVar3 = 0;
  do {
    FUN_100149a0();
    iVar3 = (iVar3 + 1) * 0x10000 >> 0x10;
  } while (iVar3 < 0x20);
  iVar3 = 0;
  *(undefined4 *)(iVar5 + 0x80) = 0;
  do {
    iVar5 = FUN_10013da0();
    FUN_100151f0(local_20,*(undefined4 *)(iVar5 + 0xc));
    iVar5 = FUN_10013da0();
    uVar1 = *(undefined4 *)(iVar5 + 0xc);
    iVar5 = FUN_10013da0();
    FUN_10014b90(uVar1,*(undefined4 *)(iVar5 + 0x10),*(undefined4 *)(DAT_101245f0 + iVar3 * 4));
    FUN_10015240(0,local_20);
    iVar3 = (iVar3 + 1) * 0x10000 >> 0x10;
  } while (iVar3 < 0x20);
  iVar3 = FUN_10013da0();
  iVar3 = *(int *)(iVar3 + 0x10);
  iVar5 = FUN_10013da0();
  *(int *)(DAT_101245f0 + 0x80) = iVar3 - *(int *)(iVar5 + 0xc);
  local_8 = 0xffffffff;
  FUN_10012c00();
  ExceptionList = local_10;
  return 1;
}



void __fastcall FUN_10020670(double *param_1)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  char *pcVar6;
  undefined4 uVar7;
  int iVar8;
  uint uVar9;
  undefined4 local_2c;
  int local_18;
  
  iVar3 = FUN_10013da0();
  uVar7 = *(undefined4 *)(iVar3 + 0x10);
  iVar3 = 0;
  if (0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)) {
    do {
      FUN_10020350(uVar7);
      iVar3 = (iVar3 + 1) * 0x10000 >> 0x10;
    } while (iVar3 < *(short *)((int)param_1 + 0xc));
  }
  iVar3 = FUN_10013da0();
  uVar7 = *(undefined4 *)(iVar3 + 0xc);
  iVar3 = FUN_10013da0();
  uVar2 = *(undefined4 *)(iVar3 + 0x10);
  iVar3 = 0;
  if (0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)) {
    do {
      FUN_10014910(uVar7,uVar2);
      iVar3 = (iVar3 + 1) * 0x10000 >> 0x10;
    } while (iVar3 < *(short *)((int)param_1 + 0xc));
  }
  FUN_10013da0();
  iVar3 = FUN_10013da0();
  iVar3 = *(int *)(iVar3 + 0xc);
  iVar4 = FUN_10013da0();
  iVar4 = *(int *)(iVar4 + 0x10);
  iVar8 = 0;
  if (0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)) {
    do {
      iVar5 = FUN_10013da0();
      FUN_10014dd0(*(undefined4 *)(iVar5 + 0x10),0x7fffffff,iVar3 - iVar4);
      iVar8 = (iVar8 + 1) * 0x10000 >> 0x10;
    } while (iVar8 < *(short *)((int)param_1 + 0xc));
  }
  local_2c = (undefined4)(longlong)ROUND(*param_1);
  pcVar6 = (char *)FUN_10013da0();
  if ((*pcVar6 != '\0') && (local_18 = 0, 0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)))
  {
    do {
      iVar3 = *(int *)((int)param_1 + local_18 * 4 + 0x14);
      uVar7 = FUN_100151f0(iVar3 + 0x84,local_2c);
      *(undefined4 *)(iVar3 + 0x228) = uVar7;
      FUN_10014660();
      uVar9 = 0;
      do {
        cVar1 = *(char *)(iVar3 + 0x84 + uVar9);
        if (cVar1 != -1) {
          FUN_10012b40(*(undefined1 *)(iVar3 + 0x104),uVar9,cVar1);
        }
        uVar9 = uVar9 + 1 & 0xff;
      } while (uVar9 < 0x80);
      local_18 = (local_18 + 1) * 0x10000 >> 0x10;
    } while (local_18 < *(short *)((int)param_1 + 0xc));
  }
  return;
}



void __thiscall FUN_100208a0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  
  iVar1 = 0;
  if (0 < (int)((uint)*(ushort *)(param_1 + 0xc) << 0x10)) {
    do {
      FUN_10014910(param_2,param_3);
      iVar1 = (iVar1 + 1) * 0x10000 >> 0x10;
    } while (iVar1 < *(short *)(param_1 + 0xc));
  }
  return;
}



undefined4 __fastcall FUN_100208f0(double *param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  char *pcVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  int local_34;
  int local_20;
  
  local_34 = (int)(longlong)ROUND(*param_1);
  iVar9 = (local_34 / 0x300) * 0x300;
  iVar2 = FUN_1000dee0();
  iVar7 = 0;
  iVar4 = 0;
  do {
    iVar3 = FUN_10014670();
    iVar7 = (iVar7 + 1) * 0x10000 >> 0x10;
    iVar4 = iVar3 + iVar4;
  } while (iVar7 < 0x20);
  if (iVar2 < iVar4 + 0x1000) {
    return 0;
  }
  iVar4 = 0;
  if (0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)) {
    do {
      FUN_10020350(iVar9);
      iVar4 = (iVar4 + 1) * 0x10000 >> 0x10;
    } while (iVar4 < *(short *)((int)param_1 + 0xc));
  }
  iVar4 = 0;
  if (0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)) {
    do {
      FUN_10014dd0(iVar9,0x7fffffff,*(undefined4 *)(DAT_101245f0 + 0x80));
      FUN_10014cc0(iVar9,*(undefined4 *)(DAT_101245f0 + iVar4 * 4));
      iVar4 = (iVar4 + 1) * 0x10000 >> 0x10;
    } while (iVar4 < *(short *)((int)param_1 + 0xc));
  }
  iVar4 = FUN_10013da0();
  if (*(char *)(iVar4 + 1) == '\0') {
    uVar5 = FUN_10004660(iVar9 + *(int *)(DAT_101245f0 + 0x80),0,0xbb200);
    FUN_1001bf70(*(undefined4 *)((int)param_1 + 0x94),uVar5);
  }
  iVar4 = 0;
  if (0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)) {
    do {
      FUN_100149f0();
      iVar4 = (iVar4 + 1) * 0x10000 >> 0x10;
    } while (iVar4 < *(short *)((int)param_1 + 0xc));
  }
  local_34 = (int)(longlong)ROUND(*param_1);
  pcVar6 = (char *)FUN_10013da0();
  if ((*pcVar6 != '\0') && (local_20 = 0, 0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)))
  {
    do {
      iVar4 = *(int *)((int)param_1 + local_20 * 4 + 0x14);
      uVar5 = FUN_100151f0(iVar4 + 0x84,local_34);
      *(undefined4 *)(iVar4 + 0x228) = uVar5;
      FUN_10014660();
      uVar8 = 0;
      do {
        cVar1 = *(char *)(iVar4 + 0x84 + uVar8);
        if (cVar1 != -1) {
          FUN_10012b40(*(undefined1 *)(iVar4 + 0x104),uVar8,cVar1);
        }
        uVar8 = uVar8 + 1 & 0xff;
      } while (uVar8 < 0x80);
      local_20 = (local_20 + 1) * 0x10000 >> 0x10;
    } while (local_20 < *(short *)((int)param_1 + 0xc));
  }
  return 1;
}



undefined4 __fastcall FUN_10020bc0(double *param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  char *pcVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  int local_34;
  int local_20;
  int local_1c;
  
  local_34 = (int)(longlong)ROUND(*param_1);
  iVar9 = (local_34 / 0x300) * 0x300;
  iVar2 = FUN_1000dee0();
  iVar7 = 0;
  iVar4 = 0;
  do {
    iVar3 = FUN_10014670();
    iVar7 = (iVar7 + 1) * 0x10000 >> 0x10;
    iVar4 = iVar3 + iVar4;
  } while (iVar7 < 0x20);
  if (iVar2 < iVar4 + 0x1000) {
    return 0;
  }
  iVar4 = 0;
  local_1c = *(int *)(DAT_101245f0 + 0x80) + iVar9;
  if (0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)) {
    do {
      FUN_10020350(local_1c);
      iVar4 = (iVar4 + 1) * 0x10000 >> 0x10;
    } while (iVar4 < *(short *)((int)param_1 + 0xc));
    local_1c = iVar9 + *(int *)(DAT_101245f0 + 0x80);
  }
  iVar4 = 0;
  if (0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)) {
    do {
      FUN_10014910(iVar9,local_1c);
      iVar4 = (iVar4 + 1) * 0x10000 >> 0x10;
    } while (iVar4 < *(short *)((int)param_1 + 0xc));
  }
  iVar4 = 0;
  if (0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)) {
    do {
      FUN_10014cc0(iVar9,*(undefined4 *)(DAT_101245f0 + iVar4 * 4));
      iVar4 = (iVar4 + 1) * 0x10000 >> 0x10;
    } while (iVar4 < *(short *)((int)param_1 + 0xc));
  }
  iVar4 = FUN_10013da0();
  if (*(char *)(iVar4 + 1) == '\0') {
    uVar5 = FUN_10004660(iVar9 + *(int *)(DAT_101245f0 + 0x80),0,0xbb200);
    FUN_1001bf70(*(undefined4 *)((int)param_1 + 0x94),uVar5);
  }
  iVar4 = 0;
  if (0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)) {
    do {
      FUN_100149f0();
      iVar4 = (iVar4 + 1) * 0x10000 >> 0x10;
    } while (iVar4 < *(short *)((int)param_1 + 0xc));
  }
  local_34 = (int)(longlong)ROUND(*param_1);
  pcVar6 = (char *)FUN_10013da0();
  if ((*pcVar6 != '\0') && (local_20 = 0, 0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)))
  {
    do {
      iVar4 = *(int *)((int)param_1 + local_20 * 4 + 0x14);
      uVar5 = FUN_100151f0(iVar4 + 0x84,local_34);
      *(undefined4 *)(iVar4 + 0x228) = uVar5;
      FUN_10014660();
      uVar8 = 0;
      do {
        cVar1 = *(char *)(iVar4 + 0x84 + uVar8);
        if (cVar1 != -1) {
          FUN_10012b40(*(undefined1 *)(iVar4 + 0x104),uVar8,cVar1);
        }
        uVar8 = uVar8 + 1 & 0xff;
      } while (uVar8 < 0x80);
      local_20 = (local_20 + 1) * 0x10000 >> 0x10;
    } while (local_20 < *(short *)((int)param_1 + 0xc));
  }
  return 1;
}



void FUN_10020ec0(int param_1)

{
  undefined1 uVar1;
  uint uVar2;
  int iVar3;
  uint local_30;
  uint local_2c;
  uint local_24;
  uint local_20;
  
  FUN_10019e50();
  FUN_10019eb0(param_1 + 1);
  FUN_10019e50();
  uVar2 = FUN_10014670();
  local_2c = local_20;
  if (uVar2 < local_20) {
    local_2c = uVar2;
  }
  local_30 = local_24;
  if (uVar2 < local_24) {
    local_30 = uVar2;
  }
  FUN_10019e70(&DAT_10121ee0);
  iVar3 = 9;
  FUN_10014af0(local_30);
  for (; local_30 < local_2c; local_30 = local_30 + 1) {
    (&DAT_10121ee0)[iVar3] = 99;
    FUN_10019ef0();
    FUN_1000dee0();
    FUN_10019f10(iVar3 + 0x10121ee1);
    iVar3 = iVar3 + 7;
  }
  uVar1 = FUN_10011d70();
  FUN_1001ded0(uVar1,0x25,&DAT_10121ee0,iVar3);
  return;
}



void FUN_10021010(int param_1)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 local_2c;
  undefined1 local_28;
  undefined1 local_27;
  int local_20;
  int local_1c;
  
  FUN_10019e50();
  FUN_10019eb0(param_1 + 1);
  uVar2 = local_1c - local_20;
  uVar1 = FUN_1000dee0();
  if (uVar1 < uVar2) {
    FUN_1001de00(0x16);
    return;
  }
  uVar4 = 0;
  iVar3 = 10;
  for (; uVar2 != 0; uVar2 = uVar2 - 1) {
    FUN_10019ef0();
    FUN_10019f40(param_1 + iVar3 + 1);
    iVar3 = iVar3 + 7;
    uVar4 = FUN_10014750(uVar4,local_2c,local_28,local_27);
  }
  FUN_1001df80(0x49);
  return;
}



void FUN_10021110(undefined1 param_1)

{
  int iVar1;
  
  iVar1 = FUN_10013da0();
  *(undefined1 *)(iVar1 + 3) = param_1;
  return;
}



void FUN_10021130(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_10013da0();
  *(undefined4 *)(iVar1 + 0xc) = param_1;
  return;
}



void FUN_10021150(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_10013da0();
  *(undefined4 *)(iVar1 + 0x10) = param_1;
  return;
}



void FUN_10021170(undefined1 param_1)

{
  int iVar1;
  
  iVar1 = FUN_10013da0();
  *(undefined1 *)(iVar1 + 0x14) = param_1;
  return;
}



void __thiscall FUN_10021190(double *param_1,char param_2)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_2c;
  int iStack_18;
  
  iVar2 = FUN_10013da0();
  if ((*(char *)(iVar2 + 2) != '\0') && (param_2 == '\0')) {
    iVar2 = 0;
    uStack_2c = (undefined4)(longlong)ROUND(*param_1);
    if (0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)) {
      do {
        FUN_1001f520(uStack_2c);
        iVar2 = (iVar2 + 1) * 0x10000 >> 0x10;
      } while (iVar2 < *(short *)((int)param_1 + 0xc));
    }
    uStack_2c = (undefined4)(longlong)ROUND(*param_1);
    pcVar3 = (char *)FUN_10013da0();
    if ((*pcVar3 != '\0') &&
       (iStack_18 = 0, 0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10))) {
      do {
        iVar2 = *(int *)((int)param_1 + iStack_18 * 4 + 0x14);
        uVar4 = FUN_100151f0(iVar2 + 0x84,uStack_2c);
        *(undefined4 *)(iVar2 + 0x228) = uVar4;
        FUN_10014660();
        uVar5 = 0;
        do {
          cVar1 = *(char *)(iVar2 + 0x84 + uVar5);
          if (cVar1 != -1) {
            FUN_10012b40(*(undefined1 *)(iVar2 + 0x104),uVar5,cVar1);
          }
          uVar5 = uVar5 + 1 & 0xff;
        } while (uVar5 < 0x80);
        iStack_18 = (iStack_18 + 1) * 0x10000 >> 0x10;
      } while (iStack_18 < *(short *)((int)param_1 + 0xc));
    }
  }
  iVar2 = FUN_10013da0();
  *(char *)(iVar2 + 2) = param_2;
  return;
}



void __thiscall FUN_10021194(double *param_1,char param_2)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 local_2c;
  int local_18;
  
  iVar2 = FUN_10013da0();
  if ((*(char *)(iVar2 + 2) != '\0') && (param_2 == '\0')) {
    iVar2 = 0;
    local_2c = (undefined4)(longlong)ROUND(*param_1);
    if (0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)) {
      do {
        FUN_1001f520(local_2c);
        iVar2 = (iVar2 + 1) * 0x10000 >> 0x10;
      } while (iVar2 < *(short *)((int)param_1 + 0xc));
    }
    local_2c = (undefined4)(longlong)ROUND(*param_1);
    pcVar3 = (char *)FUN_10013da0();
    if ((*pcVar3 != '\0') &&
       (local_18 = 0, 0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10))) {
      do {
        iVar2 = *(int *)((int)param_1 + local_18 * 4 + 0x14);
        uVar4 = FUN_100151f0(iVar2 + 0x84,local_2c);
        *(undefined4 *)(iVar2 + 0x228) = uVar4;
        FUN_10014660();
        uVar5 = 0;
        do {
          cVar1 = *(char *)(iVar2 + 0x84 + uVar5);
          if (cVar1 != -1) {
            FUN_10012b40(*(undefined1 *)(iVar2 + 0x104),uVar5,cVar1);
          }
          uVar5 = uVar5 + 1 & 0xff;
        } while (uVar5 < 0x80);
        local_18 = (local_18 + 1) * 0x10000 >> 0x10;
      } while (local_18 < *(short *)((int)param_1 + 0xc));
    }
  }
  iVar2 = FUN_10013da0();
  *(char *)(iVar2 + 2) = param_2;
  return;
}



void __thiscall FUN_10021340(double *param_1,char param_2,byte param_3,undefined1 param_4)

{
  char *pcVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined4 local_24;
  
  pcVar1 = (char *)FUN_10013da0();
  if ((*pcVar1 != '\0') && (iVar2 = FUN_10013da0(), *(char *)(iVar2 + 2) != '\0')) {
    uVar3 = FUN_1000dee0();
    if ((uVar3 < 100) && (((uVar3 == 99 || (uVar3 == 0x32)) || (uVar3 < 10)))) {
      FUN_1001d440(0x4f);
    }
    iVar2 = 0;
    if (0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)) {
      do {
        if (param_2 == *(char *)(*(int *)((int)param_1 + iVar2 * 4 + 0x14) + 0x104)) {
          iVar2 = *(int *)((int)param_1 + iVar2 * 4 + 0x14);
          if (iVar2 == 0) {
            return;
          }
          uVar3 = (uint)param_3;
          *(undefined1 *)(iVar2 + 4 + uVar3) = 1;
          iVar2 = FUN_10013da0();
          if (*(char *)(iVar2 + 1) == '\0') {
            local_24 = (undefined4)(longlong)ROUND(*param_1);
            iVar2 = FUN_10014720(local_24,uVar3);
          }
          else {
            local_24 = (undefined4)(longlong)ROUND(*param_1);
            iVar2 = FUN_100146e0(local_24,uVar3);
          }
          iVar4 = FUN_10013da0();
          if ((*(char *)(iVar4 + 3) != '\0') &&
             (iVar4 = FUN_10013da0(), iVar2 == *(int *)(iVar4 + 0x10))) {
            iVar2 = FUN_10013da0();
            iVar2 = *(int *)(iVar2 + 0xc);
          }
          FUN_10014750(0,iVar2,uVar3,param_4);
          return;
        }
        iVar2 = (iVar2 + 1) * 0x10000 >> 0x10;
      } while (iVar2 < *(short *)((int)param_1 + 0xc));
    }
  }
  return;
}



void __thiscall FUN_10021520(int param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = 0;
  if (0 < (int)((uint)*(ushort *)(param_1 + 0xc) << 0x10)) {
    do {
      FUN_10020350(param_2);
      iVar1 = (iVar1 + 1) * 0x10000 >> 0x10;
    } while (iVar1 < *(short *)(param_1 + 0xc));
  }
  return;
}



void __thiscall FUN_10021560(int param_1,char param_2,undefined1 param_3,undefined1 param_4)

{
  int iVar1;
  
  iVar1 = 0;
  if (0 < (int)((uint)*(ushort *)(param_1 + 0xc) << 0x10)) {
    do {
      if (param_2 == *(char *)(*(int *)(param_1 + 0x14 + iVar1 * 4) + 0x104)) break;
      iVar1 = (iVar1 + 1) * 0x10000 >> 0x10;
    } while (iVar1 < *(short *)(param_1 + 0xc));
  }
  FUN_10014600(param_3,param_4);
  return;
}



undefined1 FUN_100215d0(void)

{
  int iVar1;
  
  iVar1 = FUN_10013da0();
  return *(undefined1 *)(iVar1 + 3);
}



int __fastcall FUN_100215f0(int param_1)

{
  uint uVar1;
  void *pvVar2;
  uint uVar3;
  uint local_18;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10021710;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  *(undefined4 *)(param_1 + 0x80) = 0;
  uVar1 = 0;
  do {
    uVar3 = uVar1 + 1 & 0xffff;
    *(undefined4 *)(param_1 + uVar1 * 4) = 0;
    uVar1 = uVar3;
  } while (uVar3 < 0x20);
  local_8 = 0;
  local_18 = 0;
  do {
    pvVar2 = operator_new(0x90);
    if (pvVar2 == (void *)0x0) {
      pvVar2 = (void *)0x0;
    }
    else {
      FUN_100144b0();
    }
    *(void **)(param_1 + local_18 * 4) = pvVar2;
    local_18 = local_18 + 1 & 0xffff;
  } while (local_18 < 0x20);
  ExceptionList = local_10;
  return param_1;
}



void __fastcall FUN_10021724(int param_1)

{
  uint uVar1;
  
  uVar1 = 0;
  *(undefined4 *)(param_1 + 0x80) = 0;
  do {
    if (*(int *)(param_1 + uVar1 * 4) != 0) {
      FUN_1001eb40(1);
    }
    *(undefined4 *)(param_1 + uVar1 * 4) = 0;
    uVar1 = uVar1 + 1 & 0xffff;
  } while (uVar1 < 0x20);
  return;
}



void FUN_10021770(void)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10021830;
  local_10 = ExceptionList;
  local_8 = 1;
  ExceptionList = &local_10;
  FUN_10014550();
  local_8 = 0;
  FUN_10014550();
  local_8 = 0xffffffff;
  FUN_10012c00();
  ExceptionList = local_10;
  return;
}



void FUN_10021840(void)

{
  ushort uVar1;
  int *piVar2;
  ushort uVar3;
  
  uVar1 = FUN_10013d80();
  uVar3 = 0;
  if ((uVar1 & 0xff) != 0) {
    do {
      piVar2 = (int *)FUN_10013d90(uVar3 & 0xff);
      (**(code **)(*piVar2 + 0x10))();
      uVar3 = uVar3 + 1;
    } while (uVar3 < (uVar1 & 0xff));
  }
  return;
}



void __fastcall FUN_100218a0(double *param_1)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 local_2c;
  int local_18;
  
  iVar2 = FUN_10013da0();
  if (*(char *)(iVar2 + 1) != '\0') {
    iVar2 = FUN_10013da0();
    *(undefined1 *)(iVar2 + 1) = 0;
    FUN_10021840();
  }
  iVar2 = 0;
  if (0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)) {
    do {
      FUN_100149f0();
      iVar2 = (iVar2 + 1) * 0x10000 >> 0x10;
    } while (iVar2 < *(short *)((int)param_1 + 0xc));
  }
  local_2c = (undefined4)(longlong)ROUND(*param_1);
  pcVar3 = (char *)FUN_10013da0();
  if ((*pcVar3 != '\0') && (local_18 = 0, 0 < (int)((uint)*(ushort *)((int)param_1 + 0xc) << 0x10)))
  {
    do {
      iVar2 = *(int *)((int)param_1 + local_18 * 4 + 0x14);
      uVar4 = FUN_100151f0(iVar2 + 0x84,local_2c);
      *(undefined4 *)(iVar2 + 0x228) = uVar4;
      FUN_10014660();
      uVar5 = 0;
      do {
        cVar1 = *(char *)(iVar2 + 0x84 + uVar5);
        if (cVar1 != -1) {
          FUN_10012b40(*(undefined1 *)(iVar2 + 0x104),uVar5,cVar1);
        }
        uVar5 = uVar5 + 1 & 0xff;
      } while (uVar5 < 0x80);
      local_18 = (local_18 + 1) * 0x10000 >> 0x10;
    } while (local_18 < *(short *)((int)param_1 + 0xc));
  }
  return;
}



void FUN_10021a10(void)

{
  void *pvVar1;
  
  pvVar1 = operator_new(0x84);
  if (pvVar1 == (void *)0x0) {
    pvVar1 = (void *)0x0;
  }
  else {
    FUN_100215f0();
  }
  DAT_101245f0 = pvVar1;
  pvVar1 = operator_new(0x14);
  if (pvVar1 == (void *)0x0) {
    pvVar1 = (void *)0x0;
  }
  else {
    FUN_100142c0();
  }
  DAT_10100230 = pvVar1;
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void FUN_100234a0(void)

{
  double dVar1;
  float10 fVar2;
  float10 fVar3;
  float10 fVar4;
  float10 fVar5;
  double dVar6;
  double dVar7;
  double dVar8;
  double dVar9;
  double dVar10;
  uint uVar11;
  uint uVar12;
  int iVar13;
  float10 fVar14;
  float10 fVar15;
  float10 fVar16;
  float10 fVar17;
  float10 fVar18;
  float10 fVar19;
  float10 fVar20;
  float10 fVar21;
  double local_34;
  uint local_24;
  
  if (DAT_10124700 != '\0') {
    return;
  }
  fVar14 = (float10)FUN_1002ddf0(0,0x40990800,0x401004,0x3f500401);
  fVar15 = (float10)FUN_1002ddf0((double)fVar14,0,0x408ff800);
  fVar3 = (float10)_DAT_101539c8;
  local_24 = 0;
  do {
    dVar6 = (double)local_24;
    fVar16 = (float10)FUN_1002ddf0(0x40000000,0x3ffc7ae1,dVar6);
    fVar4 = (float10)_DAT_101539d8;
    dVar9 = (double)_DAT_10153a58;
    dVar10 = dVar6 * _DAT_101539e0 + _DAT_101539e8;
    dVar8 = dVar6 * dVar9 * _DAT_101539c8 + _DAT_101539f0;
    iVar13 = local_24 * 0x4000;
    uVar11 = 0;
    do {
      dVar7 = (double)uVar11;
      fVar17 = (float10)FUN_1002ddf0((double)fVar14,dVar7);
      dVar1 = (double)(fVar17 * (float10)(double)(fVar3 / fVar15) * (float10)dVar8);
      dVar7 = dVar7 * _DAT_101539f8 * _DAT_10153a00 * dVar7 * _DAT_101539f8 * _DAT_10153a00 *
              _DAT_10153a08 - _DAT_10153a10;
      if ((double)_DAT_10153a5c < dVar7) {
        dVar7 = (double)_DAT_10153a5c;
      }
      if (dVar7 < (double)_DAT_10153a60) {
        dVar7 = (double)_DAT_10153a60;
      }
      local_34 = (_DAT_10153a18 - dVar7) * dVar10 + dVar7 * (double)(fVar16 * fVar4);
      fVar17 = (float10)fcos((float10)dVar1 * (float10)_DAT_10153a20);
      fVar19 = (float10)1.4426950408889634 *
               (float10)dVar1 * (float10)_DAT_10153a28 * (float10)(_DAT_101539a8 / local_34);
      fVar18 = ROUND(fVar19);
      fVar19 = (float10)f2xm1(-(fVar18 - fVar19));
      fVar19 = (float10)fscale((float10)1 + fVar19,fVar18);
      fVar19 = (float10)(double)fVar17 * (float10)_DAT_10153a30 * fVar19;
      fVar17 = (float10)_DAT_10153a18;
      fVar20 = (float10)1.4426950408889634 *
               (float10)dVar1 * (float10)_DAT_10153a38 * (float10)(_DAT_101539a8 / local_34);
      fVar18 = ROUND(fVar20);
      fVar20 = (float10)f2xm1(-(fVar18 - fVar20));
      fVar20 = (float10)fscale((float10)1 + fVar20,fVar18);
      fVar21 = (float10)1.4426950408889634 *
               ((float10)(dVar6 * dVar9) * (float10)_DAT_10153a40 + (float10)_DAT_10153a48) *
               (float10)(double)((float10)dVar1 * (float10)_DAT_10153a38);
      fVar18 = ROUND(fVar21);
      fVar21 = (float10)f2xm1(-(fVar18 - fVar21));
      fVar21 = (float10)fscale((float10)1 + fVar21,fVar18);
      fVar18 = (float10)_DAT_10153a18;
      if ((double)_DAT_10153a64 < local_34) {
        local_34 = (double)_DAT_10153a68;
      }
      fVar2 = (float10)_DAT_10153a5c;
      fVar5 = (float10)_DAT_10153a50;
      *(float *)(&DAT_1012b370 + uVar11 * 0x10 + iVar13) = (float)fVar21;
      *(float *)(&DAT_1012b364 + uVar11 * 0x10 + iVar13) = (float)fVar19;
      uVar12 = uVar11 + 1 & 0xffff;
      *(float *)(&DAT_1012b368 + uVar11 * 0x10 + iVar13) = (float)fVar20;
      *(float *)(&DAT_1012b36c + uVar11 * 0x10 + iVar13) =
           (float)(((fVar18 - fVar21) *
                   (float10)(double)(fVar20 + (float10)(double)(fVar17 - fVar19))) /
                  (((float10)local_34 + fVar2) * fVar5));
      uVar11 = uVar12;
    } while (uVar12 < 0x400);
    local_24 = local_24 + 1 & 0xffff;
  } while (local_24 < 8);
  DAT_10124700 = 1;
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void FUN_10023800(undefined4 param_1,float param_2)

{
  int iVar1;
  int iVar2;
  float *in_EAX;
  uint uVar3;
  float10 in_ST0;
  float10 fVar4;
  ulonglong local_1c;
  
  local_1c._0_4_ = (int)(longlong)ROUND(param_2 * _DAT_10153a6c);
  iVar2 = (int)local_1c;
  local_1c._0_2_ = (ushort)(longlong)ROUND(in_ST0 * (float10)_DAT_10153a70);
  uVar3 = (uint)(ushort)local_1c;
  local_1c = (ulonglong)uVar3;
  iVar1 = (uVar3 + 1) * 0x800 + iVar2 * 2;
  iVar2 = uVar3 * 0x800 + iVar2 * 2;
  fVar4 = in_ST0 * (float10)_DAT_10153a70 - (float10)local_1c;
  *in_EAX = (float)(((float10)*(float *)(&DAT_1012b364 + iVar1 * 8) -
                    (float10)*(float *)(&DAT_1012b364 + iVar2 * 8)) * fVar4 +
                   (float10)*(float *)(&DAT_1012b364 + iVar2 * 8));
  in_EAX[1] = (float)(((float10)*(float *)(&DAT_1012b368 + iVar1 * 8) -
                      (float10)*(float *)(&DAT_1012b368 + iVar2 * 8)) * fVar4 +
                     (float10)*(float *)(&DAT_1012b368 + iVar2 * 8));
  in_EAX[2] = (float)(((float10)*(float *)(&DAT_1012b36c + iVar1 * 8) -
                      (float10)*(float *)(&DAT_1012b36c + iVar2 * 8)) * fVar4 +
                     (float10)*(float *)(&DAT_1012b36c + iVar2 * 8));
  in_EAX[3] = (float)((float10)*(float *)(&DAT_1012b370 + iVar2 * 8) +
                     ((float10)*(float *)(&DAT_1012b370 + iVar1 * 8) -
                     (float10)*(float *)(&DAT_1012b370 + iVar2 * 8)) * fVar4);
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

undefined4 * __thiscall FUN_10023920(undefined4 *param_1,undefined4 param_2,undefined1 param_3)

{
  float10 fVar1;
  float10 fVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  float10 fVar6;
  float10 fVar7;
  float10 fVar8;
  float10 fVar9;
  float10 fVar10;
  int local_30;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10023be0;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_100103a0(param_2,param_3);
  local_8 = 0;
  *param_1 = &PTR_LAB_10033fd4;
  FUN_10018c20();
  local_30 = 0x20;
  do {
    FUN_10018d20();
    iVar5 = 0x10;
    do {
      FUN_10018d30();
      iVar5 = iVar5 + -1;
    } while (iVar5 != 0);
    local_30 = local_30 + -1;
  } while (local_30 != 0);
  FUN_10018c20();
  param_1[0x330] = 0x3f000000;
  param_1[0x331] = 0x3f000000;
  *(undefined1 *)(param_1 + 0x325) = 0;
  *(undefined1 *)(param_1 + 0x328) = 0;
  *(undefined1 *)((int)param_1 + 0xc96) = 0;
  *(undefined1 *)((int)param_1 + 0xca1) = 0;
  param_1[0x32c] = 0;
  param_1[0x32d] = 0;
  param_1[0x33c] = 0;
  param_1[0x33b] = 0;
  param_1[0x33a] = 0;
  param_1[0x339] = 0;
  param_1[0x338] = 0;
  param_1[0x337] = 0;
  param_1[0x336] = 0;
  param_1[0x335] = 0;
  param_1[0x334] = 0;
  param_1[0x340] = 0;
  param_1[0x33f] = 0;
  param_1[0x33e] = 0;
  param_1[0x33d] = 0;
  param_1[0x333] = 0;
  param_1[0x332] = 0;
  param_1[0x32f] = 0;
  param_1[0x32e] = 0;
  param_1[0x32b] = 0;
  param_1[0x32a] = 0;
  param_1[0x329] = 0;
  *(undefined1 *)((int)param_1 + 0xc95) = 1;
  FUN_100234a0();
  if (DAT_10124704 == '\0') {
    DAT_10124704 = '\x01';
    fVar6 = (float10)FUN_1002ddf0(0,0x40000000,0x55555555,0x3fb55555);
    uVar3 = 3;
    fVar7 = (float10)_DAT_10153a90;
    while( true ) {
      if ((uVar3 & 1) != 0) {
        fVar7 = fVar7 * fVar6;
      }
      uVar3 = uVar3 >> 1;
      if (uVar3 == 0) break;
      fVar6 = fVar6 * fVar6;
    }
    fVar6 = (float10)_DAT_10153a98;
    fVar1 = (float10)_DAT_10153a80;
    fVar8 = (float10)FUN_1002ddf0(0,0x40000000,0x55555555,0x3f555555);
    fVar9 = (float10)FUN_1002ddf0((double)fVar8,0,0x40a80000);
    fVar2 = (float10)_DAT_10153ab0;
    uVar3 = 0;
    do {
      fVar10 = (float10)FUN_1002ddf0((double)fVar8,(double)uVar3);
      (&DAT_10125364)[uVar3] =
           (float)(fVar10 * (float10)(double)(((float10)(double)(fVar7 * fVar6 * fVar1) * fVar2) /
                                             fVar9));
      uVar3 = uVar3 + 1;
    } while (uVar3 < 0x1800);
  }
  param_1[0x327] = 0;
  param_1[0x326] = 0xffffffff;
  uVar3 = 0;
  do {
    uVar4 = uVar3 + 1 & 0xffff;
    *(undefined1 *)((int)param_1 + uVar3 + 0xc88) = 0;
    uVar3 = uVar4;
  } while (uVar4 < 0xc);
  ExceptionList = local_10;
  return param_1;
}



void __fastcall FUN_10023bf0(undefined4 *param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10023c60;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  *param_1 = &PTR_LAB_10033fd4;
  local_8 = 0xffffffff;
  FUN_10010220();
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_10023c74(int param_1)

{
  int iVar1;
  
  if (*(char *)(param_1 + 0xca1) == '\0') {
    *(undefined4 *)(param_1 + 0xcd0) = 0;
    iVar1 = FUN_10013da0();
    if (*(char *)(iVar1 + 0x15) == '\0') {
      *(undefined4 *)(param_1 + 0xcc8) = 0x3d810625;
      *(undefined4 *)(param_1 + 0xccc) = 0x3f6fdf3b;
      return;
    }
    *(undefined4 *)(param_1 + 0xcc8) = 0x3dcccccd;
    *(undefined4 *)(param_1 + 0xccc) = 0x3f666666;
  }
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void __thiscall FUN_10023cd4(int param_1,byte *param_2)

{
  float fVar1;
  int iVar2;
  
  *(float *)(param_1 + 0xcec) =
       ((float)*(byte *)(param_1 + 0xc80) * (float)_DAT_10153b28 + (float)_DAT_10153b30) *
       (float)_DAT_10153b38;
  iVar2 = FUN_10013da0();
  if (*(char *)(iVar2 + 0x15) == '\0') {
    fVar1 = *(float *)(param_1 + 0xcec) * *(float *)(param_1 + 0xcec);
    fVar1 = fVar1 * fVar1;
    fVar1 = fVar1 * fVar1;
    fVar1 = fVar1 * fVar1;
    fVar1 = fVar1 * fVar1;
    *(float *)(param_1 + 0xcec) = fVar1 * fVar1;
  }
  else {
    fVar1 = *(float *)(param_1 + 0xcec) * *(float *)(param_1 + 0xcec);
    *(float *)(param_1 + 0xcec) = fVar1 * fVar1;
  }
  if (param_2[2] == 0) {
    *(undefined4 *)(param_1 + 0xcb8) = 0;
    fVar1 = (float)_DAT_10153b48 - (float)*(byte *)(param_1 + 0xc82) * _DAT_10153b74;
    *(float *)(param_1 + 0xcac) = (float)_DAT_10153b58 - fVar1 * fVar1 * (float)_DAT_10153b50;
  }
  else {
    *(undefined4 *)(param_1 + 0xcac) = 0x3f7febaf;
    *(float *)(param_1 + 0xcb8) = (float)*(byte *)(param_1 + 0xc83) * (float)_DAT_10153b40;
  }
  iVar2 = FUN_10013da0();
  if (*(char *)(iVar2 + 0x15) == '\0') {
    fVar1 = *(float *)(param_1 + 0xcac) * *(float *)(param_1 + 0xcac);
    fVar1 = fVar1 * fVar1;
    fVar1 = fVar1 * fVar1;
    fVar1 = fVar1 * fVar1;
    fVar1 = fVar1 * fVar1;
    *(float *)(param_1 + 0xcac) = fVar1 * fVar1;
  }
  else {
    fVar1 = *(float *)(param_1 + 0xcac) * *(float *)(param_1 + 0xcac);
    *(float *)(param_1 + 0xcac) = fVar1 * fVar1;
  }
  if (param_2[5] == 0) {
    *(undefined4 *)(param_1 + 0xcd0) = 0x3f800000;
    iVar2 = FUN_10013da0();
    if (*(char *)(iVar2 + 0x15) == '\0') {
      *(undefined4 *)(param_1 + 0xcc8) = 0x3f800000;
      *(undefined4 *)(param_1 + 0xccc) = 0;
    }
    else {
      *(undefined4 *)(param_1 + 0xcc8) = 0x3dcccccd;
      *(undefined4 *)(param_1 + 0xccc) = 0x3f666666;
    }
    if (*(char *)(param_1 + 0xca1) == '\0') {
      *(undefined4 *)(param_1 + 0xca8) = 0x3f800000;
      *(undefined1 *)(param_1 + 0xca0) = 1;
    }
  }
  *(int *)(param_1 + 0xcb0) =
       (*(short *)(&DAT_10033f90 + ((int)(uint)*(byte *)(param_1 + 0xc7e) >> 2) * 2) * 0x40 + 0xc00
       + ((int)(((uint)param_2[3] * 0xc + (uint)*param_2 + (uint)param_2[4] * -0xc) * 0x10000) >>
         0x10) * 0x40) * 0x10;
  if (*(char *)(param_1 + 0xca1) == '\0') {
    *(undefined4 *)(param_1 + 0xcb4) = *(undefined4 *)(param_1 + 0xcb0);
  }
  DAT_10124708 = DAT_10124708 + 1;
  *(byte *)(param_1 + 0xca1) = param_2[1];
  if (0x12 < DAT_10124708) {
    DAT_10124708 = 0;
  }
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void __thiscall FUN_100248c4(int param_1,undefined4 *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  uint uVar21;
  short sVar22;
  float *pfVar23;
  bool bVar24;
  undefined4 local_1a8;
  undefined4 local_1a4;
  undefined4 local_19c;
  float local_198;
  float local_194;
  float local_190;
  float local_18c;
  
  fVar2 = _DAT_10124710 * *(float *)(param_1 + 0xcc0);
  fVar3 = _DAT_1012470c * *(float *)(param_1 + 0xcc4);
  fVar4 = ((float)*(byte *)(param_1 + 0xc7f) * (float)_DAT_10153be8 + (float)_DAT_10153bf0) *
          _DAT_10124714;
  uVar21 = (uint)(*(int *)(param_1 + 0xcb4) * 0xb + *(int *)(param_1 + 0xcb0)) / 0xc;
  *(uint *)(param_1 + 0xcb4) = uVar21;
  fVar1 = *(float *)(param_1 + 0xcd4) + _DAT_10153c30;
  pfVar23 = (float *)*param_2;
  *(undefined4 *)(param_1 + 0xcc4) = *(undefined4 *)(param_1 + 0xcc0);
  *(float *)(param_1 + 0xcc0) = (fVar4 + fVar2) - fVar3;
  *(float *)(param_1 + 0xcd4) = fVar1;
  fVar13 = _DAT_10153c30 + *(float *)(param_1 + 0xca8);
  fVar2 = (float)_DAT_10153be0;
  *(float *)(param_1 + 0xca8) = fVar13;
  fVar10 = (float)(&DAT_10125364)[uVar21 >> 4];
  fVar12 = *(float *)(param_1 + 0xcd0) * *(float *)(param_1 + 0xcc8) +
           fVar1 * *(float *)(param_1 + 0xccc);
  fVar7 = (fVar2 - *(float *)(param_1 + 0xcec)) * *(float *)(param_1 + 0xcb8) * fVar13 +
          *(float *)(param_1 + 0xcec) * *(float *)(param_1 + 0xcbc);
  fVar11 = *(float *)(param_1 + 0xcac);
  fVar6 = (float)_DAT_10153be0;
  *(float *)(param_1 + 0xcbc) = fVar7;
  fVar1 = *(float *)(param_1 + 0xcdc);
  fVar2 = *(float *)(param_1 + 0xce0);
  fVar3 = *(float *)(param_1 + 0xce4);
  fVar4 = *(float *)(param_1 + 0xce8);
  fVar5 = *(float *)(param_1 + 0xca4);
  if (*(char *)(param_1 + 0xca0) != '\0') {
    FUN_10023800();
    *(undefined4 *)(param_1 + 0xcf4) = local_1a8;
    *(undefined4 *)(param_1 + 0xcfc) = 0;
    *(undefined4 *)(param_1 + 0xcf8) = local_1a4;
    *(undefined1 *)(param_1 + 0xca0) = 0;
    *(undefined4 *)(param_1 + 0xd00) = local_19c;
  }
  FUN_10023800();
  fVar14 = (local_190 * (fVar7 + fVar6) * fVar12 - *(float *)(param_1 + 0xcfc)) *
           (float)_DAT_10153c28;
  fVar15 = (local_198 - *(float *)(param_1 + 0xcf4)) * (float)_DAT_10153c28;
  fVar16 = (local_194 - *(float *)(param_1 + 0xcf8)) * (float)_DAT_10153c28;
  fVar6 = *(float *)(param_1 + 0xcf4);
  fVar17 = (local_18c - *(float *)(param_1 + 0xd00)) * (float)_DAT_10153c28;
  fVar7 = *(float *)(param_1 + 0xcf8);
  fVar8 = *(float *)(param_1 + 0xcfc);
  fVar9 = *(float *)(param_1 + 0xd00);
  if (*(char *)(param_1 + 0xc84) == '\0') {
    sVar22 = 0xf;
    do {
      fVar18 = _DAT_10153c34;
      fVar5 = fVar5 + fVar10;
      if (_DAT_10153c34 < fVar5) {
        fVar5 = fVar5 - _DAT_10153c40;
      }
      fVar3 = fVar3 * fVar9 + fVar5;
      fVar5 = fVar5 + fVar10;
      fVar19 = (fVar1 * fVar6 + fVar3 * fVar8) - fVar2 * fVar7;
      fVar2 = (fVar19 - fVar1) + fVar4 * _DAT_10153c44;
      *pfVar23 = fVar2;
      fVar4 = _DAT_10153c34;
      if (fVar18 < fVar5) {
        fVar5 = fVar5 - _DAT_10153c40;
      }
      fVar3 = fVar3 * fVar9 + fVar5;
      fVar5 = fVar5 + fVar10;
      fVar18 = fVar6 + fVar15;
      fVar1 = (fVar19 * fVar6 + fVar3 * fVar8) - fVar1 * fVar7;
      fVar6 = fVar2 * _DAT_10153c44 + (fVar1 - fVar19);
      fVar7 = fVar7 + fVar16;
      pfVar23[1] = fVar6;
      fVar20 = _DAT_10153c34;
      fVar8 = fVar8 + fVar14;
      fVar9 = fVar9 + fVar17;
      if (fVar4 < fVar5) {
        fVar5 = fVar5 - _DAT_10153c40;
      }
      fVar3 = fVar3 * fVar9 + fVar5;
      fVar5 = fVar5 + fVar10;
      fVar2 = (fVar1 * fVar18 + fVar3 * fVar8) - fVar19 * fVar7;
      fVar4 = fVar6 * _DAT_10153c44 + (fVar2 - fVar1);
      pfVar23[2] = fVar4;
      if (fVar20 < fVar5) {
        fVar5 = fVar5 - _DAT_10153c40;
      }
      fVar3 = fVar3 * fVar9 + fVar5;
      fVar6 = fVar18 + fVar15;
      fVar1 = (fVar2 * fVar18 + fVar3 * fVar8) - fVar1 * fVar7;
      fVar7 = fVar7 + fVar16;
      fVar4 = fVar4 * _DAT_10153c44 + (fVar1 - fVar2);
      fVar8 = fVar8 + fVar14;
      fVar9 = fVar9 + fVar17;
      pfVar23[3] = fVar4;
      pfVar23 = pfVar23 + 4;
      bVar24 = sVar22 != 0;
      sVar22 = sVar22 + -1;
    } while (bVar24);
  }
  else {
    sVar22 = 0xf;
    do {
      fVar18 = _DAT_10153c34;
      fVar5 = fVar5 + fVar10;
      if (_DAT_10153c34 < fVar5) {
        fVar5 = fVar5 - _DAT_10153c40;
      }
      if (_DAT_10153c48 < fVar5) {
        fVar19 = _DAT_10153c4c;
      }
      else {
        fVar19 = _DAT_10153c50;
      }
      fVar19 = fVar3 * fVar9 + fVar19;
      fVar5 = fVar5 + fVar10;
      fVar2 = (fVar1 * fVar6 + fVar19 * fVar8) - fVar2 * fVar7;
      fVar3 = (fVar2 - fVar1) + fVar4 * _DAT_10153c44;
      *pfVar23 = fVar3;
      fVar4 = _DAT_10153c34;
      if (fVar18 < fVar5) {
        fVar5 = fVar5 - _DAT_10153c40;
      }
      if (_DAT_10153c48 < fVar5) {
        fVar18 = _DAT_10153c4c;
      }
      else {
        fVar18 = _DAT_10153c50;
      }
      fVar5 = fVar5 + fVar10;
      fVar18 = fVar19 * fVar9 + fVar18;
      fVar19 = (fVar2 * fVar6 + fVar18 * fVar8) - fVar1 * fVar7;
      fVar1 = fVar7 + fVar16;
      fVar8 = fVar8 + fVar14;
      fVar3 = fVar3 * _DAT_10153c44 + (fVar19 - fVar2);
      fVar9 = fVar9 + fVar17;
      pfVar23[1] = fVar3;
      fVar7 = _DAT_10153c34;
      fVar20 = fVar6 + fVar15;
      if (fVar4 < fVar5) {
        fVar5 = fVar5 - _DAT_10153c40;
      }
      if (_DAT_10153c48 < fVar5) {
        fVar4 = _DAT_10153c4c;
      }
      else {
        fVar4 = _DAT_10153c50;
      }
      fVar5 = fVar5 + fVar10;
      fVar4 = fVar18 * fVar9 + fVar4;
      fVar2 = (fVar19 * fVar20 + fVar4 * fVar8) - fVar2 * fVar1;
      fVar18 = (fVar2 - fVar19) + fVar3 * _DAT_10153c44;
      pfVar23[2] = fVar18;
      if (fVar7 < fVar5) {
        fVar5 = fVar5 - _DAT_10153c40;
      }
      if (_DAT_10153c48 < fVar5) {
        fVar3 = _DAT_10153c4c;
      }
      else {
        fVar3 = _DAT_10153c50;
      }
      fVar3 = fVar4 * fVar9 + fVar3;
      fVar6 = fVar20 + fVar15;
      fVar7 = fVar1 + fVar16;
      fVar1 = (fVar2 * fVar20 + fVar3 * fVar8) - fVar19 * fVar1;
      fVar8 = fVar8 + fVar14;
      fVar4 = fVar18 * _DAT_10153c44 + (fVar1 - fVar2);
      fVar9 = fVar9 + fVar17;
      pfVar23[3] = fVar4;
      pfVar23 = pfVar23 + 4;
      bVar24 = sVar22 != 0;
      sVar22 = sVar22 + -1;
    } while (bVar24);
  }
  *(float *)(param_1 + 0xcf4) = fVar6;
  *(float *)(param_1 + 0xcf8) = fVar7;
  *(float *)(param_1 + 0xcfc) = fVar8;
  *(float *)(param_1 + 0xd00) = fVar9;
  *(float *)(param_1 + 0xca4) = fVar5;
  *(float *)(param_1 + 0xca8) = fVar13 * fVar11;
  *(float *)(param_1 + 0xcd4) = fVar12;
  *(float *)(param_1 + 0xcdc) = fVar1;
  *(float *)(param_1 + 0xce0) = fVar2;
  *(float *)(param_1 + 0xce8) = fVar4;
  *(float *)(param_1 + 0xce4) = fVar3;
  return;
}



int __thiscall FUN_10026d80(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  void *pvVar1;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10026e00;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_100094c0(param_2);
  local_8 = 0;
  *(uint *)(param_1 + 0x1c) = param_4;
  *(undefined4 *)(param_1 + 0x14) = param_3;
  *(undefined4 *)(param_1 + 0x18) = 0;
  pvVar1 = operator_new(param_4);
  *(void **)(param_1 + 0x18) = pvVar1;
  ExceptionList = local_10;
  return param_1;
}



void __fastcall FUN_10026e10(int param_1)

{
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10026e90;
  local_10 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_10;
  FUN_1002dde0(*(undefined4 *)(param_1 + 0x18));
  *(undefined4 *)(param_1 + 0x18) = 0;
  local_8 = 0xffffffff;
  FUN_10009500();
  ExceptionList = local_10;
  return;
}



void __fastcall FUN_10026ea0(int param_1)

{
  char cVar1;
  int iVar2;
  undefined4 local_10;
  
  cVar1 = FUN_10009950();
  if (cVar1 != '\0') {
    iVar2 = FUN_100096d0(&local_10);
    while ((iVar2 == 0xc && (cVar1 = FUN_10009740(local_10), cVar1 != '\0'))) {
      FUN_100095e0(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 0x1c),&local_10);
      FUN_10009520(*(undefined4 *)(param_1 + 0x18),local_10);
      iVar2 = FUN_100096d0(&local_10);
    }
    FUN_10009970();
  }
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

int * __thiscall FUN_10026f70(int *param_1,undefined4 param_2,undefined1 param_3,int param_4)

{
  uint uVar1;
  void *pvVar2;
  uint uVar3;
  int iVar4;
  float10 fVar5;
  float10 fVar6;
  float10 fVar7;
  float10 fVar8;
  ulonglong local_5c;
  int local_48;
  uint local_34;
  uint local_2c;
  uint local_24;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10027510;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_100103a0(param_2,param_3);
  local_8 = 0;
  *param_1 = (int)&PTR_LAB_10034154;
  FUN_10018fb0();
  local_48 = 0x20;
  do {
    FUN_10018d20();
    iVar4 = 0x10;
    do {
      FUN_100197c0();
      iVar4 = iVar4 + -1;
    } while (iVar4 != 0);
    local_48 = local_48 + -1;
  } while (local_48 != 0);
  FUN_10018fb0();
  *(undefined1 *)((int)param_1 + 0x18d2) = 0;
  param_1[0x635] = 0;
  *(undefined1 *)(param_1 + 0x634) = 0;
  *(undefined1 *)((int)param_1 + 0x18d1) = 1;
  param_1[0x636] = param_4;
  iVar4 = (int)DAT_1014ccd8;
  DAT_1014ccd8 = (short)(iVar4 + 1);
  if (iVar4 + 1 == 1) {
    fVar5 = (float10)FUN_1002ddf0(0,0x40000000,0x55555555,0x3f755555);
    uVar1 = 0x40;
    fVar6 = (float10)_DAT_10153ea0;
    while( true ) {
      if ((uVar1 & 1) != 0) {
        fVar6 = fVar6 * fVar5;
      }
      uVar1 = uVar1 >> 1;
      if (uVar1 == 0) break;
      fVar5 = fVar5 * fVar5;
    }
    fVar5 = (float10)_DAT_10153ea8;
    fVar7 = (float10)FUN_1002ddf0(0,0x40000000,0x55555555,0x3f755555);
    uVar1 = 0;
    do {
      local_5c = (ulonglong)uVar1;
      fVar8 = (float10)FUN_1002ddf0((double)fVar7,(double)local_5c);
      uVar3 = uVar1 + 1 & 0xffff;
      (&DAT_1014cbd8)[uVar1] = (short)(longlong)ROUND(fVar8 * (float10)(double)(fVar5 / fVar6));
      uVar1 = uVar3;
    } while (uVar3 < 0x80);
  }
  param_1[0x643] = 0;
  uVar1 = 0;
  do {
    uVar3 = uVar1 + 1 & 0xffff;
    param_1[uVar1 + 0x637] = 0;
    uVar1 = uVar3;
  } while (uVar3 < 5);
  uVar1 = 0;
  do {
    uVar3 = uVar1 + 1 & 0xffff;
    param_1[uVar1 + 0x63c] = 0;
    uVar1 = uVar3;
  } while (uVar3 < 3);
  uVar1 = 0;
  do {
    uVar3 = uVar1 + 1 & 0xffff;
    param_1[uVar1 + 0x63f] = 0;
    uVar1 = uVar3;
  } while (uVar3 < 3);
  param_1[0x642] = 0;
  uVar1 = 0;
  do {
    uVar3 = uVar1 + 1 & 0xffff;
    *(undefined1 *)((int)param_1 + uVar1 + 0x18b0) = 0;
    uVar1 = uVar3;
  } while (uVar3 < 0x20);
  local_8 = 1;
  local_34 = 0;
  do {
    pvVar2 = operator_new(0x20);
    if (pvVar2 == (void *)0x0) {
      pvVar2 = (void *)0x0;
    }
    else {
      FUN_1001e290();
    }
    param_1[local_34 + 0x637] = (int)pvVar2;
    local_34 = local_34 + 1 & 0xffff;
  } while (local_34 < 5);
  local_2c = 0;
  do {
    pvVar2 = operator_new(0x30);
    if (pvVar2 == (void *)0x0) {
      pvVar2 = (void *)0x0;
    }
    else {
      FUN_1001e8b0();
    }
    param_1[local_2c + 0x63c] = (int)pvVar2;
    local_2c = local_2c + 1 & 0xffff;
  } while (local_2c < 3);
  local_24 = 0;
  do {
    pvVar2 = operator_new(0x28);
    if (pvVar2 == (void *)0x0) {
      pvVar2 = (void *)0x0;
    }
    else {
      FUN_1001e3e0();
    }
    param_1[local_24 + 0x63f] = (int)pvVar2;
    local_24 = local_24 + 1 & 0xffff;
  } while (local_24 < 3);
  pvVar2 = operator_new(0x2c);
  if (pvVar2 == (void *)0x0) {
    pvVar2 = (void *)0x0;
  }
  else {
    FUN_1001e610();
  }
  param_1[0x642] = (int)pvVar2;
  (**(code **)(*param_1 + 0x18))();
  ExceptionList = local_10;
  return param_1;
}



void __fastcall FUN_10027520(undefined4 *param_1)

{
  uint uVar1;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_10027680;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  *param_1 = &PTR_LAB_10034154;
  local_8 = 0;
  uVar1 = 0;
  DAT_1014ccd8 = DAT_1014ccd8 + -1;
  do {
    if ((undefined4 *)param_1[uVar1 + 0x637] != (undefined4 *)0x0) {
      (*(code *)**(undefined4 **)param_1[uVar1 + 0x637])(1);
    }
    param_1[uVar1 + 0x637] = 0;
    uVar1 = uVar1 + 1 & 0xffff;
  } while (uVar1 < 5);
  uVar1 = 0;
  do {
    if ((undefined4 *)param_1[uVar1 + 0x63c] != (undefined4 *)0x0) {
      (*(code *)**(undefined4 **)param_1[uVar1 + 0x63c])(1);
    }
    param_1[uVar1 + 0x63c] = 0;
    uVar1 = uVar1 + 1 & 0xffff;
  } while (uVar1 < 3);
  uVar1 = 0;
  do {
    if ((undefined4 *)param_1[uVar1 + 0x63f] != (undefined4 *)0x0) {
      (*(code *)**(undefined4 **)param_1[uVar1 + 0x63f])(1);
    }
    param_1[uVar1 + 0x63f] = 0;
    uVar1 = uVar1 + 1 & 0xffff;
  } while (uVar1 < 3);
  if ((undefined4 *)param_1[0x642] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x642])(1);
  }
  param_1[0x642] = 0;
  local_8 = 0xffffffff;
  FUN_10010220();
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_10027894(int param_1,undefined2 param_2)

{
  switch(param_2) {
  case 1:
    FUN_1002a0b4(*(undefined4 *)(*(int *)(param_1 + 0x18d8) + 4),*(undefined1 *)(param_1 + 0x1893),
                 *(undefined1 *)(param_1 + 0x1895),*(undefined1 *)(param_1 + 0x1894),1);
    return;
  case 2:
    FUN_1002a1e4(*(undefined1 *)(param_1 + 0x1896),*(undefined1 *)(param_1 + 0x1897),
                 *(undefined1 *)(param_1 + 0x1898),2);
    return;
  case 3:
    break;
  case 4:
    if (*(char *)(param_1 + 0x189e) == '\0') {
      FUN_1002a004(*(undefined4 *)(*(int *)(param_1 + 0x18d8) + 0x54),
                   *(undefined1 *)(param_1 + 0x189d),*(undefined1 *)(param_1 + 0x189c),4);
      return;
    }
    FUN_1002a004(*(undefined4 *)(*(int *)(param_1 + 0x18d8) + 0x58),
                 *(undefined1 *)(param_1 + 0x189d),*(undefined1 *)(param_1 + 0x189c),4);
    return;
  case 5:
    if (*(char *)(param_1 + 0x18a1) == '\0') {
      FUN_1002a004(*(undefined4 *)(*(int *)(param_1 + 0x18d8) + 0x40),
                   *(undefined1 *)(param_1 + 0x18a0),*(undefined1 *)(param_1 + 0x189f),5);
      return;
    }
    FUN_1002a004(*(undefined4 *)(*(int *)(param_1 + 0x18d8) + 0x44),
                 *(undefined1 *)(param_1 + 0x18a0),*(undefined1 *)(param_1 + 0x189f),5);
    return;
  case 6:
    if (*(char *)(param_1 + 0x18a3) == '\0') {
                    // WARNING: Could not recover jumptable at 0x10027a89. Too many branches
                    // WARNING: Treating indirect jump as call
      (*(code *)PTR_LAB_10154000)();
      return;
    }
                    // WARNING: Could not recover jumptable at 0x10027b27. Too many branches
                    // WARNING: Treating indirect jump as call
    (*(code *)PTR_LAB_10153fd0)();
    return;
  case 7:
    if (*(char *)(param_1 + 0x18a5) == '\0') {
                    // WARNING: Could not recover jumptable at 0x10027bd3. Too many branches
                    // WARNING: Treating indirect jump as call
      (*(code *)PTR_LAB_1015401c)();
      return;
    }
                    // WARNING: Could not recover jumptable at 0x10027c71. Too many branches
                    // WARNING: Treating indirect jump as call
    (*(code *)PTR_LAB_10153fbc)();
    return;
  case 8:
                    // WARNING: Could not recover jumptable at 0x10027d0f. Too many branches
                    // WARNING: Treating indirect jump as call
    (*(code *)PTR_LAB_10153fa8)();
    return;
  case 9:
    FUN_1002a0b4(*(undefined4 *)(*(int *)(param_1 + 0x18d8) + 0x3c),
                 *(undefined1 *)(param_1 + 0x18a7),*(undefined1 *)(param_1 + 0x18a9),
                 *(undefined1 *)(param_1 + 0x18a8),9);
    return;
  case 10:
                    // WARNING: Could not recover jumptable at 0x10027e0c. Too many branches
                    // WARNING: Treating indirect jump as call
    (*(code *)PTR_LAB_10153f98)();
    return;
  case 0xb:
                    // WARNING: Could not recover jumptable at 0x10027ec9. Too many branches
                    // WARNING: Treating indirect jump as call
    (*(code *)PTR_LAB_10153ffc)();
    return;
  default:
    return;
  }
  if (*(char *)(param_1 + 0x189b) == '\0') {
    FUN_1002a004(*(undefined4 *)(*(int *)(param_1 + 0x18d8) + 0x48),
                 *(undefined1 *)(param_1 + 0x189a),*(undefined1 *)(param_1 + 0x1899),3);
    return;
  }
  FUN_1002a004(*(undefined4 *)(*(int *)(param_1 + 0x18d8) + 0x4c),*(undefined1 *)(param_1 + 0x189a),
               *(undefined1 *)(param_1 + 0x1899),3);
  return;
}



void __thiscall FUN_10028290(int *param_1,int param_2)

{
  (**(code **)(*param_1 + 0x18))();
  param_1[0x636] = param_2;
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void __thiscall
FUN_1002a004(int param_1,undefined4 param_2,byte param_3,byte param_4,undefined2 param_5)

{
  switch(param_5) {
  case 3:
    break;
  case 4:
    break;
  case 5:
  }
  FUN_1001ead0(param_2,(float)param_4 * _DAT_10154200 * (float)param_4 * _DAT_10154200 *
                       *(float *)(param_1 + 0x190c),0x3f800000,0,
               CONCAT11(*(undefined1 *)((int)&DAT_1014cbd8 + (uint)param_3 * 2 + 1),
                        *(undefined1 *)(&DAT_1014cbd8 + param_3)));
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void __thiscall
FUN_1002a0b4(int param_1,undefined4 param_2,byte param_3,byte param_4,byte param_5,short param_6)

{
  float fVar1;
  int iVar2;
  
  if (param_6 == 1) {
    if (DAT_1014cbd0 == 0) {
      FUN_1001e3d0(0x3f7d70a4);
      DAT_1014cbd0 = 1;
    }
    else {
      FUN_1001e3d0(0x3f7d70a4);
      DAT_1014cbd0 = 0;
    }
  }
  iVar2 = (int)((uint)param_5 << 3) >> 7;
  fVar1 = (float)param_3 * _DAT_10154224 * (float)param_3 * _DAT_10154228 *
          *(float *)(param_1 + 0x190c);
  if (param_6 == 1) {
    fVar1 = ((float)_DAT_10154218 - *(float *)(&DAT_100340e4 + iVar2 * 4)) * fVar1;
  }
  FUN_1001e5c0(param_2,fVar1,*(undefined4 *)(&DAT_10034104 + ((int)((uint)param_4 << 4) >> 7) * 4),0
               ,*(undefined4 *)(&DAT_100340e4 + iVar2 * 4));
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void __thiscall FUN_1002a1e4(int param_1,byte param_2,byte param_3,byte param_4)

{
  uint uVar1;
  
  uVar1 = DAT_1014cbd4 + 1 & 0x1f;
  _DAT_1014cbd4 = (undefined2)uVar1;
  FUN_1001e820(*(undefined4 *)
                (*(int *)(param_1 + 0x18d8) + 4 +
                *(short *)(&DAT_10034090 + ((int)((uint)param_3 * 5) >> 7) * 2) * 4),
               (float)param_2 * _DAT_1015422c * (float)param_2 * _DAT_10154230 *
               *(float *)(param_1 + 0x190c),0x3f800000,0,
               *(undefined4 *)
                (*(int *)(param_1 + 0x18d8) + 4 +
                (uint)*(ushort *)(&DAT_100340dc + (uint)*(ushort *)(&DAT_1003409c + uVar1 * 2) * 2)
                * 4),(float)param_4 * _DAT_1015422c * (float)param_4 * _DAT_1015422c);
  return;
}



void __fastcall FUN_1002a2d0(int param_1)

{
  uint uVar1;
  
  uVar1 = 0;
  do {
    (**(code **)(**(int **)(param_1 + 0x18dc + uVar1 * 4) + 4))();
    uVar1 = uVar1 + 1 & 0xffff;
  } while (uVar1 < 5);
  uVar1 = 0;
  do {
    (**(code **)(**(int **)(param_1 + 0x18fc + uVar1 * 4) + 4))();
    uVar1 = uVar1 + 1 & 0xffff;
  } while (uVar1 < 3);
  uVar1 = 0;
  do {
    (**(code **)(**(int **)(param_1 + 0x18f0 + uVar1 * 4) + 4))();
    uVar1 = uVar1 + 1 & 0xffff;
  } while (uVar1 < 3);
  (**(code **)(**(int **)(param_1 + 0x1908) + 4))();
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

int * __thiscall FUN_1002a380(int *param_1,undefined4 param_2,undefined1 param_3,int param_4)

{
  float fVar1;
  float fVar2;
  uint uVar3;
  uint uVar4;
  void *pvVar5;
  int iVar6;
  float10 fVar7;
  float10 fVar8;
  float10 fVar9;
  float10 fVar10;
  ulonglong local_5c;
  int local_48;
  uint local_34;
  uint local_2c;
  uint local_24;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_1002a950;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  FUN_100103a0(param_2,param_3);
  local_8 = 0;
  *param_1 = (int)&PTR_LAB_10034294;
  FUN_100195a0();
  local_48 = 0x20;
  do {
    FUN_10018d20();
    iVar6 = 0x10;
    do {
      FUN_100197c0();
      iVar6 = iVar6 + -1;
    } while (iVar6 != 0);
    local_48 = local_48 + -1;
  } while (local_48 != 0);
  FUN_100195a0();
  *(undefined1 *)((int)param_1 + 0x18d5) = 0;
  param_1[0x636] = 0;
  *(undefined1 *)((int)param_1 + 0x18d3) = 0;
  *(undefined1 *)(param_1 + 0x635) = 1;
  param_1[0x637] = param_4;
  iVar6 = (int)DAT_1014e68c;
  DAT_1014e68c = (short)(iVar6 + 1);
  if (iVar6 + 1 == 1) {
    fVar7 = (float10)FUN_1002ddf0(0,0x40000000,0x1c71c71c,0x3f7c71c7);
    uVar3 = 0x40;
    fVar8 = (float10)_DAT_101542a0;
    while( true ) {
      if ((uVar3 & 1) != 0) {
        fVar8 = fVar8 * fVar7;
      }
      uVar3 = uVar3 >> 1;
      if (uVar3 == 0) break;
      fVar7 = fVar7 * fVar7;
    }
    fVar7 = (float10)_DAT_101542b0;
    fVar9 = (float10)FUN_1002ddf0(0,0x40000000,0x1c71c71c,0x3f7c71c7);
    uVar3 = 0;
    do {
      local_5c = (ulonglong)uVar3;
      fVar10 = (float10)FUN_1002ddf0((double)fVar9,(double)local_5c);
      uVar4 = uVar3 + 1 & 0xffff;
      (&DAT_1014e54c)[uVar3] = (short)(longlong)ROUND(fVar10 * (float10)(double)(fVar7 / fVar8));
      uVar3 = uVar4;
    } while (uVar4 < 0x80);
    iVar6 = 0xf;
    fVar2 = (float)_DAT_101542a8;
    fVar1 = _DAT_1015431c;
    do {
      *(float *)(&DAT_1014e64c + iVar6 * 4) = fVar1;
      iVar6 = (iVar6 + -1) * 0x10000 >> 0x10;
      fVar1 = fVar1 - fVar2;
    } while (-1 < iVar6);
  }
  *(undefined1 *)(param_1 + 0x644) = 0;
  param_1[0x645] = 0;
  param_1[0x647] = 0;
  param_1[0x646] = 0;
  uVar3 = 0;
  do {
    uVar4 = uVar3 + 1 & 0xffff;
    param_1[uVar3 + 0x638] = 0;
    uVar3 = uVar4;
  } while (uVar4 < 4);
  uVar3 = 0;
  do {
    uVar4 = uVar3 + 1 & 0xffff;
    param_1[uVar3 + 0x63c] = 0;
    uVar3 = uVar4;
  } while (uVar4 < 5);
  uVar3 = 0;
  do {
    uVar4 = uVar3 + 1 & 0xffff;
    param_1[uVar3 + 0x641] = 0;
    uVar3 = uVar4;
  } while (uVar4 < 2);
  param_1[0x643] = 0;
  uVar3 = 0;
  do {
    uVar4 = uVar3 + 1 & 0xffff;
    *(undefined1 *)((int)param_1 + uVar3 + 0x18b2) = 0;
    uVar3 = uVar4;
  } while (uVar4 < 0x21);
  local_8 = 1;
  local_34 = 0;
  do {
    pvVar5 = operator_new(0x20);
    if (pvVar5 == (void *)0x0) {
      pvVar5 = (void *)0x0;
    }
    else {
      FUN_1001e290();
    }
    param_1[local_34 + 0x638] = (int)pvVar5;
    local_34 = local_34 + 1 & 0xffff;
  } while (local_34 < 4);
  local_2c = 0;
  do {
    pvVar5 = operator_new(0x30);
    if (pvVar5 == (void *)0x0) {
      pvVar5 = (void *)0x0;
    }
    else {
      FUN_1001e8b0();
    }
    param_1[local_2c + 0x63c] = (int)pvVar5;
    local_2c = local_2c + 1 & 0xffff;
  } while (local_2c < 5);
  local_24 = 0;
  do {
    pvVar5 = operator_new(0x28);
    if (pvVar5 == (void *)0x0) {
      pvVar5 = (void *)0x0;
    }
    else {
      FUN_1001e3e0();
    }
    param_1[local_24 + 0x641] = (int)pvVar5;
    local_24 = local_24 + 1 & 0xffff;
  } while (local_24 < 2);
  pvVar5 = operator_new(0x2c);
  if (pvVar5 == (void *)0x0) {
    pvVar5 = (void *)0x0;
  }
  else {
    FUN_1001e610();
  }
  param_1[0x643] = (int)pvVar5;
  (**(code **)(*param_1 + 0x18))();
  ExceptionList = local_10;
  return param_1;
}



void __fastcall FUN_1002a960(undefined4 *param_1)

{
  uint uVar1;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  puStack_c = &LAB_1002aab0;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  *param_1 = &PTR_LAB_10034294;
  local_8 = 0;
  uVar1 = 0;
  do {
    if ((undefined4 *)param_1[uVar1 + 0x638] != (undefined4 *)0x0) {
      (*(code *)**(undefined4 **)param_1[uVar1 + 0x638])(1);
    }
    param_1[uVar1 + 0x638] = 0;
    uVar1 = uVar1 + 1 & 0xffff;
  } while (uVar1 < 4);
  uVar1 = 0;
  do {
    if ((undefined4 *)param_1[uVar1 + 0x63c] != (undefined4 *)0x0) {
      (*(code *)**(undefined4 **)param_1[uVar1 + 0x63c])(1);
    }
    param_1[uVar1 + 0x63c] = 0;
    uVar1 = uVar1 + 1 & 0xffff;
  } while (uVar1 < 5);
  uVar1 = 0;
  do {
    if ((undefined4 *)param_1[uVar1 + 0x641] != (undefined4 *)0x0) {
      (*(code *)**(undefined4 **)param_1[uVar1 + 0x641])(1);
    }
    param_1[uVar1 + 0x641] = 0;
    uVar1 = uVar1 + 1 & 0xffff;
  } while (uVar1 < 2);
  if ((undefined4 *)param_1[0x643] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x643])(1);
  }
  param_1[0x643] = 0;
  local_8 = 0xffffffff;
  FUN_10010220();
  ExceptionList = local_10;
  return;
}



void __thiscall FUN_1002b8c0(int *param_1,int param_2)

{
  (**(code **)(*param_1 + 0x18))();
  param_1[0x637] = param_2;
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void __thiscall FUN_1002d8b4(int param_1,undefined4 param_2,byte param_3,byte param_4,short param_5)

{
  float fVar1;
  float fVar2;
  float fVar3;
  int iVar4;
  
  fVar3 = _DAT_101545dc;
  iVar4 = (int)((uint)param_4 << 4) >> 7;
  fVar1 = *(float *)(&DAT_1014e64c + iVar4 * 4);
  fVar2 = _DAT_101545d0;
  switch(param_5) {
  case 6:
    fVar2 = _DAT_101545d4;
    break;
  case 7:
    fVar2 = _DAT_101545e4;
    break;
  case 8:
    fVar1 = fVar1 * fVar1 * fVar1 * fVar1;
    fVar1 = fVar1 * fVar1;
    FUN_1001e3d0(0x3f7ef9db);
    fVar2 = fVar3;
    break;
  case 9:
    fVar2 = _DAT_101545d4;
  }
  if (param_5 == 9) {
    FUN_1001e2b0(param_2,(float)param_3 * _DAT_101545d8 * (float)param_3 * fVar2 *
                         *(float *)(param_1 + 0x191c),*(undefined4 *)(&DAT_1014e64c + iVar4 * 4),0);
    return;
  }
  FUN_1001e2b0(param_2,_DAT_101545d8 * (float)param_3 * (float)param_3 * fVar2 *
                       *(float *)(param_1 + 0x191c),fVar1,0);
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void __thiscall
FUN_1002da24(int param_1,undefined4 param_2,byte param_3,byte param_4,byte param_5,
            undefined2 param_6)

{
  float fVar1;
  
  fVar1 = _DAT_101545f8;
  switch(param_6) {
  case 3:
    fVar1 = _DAT_1015460c;
    break;
  case 4:
    fVar1 = _DAT_10154608;
    break;
  case 5:
    fVar1 = _DAT_10154604;
    break;
  case 6:
  case 7:
  case 8:
  case 9:
    break;
  case 10:
    fVar1 = _DAT_101545fc;
    break;
  case 0xb:
    fVar1 = _DAT_101545fc;
  }
  FUN_1001ead0(param_2,(float)param_3 * _DAT_10154600 * (float)param_3 * fVar1 *
                       *(float *)(param_1 + 0x191c),
               *(undefined4 *)(&DAT_1014e64c + ((int)((uint)param_5 << 4) >> 7) * 4),0,
               (&DAT_1014e54c)[param_4]);
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void __thiscall FUN_1002db24(int param_1,byte param_2,byte param_3,byte param_4,byte param_5)

{
  undefined4 uVar1;
  int iVar2;
  bool bVar3;
  
  bVar3 = _DAT_1014e544 == 0;
  uVar1 = *(undefined4 *)(*(int *)(param_1 + 0x18dc) + 100 + ((int)(uint)param_4 >> 5) * 4);
  if (bVar3) {
    FUN_1001e3d0(0x3f7d70a4);
  }
  else {
    FUN_1001e3d0(0x3f7d70a4);
  }
  _DAT_1014e544 = (ushort)bVar3;
  iVar2 = (int)((uint)param_5 << 3) >> 7;
  FUN_1001e5c0(uVar1,(float)param_2 * _DAT_10154644 * (float)param_2 * _DAT_10154644 *
                     *(float *)(param_1 + 0x191c) *
                     ((float)_DAT_10154638 - *(float *)(&DAT_10034264 + iVar2 * 4)),
               *(undefined4 *)(&DAT_1014e64c + ((int)((uint)param_3 << 4) >> 7) * 4),0,
               *(undefined4 *)(&DAT_10034264 + iVar2 * 4));
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void __thiscall FUN_1002dc54(int param_1,byte param_2,byte param_3,byte param_4,byte param_5)

{
  uint uVar1;
  
  uVar1 = DAT_1014e548 + 1 & 0x1f;
  _DAT_1014e548 = (undefined2)uVar1;
  FUN_1001e820(*(undefined4 *)
                (*(int *)(param_1 + 0x18dc) + 100 +
                *(short *)(&DAT_10034210 + ((int)((uint)param_4 * 5) >> 7) * 2) * 4),
               (float)param_2 * _DAT_1015464c * (float)param_2 * _DAT_1015464c *
               *(float *)(param_1 + 0x191c),0x3f7f7cee,param_3 + 0x1e,
               *(undefined4 *)
                (*(int *)(param_1 + 0x18dc) + 100 +
                (uint)*(ushort *)(&DAT_1003425c + (uint)*(ushort *)(&DAT_1003421c + uVar1 * 2) * 2)
                * 4),(float)param_5 * _DAT_10154648);
  return;
}



void __fastcall FUN_1002dd40(int param_1)

{
  uint uVar1;
  
  uVar1 = 0;
  do {
    (**(code **)(**(int **)(param_1 + 0x18e0 + uVar1 * 4) + 4))();
    uVar1 = uVar1 + 1 & 0xffff;
  } while (uVar1 < 4);
  uVar1 = 0;
  do {
    (**(code **)(**(int **)(param_1 + 0x1904 + uVar1 * 4) + 4))();
    uVar1 = uVar1 + 1 & 0xffff;
  } while (uVar1 < 2);
  uVar1 = 0;
  do {
    (**(code **)(**(int **)(param_1 + 0x18f0 + uVar1 * 4) + 4))();
    uVar1 = uVar1 + 1 & 0xffff;
  } while (uVar1 < 5);
  (**(code **)(**(int **)(param_1 + 0x190c) + 4))();
  return;
}



DWORD GetFileVersionInfoSizeA(LPCSTR lptstrFilename,LPDWORD lpdwHandle)

{
  DWORD DVar1;
  
                    // WARNING: Could not recover jumptable at 0x1002ddc0. Too many branches
                    // WARNING: Treating indirect jump as call
  DVar1 = GetFileVersionInfoSizeA(lptstrFilename,lpdwHandle);
  return DVar1;
}



BOOL GetFileVersionInfoA(LPCSTR lptstrFilename,DWORD dwHandle,DWORD dwLen,LPVOID lpData)

{
  BOOL BVar1;
  
                    // WARNING: Could not recover jumptable at 0x1002ddc6. Too many branches
                    // WARNING: Treating indirect jump as call
  BVar1 = GetFileVersionInfoA(lptstrFilename,dwHandle,dwLen,lpData);
  return BVar1;
}



BOOL VerQueryValueA(LPCVOID pBlock,LPCSTR lpSubBlock,LPVOID *lplpBuffer,PUINT puLen)

{
  BOOL BVar1;
  
                    // WARNING: Could not recover jumptable at 0x1002ddcc. Too many branches
                    // WARNING: Treating indirect jump as call
  BVar1 = VerQueryValueA(pBlock,lpSubBlock,lplpBuffer,puLen);
  return BVar1;
}



void FUN_1002dde0(void *param_1)

{
  free(param_1);
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

uint FUN_1002ddf0(int param_1,uint param_2,uint param_3,uint param_4)

{
  double dVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  float10 fVar6;
  float10 fVar7;
  float10 fVar8;
  int local_20;
  ushort uVar9;
  
  uVar2 = -((int)param_2 >> 0x1f);
  if ((param_2 & 0x7ff00000) < 0x7ff00000) {
    if ((param_2 & 0x7ff00000) == 0) {
      if (param_1 == 0) {
        dVar1 = (double)CONCAT44(param_4,param_3);
        if ((_DAT_10034350 == dVar1) != 0) {
          return (uint)(ushort)((ushort)(_DAT_10034350 < dVar1) << 8 |
                                (ushort)(NAN(_DAT_10034350) || NAN(dVar1)) << 10 |
                               (ushort)(_DAT_10034350 == dVar1) << 0xe);
        }
        dVar1 = (double)CONCAT44(param_4,param_3);
        if ((_DAT_10034358 == dVar1) != 0) {
          return (uint)(ushort)((ushort)(_DAT_10034358 < dVar1) << 8 |
                                (ushort)(NAN(_DAT_10034358) || NAN(dVar1)) << 10 |
                               (ushort)(_DAT_10034358 == dVar1) << 0xe);
        }
        if ((int)param_4 < 0) {
          piVar3 = _errno();
          *piVar3 = 0x21;
          return param_2 >> 0x1f;
        }
        return param_2 >> 0x1f;
      }
    }
    else {
      if (uVar2 != 0) goto LAB_1002e0a0;
      uVar2 = 0;
    }
  }
  else {
    if (param_4 == 0) {
      return uVar2;
    }
    uVar5 = param_2;
    if (((param_2 & 0xfffff) != 0) || (param_1 != 0)) goto joined_r0x1002e2fc;
    if (-1 < (int)param_2) {
      if ((int)param_4 < 0) {
        return uVar2;
      }
      return uVar2;
    }
LAB_1002e0a0:
    uVar5 = param_3;
    if (param_3 == 0) {
      uVar5 = param_4 & 0x7fffffff;
      if (uVar5 == 0) {
        return uVar2;
      }
      if (uVar5 == 0x3ff00000) {
        return uVar2;
      }
    }
    if ((((uVar5 & 0x7ff00000) < 0x3ff00000) || (uVar2 = param_3 << 0xc, uVar2 != 0)) ||
       (uVar2 = param_3 >> 0x14,
       (param_4 << 0xc | uVar2) << ((byte)((uVar5 & 0x7ff00000) + 0xc0100000 >> 0x14) & 0x1f) != 0))
    {
      piVar3 = _errno();
      *piVar3 = 0x21;
      return uVar2;
    }
    param_2 = param_2 & 0x7fffffff;
    uVar2 = 1;
  }
  if ((param_4 & 0x7fffffff) == 0) {
    if (param_3 == 0) {
      return uVar2;
    }
LAB_1002dea9:
    local_20 = (int)(longlong)
                    ROUND(ROUND((float10)CONCAT28(0x4006,SUB108((float10)(double)CONCAT44(param_2,
                                                  param_1),0))));
    iVar4 = (local_20 + -0x80) * 8;
    fVar8 = (float10)*(double *)(&DAT_10156000 + iVar4) *
            ((float10)CONCAT28(0x3fff,SUB108((float10)(double)CONCAT44(param_2,param_1),0)) -
            (float10)_DAT_10034368 * (float10)local_20);
    fVar6 = fVar8 * fVar8;
    fVar7 = (float10)(int)((param_2 >> 0x14) - 0x3ff);
    fVar6 = (float10)*(double *)(&DAT_10156410 + iVar4) + (float10)_DAT_10034370 * fVar7 +
            (float10)*(double *)(&DAT_10156818 + iVar4) + (float10)_DAT_10034378 * fVar7 +
            ((float10)_DAT_100343a8 +
            ((float10)_DAT_100343c8 * fVar6 + (float10)_DAT_100343b8) * fVar6) * fVar6 +
            ((float10)_DAT_100343b0 + (float10)_DAT_100343c0 * fVar6) * fVar6 * fVar8 + fVar8;
LAB_1002df74:
    fVar6 = (float10)(double)CONCAT44(param_4,param_3) * fVar6;
    dVar1 = (double)fVar6;
    fVar6 = fVar6 - (float10)dVar1;
    FUN_1002e3e0(SUB82(dVar1,0),(int)((ulonglong)dVar1 >> 0x20),SUB104(fVar6,0),
                 (int)((unkuint10)fVar6 >> 0x20),(short)((unkuint10)fVar6 >> 0x40));
    if (uVar2 == 0) {
      return 0;
    }
    uVar2 = (uint)(longlong)ROUND((double)CONCAT44(param_4,param_3));
    if (((longlong)ROUND((double)CONCAT44(param_4,param_3)) & 1U) == 0) {
      return uVar2;
    }
    return uVar2;
  }
  uVar9 = (ushort)((unkuint10)(float10)(double)CONCAT44(param_4,param_3) >> 0x40);
  if ((uVar9 & 0x7fff) < 0x4045) {
    if (0x3fb8 < (uVar9 & 0x7fff)) {
      if ((float10)_DAT_10034358 == (float10)(double)CONCAT44(param_2,param_1)) {
        if ((param_4 & 0x7ff00000) == 0x7ff00000) {
          return uVar2;
        }
        goto LAB_1002e15d;
      }
      if (((ushort)((unkuint10)((float10)(double)CONCAT44(param_2,param_1) - (float10)_DAT_10034358)
                   >> 0x40) & 0x7fff) < 0x3ffb) {
        fVar6 = (float10)_DAT_10034360 *
                (((float10)(double)CONCAT44(param_2,param_1) - (float10)_DAT_10034358) /
                ((float10)_DAT_10034358 + (float10)(double)CONCAT44(param_2,param_1)));
        fVar7 = fVar6 * fVar6;
        fVar8 = fVar7 * fVar7;
        fVar6 = fVar6 + ((float10)_DAT_10034380 +
                         ((float10)_DAT_100343a0 * fVar8 + (float10)_DAT_10034390) * fVar8 +
                        ((float10)_DAT_10034388 + (float10)_DAT_10034398 * fVar8) * fVar7) *
                        fVar7 * fVar6;
        goto LAB_1002df74;
      }
      if ((param_4 == 0x3ff00000) && (param_3 == 0)) {
        return uVar2;
      }
      goto LAB_1002dea9;
    }
    if ((param_2 != 0x3ff00000) || (param_1 != 0)) {
      return uVar2;
    }
  }
  else {
    if ((param_4 & 0x7fffffff) == 0x7ff00000) {
      uVar5 = param_4;
      if (((param_4 & 0xfffff) == 0) && (param_3 == 0)) {
        if ((int)param_4 < 0) {
          if ((int)param_2 < 0x3ff00000) {
            return 0;
          }
          if (((int)param_2 < 0x3ff00001) && (param_1 == 0)) {
            return 0;
          }
          return 0;
        }
        if ((int)param_2 < 0x3ff00000) {
          return 0;
        }
        if (0x3ff00000 < (int)param_2) {
          return 0;
        }
        if (param_1 == 0) {
          return 0;
        }
        return 0;
      }
joined_r0x1002e2fc:
      if ((uVar5 & 0x80000) == 0) {
        return uVar2;
      }
      return uVar2;
    }
    if ((param_2 != 0x3ff00000) || (param_1 != 0)) {
      if (-1 < (int)param_2) {
        if (uVar2 == 0) {
          return 0;
        }
        return uVar2;
      }
      if (uVar2 == 0) {
        return 0;
      }
      return uVar2;
    }
  }
  if ((param_4 & 0x7ff00000) == 0x7ff00000) {
    return uVar2;
  }
LAB_1002e15d:
  if (uVar2 == 0) {
    return 0;
  }
  uVar2 = (uint)(longlong)ROUND((double)CONCAT44(param_4,param_3));
  if (((longlong)ROUND((double)CONCAT44(param_4,param_3)) & 1U) == 0) {
    return uVar2;
  }
  return uVar2;
}



// WARNING: Removing unreachable block (ram,0x1002e4b8)
// WARNING: Removing unreachable block (ram,0x1002e4e8)
// WARNING: Globals starting with '_' overlap smaller symbols at the same address

float10 FUN_1002e3e0(int param_1,uint param_2)

{
  int *piVar1;
  uint uVar2;
  float10 fVar3;
  float10 fVar4;
  
  uVar2 = param_2 & 0x7ff00000;
  if (uVar2 < 0x40d00000) {
    if (uVar2 < 0x3df00001) {
      return (float10)1 + (float10)(double)CONCAT44(param_2,param_1);
    }
    fVar4 = (float10)1.4426950408889634 * (float10)(double)CONCAT44(param_2,param_1);
    fVar3 = ROUND(fVar4);
    fVar4 = (float10)f2xm1(-(fVar3 - fVar4));
    fVar3 = (float10)fscale((float10)1 + fVar4,fVar3);
    return fVar3;
  }
  piVar1 = _errno();
  *piVar1 = 0x22;
  if (uVar2 < 0x7ff00000) {
    if ((int)param_2 < 0) {
      return _DAT_1015504c * _DAT_10155060;
    }
    return _DAT_1015506c * _DAT_10155080;
  }
  if (((param_2 & 0xfffff) == 0) && (param_1 == 0)) {
    if ((int)param_2 < 0) {
      return (float10)DAT_10155018;
    }
    return (float10)DAT_1015503c;
  }
  if ((param_2 & 80000) == 0) {
    return _DAT_10155028 * _DAT_10155032;
  }
  return (float10)(double)CONCAT44(param_2,param_1);
}



void __CxxFrameHandler(void)

{
                    // WARNING: Could not recover jumptable at 0x1002e510. Too many branches
                    // WARNING: Treating indirect jump as call
  __CxxFrameHandler();
  return;
}



void * __cdecl operator_new(uint param_1)

{
  void *pvVar1;
  
                    // WARNING: Could not recover jumptable at 0x1002e51c. Too many branches
                    // WARNING: Treating indirect jump as call
  pvVar1 = operator_new(param_1);
  return pvVar1;
}



void _CxxThrowException(void *pExceptionObject,ThrowInfo *pThrowInfo)

{
                    // WARNING: Could not recover jumptable at 0x1002e522. Too many branches
                    // WARNING: Subroutine does not return
                    // WARNING: Treating indirect jump as call
  _CxxThrowException(pExceptionObject,pThrowInfo);
  return;
}



type_info * __thiscall FUN_1002e590(type_info *param_1,byte param_2)

{
  type_info::~type_info(param_1);
  if ((param_2 & 1) != 0) {
    FUN_1002dde0(param_1);
  }
  return param_1;
}



// Library Function - Single Match
//  __allshr
// 
// Library: Visual Studio

undefined8 __fastcall __allshr(byte param_1,int param_2)

{
  uint in_EAX;
  int iVar1;
  
  iVar1 = param_2 >> 0x1f;
  if (0x3f < param_1) {
    return CONCAT44(iVar1,iVar1);
  }
  if (param_1 < 0x20) {
    return CONCAT44(param_2 >> (param_1 & 0x1f),
                    in_EAX >> (param_1 & 0x1f) | param_2 << 0x20 - (param_1 & 0x1f));
  }
  return CONCAT44(iVar1,param_2 >> (param_1 & 0x1f));
}



// Library Function - Single Match
//  __alldiv
// 
// Library: Visual Studio

undefined8 __alldiv(uint param_1,uint param_2,uint param_3,uint param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  bool bVar9;
  char cVar10;
  
  cVar10 = (int)param_2 < 0;
  if ((bool)cVar10) {
    bVar9 = param_1 != 0;
    param_1 = -param_1;
    param_2 = -(uint)bVar9 - param_2;
  }
  if ((int)param_4 < 0) {
    cVar10 = cVar10 + '\x01';
    bVar9 = param_3 != 0;
    param_3 = -param_3;
    param_4 = -(uint)bVar9 - param_4;
  }
  if (param_4 == 0) {
    uVar4 = param_2 / param_3;
    iVar5 = (int)(((ulonglong)param_2 % (ulonglong)param_3 << 0x20 | (ulonglong)param_1) /
                 (ulonglong)param_3);
  }
  else {
    uVar7 = param_1;
    uVar4 = param_3;
    uVar6 = param_2;
    uVar8 = param_4;
    do {
      uVar3 = uVar8 & 1;
      uVar8 = uVar8 >> 1;
      uVar4 = (uint)(CONCAT14(uVar3 != 0,uVar4) >> 1);
      uVar3 = uVar6 & 1;
      uVar6 = uVar6 >> 1;
      uVar7 = (uint)(CONCAT14(uVar3 != 0,uVar7) >> 1);
    } while (uVar8 != 0);
    uVar1 = CONCAT44(uVar6,uVar7) / (ulonglong)uVar4;
    iVar5 = (int)uVar1;
    lVar2 = (ulonglong)param_3 * (uVar1 & 0xffffffff);
    uVar4 = (uint)((ulonglong)lVar2 >> 0x20);
    uVar7 = uVar4 + iVar5 * param_4;
    if (((CARRY4(uVar4,iVar5 * param_4)) || (param_2 < uVar7)) ||
       ((param_2 <= uVar7 && (param_1 < (uint)lVar2)))) {
      iVar5 = iVar5 + -1;
    }
    uVar4 = 0;
  }
  if (cVar10 == '\x01') {
    bVar9 = iVar5 != 0;
    iVar5 = -iVar5;
    uVar4 = -(uint)bVar9 - uVar4;
  }
  return CONCAT44(uVar4,iVar5);
}



void FUN_1002e750(undefined4 param_1,undefined4 param_2,int param_3,code *param_4)

{
  void *local_14;
  undefined *puStack_10;
  undefined *puStack_c;
  undefined4 local_8;
  
  puStack_c = &DAT_1002f138;
  puStack_10 = &DAT_1002ead8;
  local_14 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_14;
  while( true ) {
    param_3 = param_3 + -1;
    if (param_3 < 0) break;
    (*param_4)();
  }
  local_8 = 0xffffffff;
  FUN_1002e7c9();
  ExceptionList = local_14;
  return;
}



void FUN_1002e7c9(void)

{
  int unaff_EBP;
  undefined4 unaff_ESI;
  undefined4 unaff_EDI;
  
  if (*(int *)(unaff_EBP + -0x1c) == 0) {
    FUN_1002e800(unaff_ESI,unaff_EDI,*(undefined4 *)(unaff_EBP + 0x10),
                 *(undefined4 *)(unaff_EBP + 0x14));
  }
  return;
}



void FUN_1002e800(undefined4 param_1,undefined4 param_2,int param_3,code *param_4)

{
  void *local_14;
  undefined *puStack_10;
  undefined *puStack_c;
  undefined4 local_8;
  
  puStack_c = &DAT_1002f148;
  puStack_10 = &DAT_1002ead8;
  local_14 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_14;
  while( true ) {
    param_3 = param_3 + -1;
    if (param_3 < 0) break;
    (*param_4)();
  }
  ExceptionList = local_14;
  return;
}



void __RTDynamicCast(void)

{
                    // WARNING: Could not recover jumptable at 0x1002e890. Too many branches
                    // WARNING: Treating indirect jump as call
  __RTDynamicCast();
  return;
}



void FUN_1002e8a0(undefined4 param_1,undefined4 param_2,int param_3,code *param_4)

{
  int iVar1;
  void *local_14;
  undefined *puStack_10;
  undefined *puStack_c;
  undefined4 local_8;
  
  puStack_c = &DAT_1002f158;
  puStack_10 = &DAT_1002ead8;
  local_14 = ExceptionList;
  local_8 = 0;
  ExceptionList = &local_14;
  for (iVar1 = 0; iVar1 < param_3; iVar1 = iVar1 + 1) {
    (*param_4)();
  }
  local_8 = 0xffffffff;
  FUN_1002e918();
  ExceptionList = local_14;
  return;
}



void FUN_1002e918(void)

{
  undefined4 unaff_EBX;
  int unaff_EBP;
  undefined4 unaff_ESI;
  undefined4 unaff_EDI;
  
  if (*(int *)(unaff_EBP + -0x20) == 0) {
    FUN_1002e800(unaff_EDI,unaff_EBX,unaff_ESI,*(undefined4 *)(unaff_EBP + 0x18));
  }
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

undefined4 FUN_1002e940(undefined4 param_1,int param_2)

{
  undefined4 *_Memory;
  undefined4 *puVar1;
  
  if (param_2 == 0) {
    if (DAT_1014e690 < 1) {
      return 0;
    }
    DAT_1014e690 = DAT_1014e690 + -1;
  }
  _DAT_1014e694 = *(undefined4 *)_adjust_fdiv_exref;
  if (param_2 == 1) {
    DAT_1014e6a0 = malloc(0x80);
    if (DAT_1014e6a0 == (undefined4 *)0x0) {
      return 0;
    }
    *DAT_1014e6a0 = 0;
    DAT_1014e69c = DAT_1014e6a0;
    initterm(&DAT_10030000,&DAT_10030060);
    DAT_1014e690 = DAT_1014e690 + 1;
    return 1;
  }
  if ((param_2 == 0) && (DAT_1014e6a0 != (undefined4 *)0x0)) {
    puVar1 = DAT_1014e69c + -1;
    _Memory = DAT_1014e6a0;
    if (DAT_1014e6a0 <= puVar1) {
      do {
        if ((code *)*puVar1 != (code *)0x0) {
          (*(code *)*puVar1)();
          _Memory = DAT_1014e6a0;
        }
        puVar1 = puVar1 + -1;
      } while (_Memory <= puVar1);
    }
    free(_Memory);
    DAT_1014e6a0 = (undefined4 *)0x0;
  }
  return 1;
}



int entry(undefined4 param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  
  iVar1 = 1;
  if ((param_2 == 0) && (DAT_1014e690 == 0)) {
    return 0;
  }
  if ((param_2 == 1) || (param_2 == 2)) {
    if (DAT_1014e698 != (code *)0x0) {
      iVar1 = (*DAT_1014e698)(param_1,param_2,param_3);
    }
    if (iVar1 != 0) {
      iVar1 = FUN_1002e940(param_1,param_2,param_3);
      if (iVar1 != 0) goto LAB_1002ea6e;
    }
    return 0;
  }
LAB_1002ea6e:
  iVar1 = FUN_1000dad0(param_1,param_2,param_3);
  if ((param_2 == 1) && (iVar1 == 0)) {
    FUN_1002e940(param_1,0,param_3);
  }
  if ((param_2 == 0) || (param_2 == 3)) {
    iVar2 = FUN_1002e940(param_1,param_2,param_3);
    if (iVar2 == 0) {
      iVar1 = 0;
    }
    if ((iVar1 != 0) && (DAT_1014e698 != (code *)0x0)) {
      iVar1 = (*DAT_1014e698)(param_1,param_2,param_3);
    }
  }
  return iVar1;
}



void __cdecl free(void *_Memory)

{
                    // WARNING: Could not recover jumptable at 0x1002eac0. Too many branches
                    // WARNING: Treating indirect jump as call
  free(_Memory);
  return;
}



int * __cdecl _errno(void)

{
  int *piVar1;
  
                    // WARNING: Could not recover jumptable at 0x1002eac6. Too many branches
                    // WARNING: Treating indirect jump as call
  piVar1 = _errno();
  return piVar1;
}



void __thiscall type_info::~type_info(type_info *this)

{
                    // WARNING: Could not recover jumptable at 0x1002ead2. Too many branches
                    // WARNING: Treating indirect jump as call
  ~type_info(this);
  return;
}



void __cdecl initterm(void)

{
                    // WARNING: Could not recover jumptable at 0x1002eae4. Too many branches
                    // WARNING: Treating indirect jump as call
  initterm();
  return;
}


